/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-08-27 19:25:56 +0200 (Fri, 27 Aug 2010) $
 * $Revision: 82 $
 * $Author:   $
 */

/** 
 * @file
 * Generic character device. 
 * This generic interface consists of two callbacks and three methods: 
 *  - xmit_cb() is called by the device when it is ready to transmit
 *  - higher protocol instance may then call the xmit() method
 *  - recv_cb() is called by the device when it has received a byte
 *  - resync() method should be called by the higher protocol instance 
 *    when there are link-layer framing errors
 *  - status() method can be used to get current status flags
 */

#ifndef __CDEV_H
#define __CDEV_H

#include <config.h>
#include <cpu/types.h>

struct cdev;

/**
 * Type of cdev xmit() methods. 
 * @param dev Target device
 * @param tx Character to send
 */
typedef void (*cdev_xmit_t)(struct cdev *dev, uint8_t tx);

/**
 * Type of cdev resync() methods. 
 * @param dev Target device
 */
typedef void (*cdev_resync_t)(struct cdev *dev);

/** @name cdev status flag values */
/*@{*/
#define CDEV_STATUS_TX 0x0001
#define CDEV_STATUS_RX 0x0002
/*@}*/

/**
 * Type of cdev status() methods. 
 * @param dev Target device
 */
typedef uint16_t (*cdev_status_t)(struct cdev *dev);

/**
 * Type of cdev xmit_cb() callbacks. 
 * This callback can be called from interrupt context. 
 */
typedef void (*cdev_xmit_cb_t)(void *app);

/**
 * Type of cdev recv_cb() callbacks. 
 * This callback can be called from interrupt context. 
 */
typedef void (*cdev_recv_cb_t)(void *app, uint8_t rx);

/**
 * Generic character device. 
 */
struct cdev {
	/* Methods: called by the higher protocol instance */

	/** Transmit method */
	cdev_xmit_t xmit;
	/** Resynchronization method */
	cdev_resync_t resync;
	/** Status method */
	cdev_status_t status;

	/* Callbacks: called by the character device */

	/** Pointer to a higher layer instance */
	void *app;
	/** Function to call when device is ready to transmit */
	cdev_xmit_cb_t xmit_cb;
	/** Function to call when a character is received */
	cdev_recv_cb_t recv_cb;
};

void cdev_init(struct cdev *dev, 
	cdev_xmit_t xmit, 
	cdev_resync_t resync,
	cdev_status_t status);
void cdev_hook(struct cdev *dev, void *app, 
	cdev_xmit_cb_t xmit_cb, cdev_recv_cb_t recv_cb);
void cdev_release(struct cdev *dev, void *app);

#endif //__CDEV_H

