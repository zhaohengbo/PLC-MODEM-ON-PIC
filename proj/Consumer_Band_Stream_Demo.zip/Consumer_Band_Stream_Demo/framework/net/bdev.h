/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-11-05 16:48:49 +0100 (Fri, 05 Nov 2010) $
 * $Revision: 88 $
 * $Author:   $
 */

/** 
 * @file
 * Generic buffered device. 
 * This generic interface consists of four methods: 
 *  - status() method can be used to get current status flags
 *  - when status() returns that transmit buffer is not full, the higher
 *    protocol instance may call the xmit() method
 *  - the recv() method can be called at any time, it will return all 
 *    the data received (may return an empty buffer)
 */

#ifndef __BDEV_H
#define __BDEV_H

#include <config.h>
#include <cpu/types.h>

#include <net/nbuf.h>

struct bdev;

/** @name bdev status flag values */
/*@{*/
/** Transmission in progress */
#define BDEV_STATUS_TX 0x0001
/** Transmit buffer full */
#define BDEV_STATUS_TX_BF 0x0002
/** Reception in progress */
#define BDEV_STATUS_RX 0x0004
/*@}*/

/**
 * Type of bdev status() methods. 
 * High 8 bits the word returned contain a link quality metric, if available. 
 * @param dev Target device
 */
typedef uint16_t (*bdev_status_t)(struct bdev *dev);

/**
 * Type of bdev xmit() methods. 
 * @param dev Target device
 * @param page Buffer to transmit, NULL indicates end of frame/packet
 */
typedef void (*bdev_xmit_t)(struct bdev *dev, struct npage *page);

/**
 * Type of bdev recv() methods. 
 * @param dev Target device
 * @return Received buffer
 */
typedef struct npage* (*bdev_recv_t)(struct bdev *dev);

/**
 * Generic buffered device. 
 */
struct bdev {
	/* Methods: called by the higher protocol instance */

	/** Transmit method, must not be called when BF flag is set */
	bdev_xmit_t xmit;
	/** Receive method */
	bdev_recv_t recv;
	/** Status method */
	bdev_status_t status;
};

void bdev_init(struct bdev *dev, 
	bdev_xmit_t xmit, 
	bdev_recv_t recv, 
	bdev_status_t status);

#endif //__BDEV_H

