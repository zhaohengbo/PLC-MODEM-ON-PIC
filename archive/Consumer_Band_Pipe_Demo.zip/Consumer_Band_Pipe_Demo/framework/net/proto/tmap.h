/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-10-22 16:00:58 +0200 (Fri, 22 Oct 2010) $
 * $Revision: 85 $
 * $Author:   $
 */

/** 
 * @file
 * Trivial Media Access Protocol Device. 
 * 
 * TMAP is a simplistic link layer protocol, suitable for networks where
 * every node is supposed to act as a repeater (eg. a power distribution 
 * network with stations randomly placed without any sensible order).  
 * 
 * This protocol has been defined by Microchip as a test protocol to 
 * demonstrate Power Line Modem operation. 
 *
 * Frame format: 
 *   PRE : Preamble. Must have at least one byte, there is no upper limit
 *   SOF : Start-Of-Frame delimiter (0x7E)
 *   LEN : Length of frame, from SOF to FCS inclusive
 *   TTL : Time-To-Live. When non-zero receiving stations that are configured
 *         as repeaters will retransmit the frame received, provided they're 
 *         neither its source, nor destination. 
 *  SMAC : Source MAC address (2 bytes)
 *  DMAC : Destination MAC address (2 bytes)
 *  PAYL : Payload (variable length)
 *   FCS : ITUT Frame Check Sequence (2 bytes)
 *         Generation polynomial: X^16 + X^12 + X^5 + 1
 */

#ifndef __TMAP_H
#define __TMAP_H

#include <config.h>

#include <net/net.h>
#include <net/bdev.h>

/** TMAP protocol overhead (in bytes, FCS inclusive) */
#define TMAP_OVERHEAD 9

/**
 * TMAP protocol header. 
 */
struct tmap_header {
	/** Time to live */
	uint8_t ttl;
	/** Source MAC */
	uint16_t smac;
	/** Destination MAC */
	uint16_t dmac;
};

/** TMAP frame reception states */
typedef enum {
	TMAP_RX_SEEK_PRE,
	TMAP_RX_SEEK_SOF,
	TMAP_RX_LEN,
	TMAP_RX_FRAME_DATA
} tmap_dev_rx_state_t;

/** @name TMAP device flags */
/*@{*/
#define TMAP_FLAG_PROMISC 0x0001
#define TMAP_FLAG_REPEATER 0x0002
/*@}*/

/**
 * TMAP protocol device. 
 */
struct tmap_dev {
	/** Interface statistics */
	struct netif_stats stats;

	/** Interface flags */
	uint16_t iflags;

	/** Interface own MAC address */
	uint16_t my_mac;

	/** Buffer currently being transmitted */
	struct nbuf *tx_nb;
	/** Buffer currently being received */
	struct nbuf *rx_nb;

	/** Transmit queue */
	struct nbuf_queue tx_queue;
	/** Receive queue */
	struct nbuf_queue rx_queue;

	/** Frame reception state */
	tmap_dev_rx_state_t rx_state;
	/** Bytes remaining to receive */
	uint8_t rx_remain;

	/** Buffered device used */
	struct bdev *interface;
};

bool tmap_resend(struct tmap_dev *dev, struct nbuf *buf);
bool tmap_send(struct tmap_dev *dev, struct nbuf *buf, 
	const struct tmap_header *header);

struct nbuf *tmap_recv(struct tmap_dev *dev, struct tmap_header *header);

void tmap_init(struct tmap_dev *dev, uint16_t mac);
void tmap_start(struct tmap_dev *dev, struct bdev *interface);
void tmap_set_flags(struct tmap_dev *dev, uint16_t flags);
void tmap_stop(struct tmap_dev *dev);
void tmap_poll(struct tmap_dev *dev);

#endif //__TMAP_H

