/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-11-06 19:26:54 +0100 (Sat, 06 Nov 2010) $
 * $Revision: 91 $
 * $Author:   $
 */

#ifndef __PLM_H
#define __PLM_H

#include <cpu/types.h>

/**
 * Start the modulator.
 *
 * This function configures the Output Compare channel(s), starts 
 * the Timer 2 and enables the Timer 2 interrupt. It is mandatory 
 * to call this function before any calls to plm_xmit() are made.
 */
void plm_mod_start(void);

/**
 * Start the demodulator and its associated signal source. 
 *
 * This function configures the selected ADC channel, starts the timer 
 * that triggers ADC conversions and optionally enables a DMA channel 
 * to service the selected ADC input. Timer and either DMA or ADC 
 * interrupts get enabled. It is mandatory to call this function before
 * any calls to plm_recv() are made.
 */
void plm_demod_start(void);

/**
 * Resynchronize the demodulator. 
 *
 * Forces the demodulator to seek new byte synchronization. This function 
 * may be called in cases when the demodulator keeps indicating bit and byte 
 * synchronization, but higher protocol layers decide that the patterns 
 * received do not form valid frames, thus suggesting that the byte 
 * synchronization is misaligned.
 */
void plm_demod_resync(void);

/**
 * Modem transmit function. 
 *
 * Transmits a buffer. This is a zero copy operation � the pointer passed
 * is used to access payload bytes directly when needed. The operation is
 * double buffered � the transmission of a previous buffer may already be
 * in progress. In all cases the buffer passed is added to a single-entry wait
 * queue and a "TX buffer full" (PLM_TX_BF) flag is set. As soon as the
 * transmission becomes possible, the pointer is copied to a working register
 * and the "TX buffer full" flag is cleared. The application must not write
 * to the buffer passed until the modem code has finished sending. It is
 * possible to determine whether the buffer is still in use by examining the
 * PLM_TX_BF and PLM_TX_ACTIVE status flags. This function must not
 * be called unless the PLM_TX_BF flag is clear.
 *
 * @param buf Buffer to transmit
 * @param size Number of bytes in the buffer
 */
void plm_xmit(const uint8_t *buf, uint16_t size);

/**
 * Modem receive function. 
 * 
 * Fetches a received buffer. Two parameters passed are the address and
 * size of a new buffer to fill-in. The function returns an address within
 * a previously passed buffer, pointing to the first free location in that
 * buffer. If the address returned is equal to the previously passed buffer
 * start address, then no data has been received between the calls. If the
 * address returned points outside the buffer (at previous buf+size), then the
 * buffer has been fully filled and would perhaps overflow, if it was allowed.
 * A NULL pointer is returned on the very first call.
 *
 * @param buf New buffer to fill in
 * @param size Buffer size
 * @return Next buffer address that would be written to
 */
uint8_t *plm_recv(uint8_t *buf, uint16_t size);

/** @name
 * Modem status flag masks. 
 */
/*@{*/
#define PLM_TX_ACTIVE_MASK (1<<PLM_TX_ACTIVE_FLAG)
#define PLM_TX_BF_MASK     (1<<PLM_TX_BF_FLAG)
#define PLM_BIT_SYNC_MASK  (1<<PLM_BIT_SYNC_FLAG)
#define PLM_BYTE_SYNC_MASK (1<<PLM_BYTE_SYNC_FLAG)
#define PLM_RESYNC_MASK    (1<<PLM_RESYNC_FLAG)
/*@}*/

/**
 * Get modem status flags. 
 *
 * Flag meaning: 
 *  - PLM_TX_ACTIVE - transmission is in progress
 *  - PLM_TX_BF - transmit buffer is full
 *  - PLM_BIT_SYNC - the receiver has found bit synchronization
 *  - PLM_BYTE_SYNC - the receiver has found byte synchronization
 *  - PLM_RESYNC - resynchronization has been requested
 *
 * @return Status flags
 */
uint16_t plm_get_status(void);

/**
 * Get the link quality for the last frame. 
 * Returns a 16 bit quality metric calculated during the initial bytes
 * after the last byte synchronization has been found. The metric is 
 * an average value of absolute values of demodulated signal samples, 
 * taken in the instants of bit decisions during the first 16 bytes 
 * after byte synchronization has been found.
 * @return A 16-bit number, a value > 0x7F00 means perfect quality. 
 */
uint16_t plm_quality(void);

#endif //__PLM_H

