/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-08-27 19:25:56 +0200 (Fri, 27 Aug 2010) $
 * $Revision: 82 $
 * $Author:   $
 */

#include <stdlib.h>
#include <string.h>

#include <config.h>
#include <cpu/adc.h>
#include <cpu/cpu.h>
#include <cpu/types.h>
#include <cpu/osc.h>

#include <common/plm.h>

#ifdef __dsPIC30F__
/** Start from XT with PLL x16 */
_FOSC(CSW_FSCM_OFF & XT_PLL16);
/** Brown-out disabled, maximum power-up timer delay */
_FBORPOR(PBOR_OFF & PWRT_64 & MCLR_EN);
/** WDT by default is off, may be turned on with RCON.SWDTEN, 512 ms timeout */
_FWDT(WDT_OFF & WDTPSA_64 & WDTPSB_4);
/** Code protection on */
_FGS(CODE_PROT_OFF);
#endif //__dsPIC30F__

#ifdef __dsPIC33F__
/** Primary oscillator is XT, switching is enabled, monitor is disabled */
_FOSC(FCKSM_CSECMD & OSCIOFNC_OFF & POSCMD_XT);
/** Start from the internal Fast RC clock */
_FOSCSEL(FNOSC_FRC & IESO_OFF);
/** Maximum power-up timer delay */
_FPOR(FPWRT_PWR128);
/** WDT by default is off, may be turned on with RCON.SWDTEN, 512 ms timeout */
_FWDT(FWDTEN_OFF & WINDIS_OFF & WDTPRE_PR32 & WDTPOST_PS512);
/** No Boot Sector */
_FBS(RBS_NO_RAM & BSS_NO_FLASH & BWRP_WRPROTECT_OFF);
/** No Secure Segment */
_FSS(RSS_NO_RAM & SSS_NO_FLASH & SWRP_WRPROTECT_OFF);
/** No code protection */
_FGS(GSS_OFF & GCP_OFF & GWRP_OFF);
#endif //__dsPIC33F__

#if 0
#define BUF_LEN 2048
uint16_t buf[BUF_LEN];
uint16_t bufptr = 0;

void buf_add(uint16_t sample)
{
    buf[bufptr++ & 0x7ff] = sample;
    buf[bufptr & 0x7ff] = 0xdead;
}
#endif //0

/* Buffers for Modem communications */
#define MSG_MAX_LEN 80

/* m2u: modem to uart 
 * u2m: uart to modem
 */
static unsigned int m2u_index = 0;
static unsigned int m2u_size = 0;
static unsigned int u2m_index = 0;
static unsigned int u2m_size = 0;

static unsigned char m2u[MSG_MAX_LEN];
static unsigned char u2m[MSG_MAX_LEN];

#define PRE PLM_PRE

static unsigned char pre[] = {PRE, PRE, PRE, PRE, PRE, PRE, PRE, PRE};

#define MODEM_RX_BUF_SIZE 16
static unsigned char *modem_rx_buf;
static unsigned char modem_rx_buf1[MODEM_RX_BUF_SIZE];
static unsigned char modem_rx_buf2[MODEM_RX_BUF_SIZE];

typedef enum
{
    M2U_STATE_MODEM_WAIT_PRE0,
    M2U_STATE_MODEM_WAIT_PRE1,
    M2U_STATE_MODEM_WAIT_PRE2,
    M2U_STATE_MODEM_DISCARD_PRE,
    M2U_STATE_MODEM_COLLECT,
    M2U_STATE_UART_SEND
} m2u_state_t;

typedef enum
{
    U2M_STATE_UART_COLLECT,
    U2M_STATE_MODEM_SEND_PRE,
    U2M_STATE_MODEM_SEND_DATA,
    U2M_STATE_MODEM_BUSY
} u2m_state_t;

m2u_state_t m2u_state;
u2m_state_t u2m_state;

/* Setup the UART */
void uart_setup(void)
{
    U2MODE = 0x8800;
    U2STA = 0x8400;
    U2BRG = (FCY / 16) / 19200 - 1;

    _U2RXIF = 0;
    _U2RXIE = 0;
    _U2TXIF = 0;
    _U2TXIE = 0;
}

/* Poll UART communications */
void uart_poll(void)
{
    if (U2STAbits.OERR)
    {
        U2STAbits.OERR = 0;
    }
    if (U2STAbits.URXDA)
    {
        char rx = U2RXREG;
        U2TXREG = rx;

        switch (u2m_state)
        {
        case U2M_STATE_UART_COLLECT:
            u2m[u2m_index++] = rx;
            if ((u2m_index == MSG_MAX_LEN) || (rx == '\r'))
            {
                u2m_state = U2M_STATE_MODEM_SEND_PRE;
                u2m_size = u2m_index;
                u2m_index = 0;
            }
            break;
        default:
            break;
        }
    }

    if (!U2STAbits.UTXBF)
    {
        switch (m2u_state)
        {
        case M2U_STATE_UART_SEND:
            if (m2u_index < m2u_size)
            {
                U2TXREG = m2u[m2u_index++];
            }
            else
            {
                U2TXREG = '\n';
                m2u_state = M2U_STATE_MODEM_WAIT_PRE0;
                m2u_size = 0;
                m2u_index = 0;
            }
            break;
        default:
            break;
        }
    }
}

/* Setup the MODEM */
void modem_setup(void)
{
    modem_rx_buf = modem_rx_buf1;
    u2m_state = U2M_STATE_UART_COLLECT;
    u2m_index = 0;

    m2u_state = M2U_STATE_MODEM_WAIT_PRE0;
    m2u_index = 0;

    plm_demod_start();
    plm_mod_start();
}

/* Poll MODEM communications */
void modem_poll(void)
{
    unsigned char c;

    unsigned char *end_ptr;
    unsigned char *ptr;

    end_ptr = plm_recv(modem_rx_buf, MODEM_RX_BUF_SIZE);
    if (modem_rx_buf == modem_rx_buf1)
    {
        modem_rx_buf = modem_rx_buf2;
    }
    else
    {
        modem_rx_buf = modem_rx_buf1;
    }

    for (ptr = modem_rx_buf; ptr < end_ptr; ptr++)
    {

        c = *ptr;

        switch (m2u_state)
        {
        case M2U_STATE_MODEM_WAIT_PRE0:
        case M2U_STATE_MODEM_WAIT_PRE1:
        case M2U_STATE_MODEM_WAIT_PRE2:
            if (c == PRE)
            {
                m2u_state++;
            }
            else
            {
                m2u_state = M2U_STATE_MODEM_WAIT_PRE0;
            }
            break;
        case M2U_STATE_MODEM_DISCARD_PRE:
            if (c == PRE)
            {
                break;
            }

            m2u_state = M2U_STATE_MODEM_COLLECT;
            //fall through
        case M2U_STATE_MODEM_COLLECT:
            m2u[m2u_index++] = c;
            if ((m2u_index == MSG_MAX_LEN) || (c == '\r'))
            {
                plm_demod_resync();
                m2u_state = M2U_STATE_UART_SEND;
                m2u_size = m2u_index;
                m2u_index = 0;
                break;
            }
            break;
        default:
            break;
        }
    }

    if ((plm_get_status() & PLM_TX_BF_MASK) == 0)
    {
        switch (u2m_state)
        {
        case U2M_STATE_MODEM_SEND_PRE:
            plm_xmit(pre, sizeof (pre));
            u2m_state = U2M_STATE_MODEM_SEND_DATA;
            break;
        case U2M_STATE_MODEM_SEND_DATA:
            plm_xmit(u2m, u2m_size);
            u2m_state = U2M_STATE_MODEM_BUSY;
            break;
        case U2M_STATE_MODEM_BUSY:
            u2m_state = U2M_STATE_UART_COLLECT;
            break;
        default:
            //plm_xmit(pre, sizeof(pre));
            break;
        }
    }
}

/* Show status on leds */
static void show_led_status(void)
{
    uint16_t status = plm_get_status();
    LATAbits.LATA0 = (status & PLM_TX_ACTIVE_MASK) ? 1 : 0;
    LATAbits.LATA1 = (status & PLM_BIT_SYNC_MASK) ? 1 : 0;
    LATAbits.LATA2 = (status & PLM_BYTE_SYNC_MASK) ? 1 : 0;
}

int main(void)
{
    /* Set the required DSP engine configuration
     *  - the other bits assumed to be in the default reset state.
     */
    CORCONbits.ACCSAT = 1;
    CORCONbits.SATA = 1;
    CORCONbits.SATB = 1;

#ifdef __dsPIC33F__
    /* We have 8MHz XTAL on Explorer16
     * Fvco = Fin * (PLLDIV+2) / (PLLPRE+2)
     * Fvco must be in the range 100..200 MHz
     * Fpfd = Fvco / (PLLDIV+2) must be in the range 0.8..8 MHz
     * Fosc = Fvco / (2*(PLLPOST+1))
     * Fcy  = Fosc / 2
     */
    //_PLLDIV = 78;   //80: 8MHz * (78+2) = 640MHz
    //_PLLPRE = 2;    // 4: Fvco = 640MHz / (2+2) = 160MHz, Fpfd = 2MHz
    //_PLLPOST = 0;   // 2: Fosc = 160MHz / 2 = 80MHz

    osc_set_pll(PLLPRE_4, PLLPOST_2, 80);
    osc_do_switch(OSCSEL_PRIPLL);

    while (!osc_switch_complete());
    while (!pll_has_lock());
#endif //__dsPIC33F__

    adc_set_all_digital();

    TRISAbits.TRISA0 = 0;
    LATAbits.LATA0 = 0;
    TRISAbits.TRISA1 = 0;
    LATAbits.LATA1 = 0;
    TRISAbits.TRISA2 = 0;
    LATAbits.LATA2 = 0;
    TRISAbits.TRISA3 = 0;
    LATAbits.LATA3 = 0;

    TRISGbits.TRISG0 = 0;
    LATGbits.LATG0 = 0;

    uart_setup();
    modem_setup();

    while (1)
    {
        uart_poll();
        modem_poll();
        show_led_status();
    }
}

