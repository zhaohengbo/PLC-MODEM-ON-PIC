/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-08-27 19:25:56 +0200 (Fri, 27 Aug 2010) $
 * $Revision: 82 $
 * $Author:   $
 */

/**
 * @file
 * Driver for HD44780-based LCDs.
 */

#ifndef __HD44780_H
#define __HD44780_H

#include <config.h>
#include <cpu/types.h>

#include <sys/timebase.h>

/** @name HD44780 addresses */
/*@{*/
#define HD44780_ADDR_LINE0 0x00
#define HD44780_ADDR_LINE1 0x40
/*@}*/

/** @name HD44780 commands */
/*@{*/
#define HD44780_CMD_CLEAR_DISP 0x01
#define HD44780_CMD_RETURN_HOME 0x02
#define HD44780_CMD_ENTRY_MODE_SET 0x04
#define HD44780_CMD_ON_OFF_CTRL 0x08
#define HD44780_CMD_SHIFT 0x10
#define HD44780_CMD_FUNC_SET 0x20
#define HD44780_CMD_SET_CGADDR 0x40
#define HD44780_CMD_SET_DDADDR 0x80
/*@}*/

/** A line of HD44780 data */
struct hd44780_line {
	/** Display data */
	char data[C_HD44780_CHARACTERS];
	/** Update flag */
	bool update;
};

/**
 * HD44780 states.
 */
typedef enum {
	HD44780_STATE_FUNC_SET,
	HD44780_STATE_ON_OFF_CTRL,
	HD44780_STATE_CLEAR_DISP,
	HD44780_STATE_ENTRY_MODE_SET,
	HD44780_STATE_CHECK_UPDATE_LINE0,
	HD44780_STATE_UPDATE_LINE0,
	HD44780_STATE_CHECK_UPDATE_LINE1,
	HD44780_STATE_UPDATE_LINE1
} hd44780_state_t;

/**
 * HD44780-based LCD controller. 
 */
struct hd44780 {
	/** Controller state */
	hd44780_state_t state;
	/** Internal timeout variable */
	jiffie_t timeout;
	/** Internal position pointer */
	uint16_t update_ptr;
	/** Framebuffer */
	struct hd44780_line lines[C_HD44780_LINES];
};

void hd44780_init(void);
bool hd44780_ready(void);
void hd44780_clear(void);
void hd44780_write(const char buf[], int pos, int len, int line);
void hd44780_poll(void);

#endif //__HD44780_H

