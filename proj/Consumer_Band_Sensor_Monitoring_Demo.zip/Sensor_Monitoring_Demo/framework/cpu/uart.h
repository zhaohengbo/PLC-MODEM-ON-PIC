/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-08-27 19:25:56 +0200 (Fri, 27 Aug 2010) $
 * $Revision: 82 $
 * $Author:   $
 */

/**
 * @file
 * Hardware UART support. 
 */

#ifndef __UART_H
#define __UART_H

#include <cpu/osc.h>

/** @name UART interfaces */
/*@{*/
#define U1 1
#define U2 2
/*@}*/

/**
 * Calculate BRG register content for a given baud rate. 
 * WARNING: if 'baud' is a variable you'll get division here
 */
#define uart_brg(baud) (((osc_get_fcy()/baud) / 16))

/** @name UART1 macros
 */
/*@{*/
#define uart1_set_baud_rate(baud) U1BRG = uart_brg(baud)
#define uart1_txbuf_full() (U1STAbits.UTXBF==1)
#define uart1_txbuf_empty() (U1STAbits.TRMT==1)
#define uart1_data_avail() (U1STAbits.URXDA==1)
#define uart1_tx(byte) U1TXREG = byte
#define uart1_rx() U1RXREG
#define uart1_off() (U1MODEbits.UARTEN = 0)
#define uart1_on() (U1MODEbits.UARTEN = 1)
#define uart1_tx_disable() (U1STAbits.UTXEN = 0)
#define uart1_tx_enable() (U1STAbits.UTXEN = 1)

#define uart1_parity_err() (U1STAbits.PERR == 1)
#define uart1_framing_err() (U1STAbits.FERR == 1)
#define uart1_overrun_err() (U1STAbits.OERR == 1)

#define uart1_clear_overrun_flag() (U1STAbits.OERR = 0)
/*@}*/

/** @name UART2 macros
 */
/*@{*/
#define uart2_set_baud_rate(baud) U2BRG = uart_brg(baud)
#define uart2_txbuf_full() (U2STAbits.UTXBF==1)
#define uart2_txbuf_empty() (U2STAbits.TRMT==1)
#define uart2_data_avail() (U2STAbits.URXDA==1)
#define uart2_tx(byte) U2TXREG = byte
#define uart2_rx() U2RXREG
#define uart2_off() (U2MODEbits.UARTEN = 0)
#define uart2_on() (U2MODEbits.UARTEN = 1)
#define uart2_tx_disable() (U2STAbits.UTXEN = 0)
#define uart2_tx_enable() (U2STAbits.UTXEN = 1)

#define uart2_parity_err() (U2STAbits.PERR == 1)
#define uart2_framing_err() (U2STAbits.FERR == 1)
#define uart2_overrun_err() (U2STAbits.OERR == 1)

#define uart2_clear_overrun_flag() (U2STAbits.OERR = 0)
/*@}*/

/** @name UxMODE register bits. */
/*@{*/
/** Uart module enable/disable */
#define UART_UARTEN 0x8000
/** Stop or run when CPU is in IDLE mode */
#define UART_USIDL 0x2000
/** Use UxARX and UxATX instead of UxRX and UxTX */
#define UART_ALTIO 0x0400
/** Enable or disable wake-up on START bit */
#define UART_WAKE 0x0080
/** Loopback mode enable/disable */
#define UART_LPBACK 0x0040
/**
 * ABAUD : Automatic baud rate detection (using capture module). 
 * When on, then UxRX signal is routed to the Capture module input. 
 */
#define UART_ABAUD 0x0020
/** Stop bits configuration */
#define UART_STSEL 0x0001
/** Parity and word length configuration */
#define UART_PDSEL 0x0006
/*@}*/

/** @name UxMODE defines. 
 * Constants should be or'ed together. 
 */
/*@{*/
/** Uart module is enabled */
#define UART_ENABLED UART_UARTEN
/** Uart module is disabled */
#define UART_DISABLED 0x0000

/** The module stops when CPU idles */
#define UART_STOP_IDLE UART_USIDL
/** The module continues to run when CPU idles */
#define UART_RUN_IDLE 0x0000

/** Uart operates on alternate pins */
#define UART_USE_ALTIO UART_ALTIO
/** Uart operates on default pins */
#define UART_USE_DEFAULT 0x0000

/** Wake-up on START bit enabled */
#define UART_WAKE_EN UART_WAKE
/** Wake-up on START bit disabled */
#define UART_WAKE_DIS 0x0000

/** Loopback mode activated */
#define UART_LOOPBACK UART_LPBACK
/** Loopback mode not activated */
#define UART_NO_LOOPBACK 0x0000

/** Autobaud enabled - UxRX is routed to the Capture module input */
#define UART_ABAUD_ON UART_ABAUD
/** Autobaud disabled */
#define UART_ABAUD_OFF 0x0000
/** Uart uses one stop bit */

#define UART_ONE_STOP 0x0000
/** Uart uses two stop bits */
#define UART_TWO_STOP 0x0001

/** Uart uses 9-bit word, no parity */
#define UART_9N 0x0006
/** Uart uses 8-bit word, odd parity */
#define UART_8O 0x0004
/** Uart uses 8-bit word, even parity */
#define UART_8E 0x0002
/** Uart uses 8-bit word, no parity */
#define UART_8N 0x0000

#define UART_9N2 0x0007	 ///< 9 data bits, no parity, 2 stop bits
#define UART_9N1 0x0006	 ///< 9 data bits, no parity, 1 stop bit
#define UART_8O2 0x0005	 ///< 8 data bits, odd parity, 2 stop bits
#define UART_8O1 0x0004	 ///< 8 data bits, odd parity, 1 stop bit
#define UART_8E2 0x0003	 ///< 8 data bits, even parity, 2 stop bits
#define UART_8E1 0x0002	 ///< 8 data bits, even parity, 1 stop bit
#define UART_8N2 0x0001	 ///< 8 data bits, no parity, 2 stop bits
#define UART_8N1 0x0000	 ///< 8 data bits, no parity, 1 stop bit
/*@}*/

/** @name UxSTA register bits. */
/*@{*/
/** Uart TX interrupt configuration. */
#define UART_UTXISEL 0x8000
/** 
 * BREAK generation. If activated, then UxTX pin is driven low, 
 * regardless of transmitter state. 
 */
#define UART_UTXBRK 0x0800
/** Enable or disable the UART transmitter. */
#define UART_UTXEN 0x0400
/** Uart RX interrupt generation. */
#define UART_URXISEL 0x00C0
/** 
 * Address Detect mode enable/disable. This mode may be activated 
 * in 9-bit modes only. 
 */
#define UART_ADDEN 0x0020
/*@}*/

/** @name UxSTA defines. 
 * Constants should be or'ed together.  
 */
/*@{*/
/**
 * Interrupt when a character is transferred to the Transmit Shift register 
 * and as result, the transmit buffer becomes empty. 
 */
#define UART_INT_TX_EMPTY UART_UTXISEL
/** 
 * Interrupt when a character is transferred to the Transmit Shift register 
 * (this implies that there is at least one character open in the transmit 
 * buffer). 
 */
#define UART_INT_TX_1WORD 0x0000

/** UxTX pin driven low - break generation */
#define UART_TX_LOW UART_UTXBRK
/** UxTX pin operates normally */
#define UART_TX_NORMAL 0x0000

/** Uart transmitter enabled */
#define UART_TX_EN UART_UTXEN
/** Uart transmitter disabled */
#define UART_TX_DIS 0x0000

/** Interrupt flag bit is set when Receive Buffer is full */
#define UART_INT_RX_4WORD 0x00C0
/** Interrupt flag bit is set when Receive Buffer is 3/4 full */
#define UART_INT_RX_3WORD 0x0080
/** Interrupt flag bit is set when a character is received */
#define UART_INT_RX_1WORD 0x0000

/** Address detection enabled */
#define UART_ADDR_DET UART_ADDEN
/** Address detection disabled */
#define UART_NO_ADDR_DET 0x0000
/*@}*/

#endif //__UART_H

