/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-11-05 16:48:49 +0100 (Fri, 05 Nov 2010) $
 * $Revision: 88 $
 * $Author:   $
 */

/**
 * @file
 * Software power line modem implementing the 'bdev' interface. 
 */

#include <config.h>
#include <string.h>
#include <common/plm.h>
#include <net/nbuf.h>
#include <net/bdev.h>
#include <net/bdev/sw_plm.h>

/* Single static instance of the modem */
static struct sw_plm modem;

/* Interface method called by the higher protocol instance to transmit. 
 * Must not be called when BF flag is set. 
 */
static void xmit_method(struct bdev *dev, struct npage *page)
{
    if (!page)
    {
        return;
    }

    plm_xmit(&page->data[page->start], page->end - page->start);

    if (modem.txpage[0] != NULL)
    {
        npage_deref(modem.txpage[0]);
    }

    modem.txpage[0] = modem.txpage[1];
    modem.txpage[1] = page;
}

/* Interface method called by the higher protocol instance to receive. 
 */
static struct npage *recv_method(struct bdev *dev)
{
    uint8_t *end_ptr;

    struct npage *newpage;
    struct npage *oldpage;

    newpage = npage_pool_get();
    oldpage = modem.rxpage;
    modem.rxpage = newpage;

    if (newpage != NULL)
    {
        end_ptr = plm_recv(newpage->data, C_NET_NPAGE_SIZE);
    }
    else
    {
        end_ptr = plm_recv(NULL, 0);
    }

    if (oldpage != NULL)
    {
        oldpage->start = 0;
        if (end_ptr > oldpage->data)
        {
            oldpage->end = end_ptr - oldpage->data;
        }
        else
        {
            oldpage->end = 0;
        }
    }
    return oldpage;
}

/* Interface method called by the higher protocol to check status. 
 */
static uint16_t status_method(struct bdev *dev)
{
    uint16_t plm_status = plm_get_status();
    uint16_t bdev_status = 0;

#if PLM_QUALITY_MEASURE == ENABLED
    bdev_status = plm_quality() & 0xff00;
#endif //PLM_QUALITY_MEASURE

    if (plm_status & PLM_TX_ACTIVE_MASK)
    {
        bdev_status |= BDEV_STATUS_TX;
    }
    if (plm_status & PLM_TX_BF_MASK)
    {
        bdev_status |= BDEV_STATUS_TX_BF;
    }
    if (plm_status & PLM_BYTE_SYNC_MASK)
    {
        bdev_status |= BDEV_STATUS_RX;
    }
    return bdev_status;
}

/* Public API */

/**
 * Initialize the modem. 
 * This function has to be called before any other API functions are used. 
 */
void sw_plm_init(void)
{
    //memset(&modem, 0, sizeof(modem));

    modem.rxpage = NULL;
    modem.txpage[0] = NULL;
    modem.txpage[1] = NULL;

    bdev_init(&modem.dev, xmit_method, recv_method, status_method);
}

/**
 * Start the modem. 
 */
void sw_plm_start(void)
{
    plm_demod_start();
    plm_mod_start();
}

/**
 * Poll the modem. 
 */
void sw_plm_poll(void)
{
    uint16_t plm_status = plm_get_status();

    if ((plm_status & (PLM_TX_ACTIVE_MASK | PLM_TX_BF_MASK)) == 0)
    {
        if (modem.txpage[0])
        {
            npage_deref(modem.txpage[0]);
        }
        modem.txpage[0] = modem.txpage[1];
        modem.txpage[1] = NULL;
    }
}

/**
 * Get a modem handle. 
 * @return Address of the modem's 'bdev' structure. 
 */
struct bdev *sw_plm_get_handle(void)
{
    return &modem.dev;
}

