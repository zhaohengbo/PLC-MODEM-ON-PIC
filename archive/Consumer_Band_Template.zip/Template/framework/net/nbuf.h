/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-11-05 16:48:49 +0100 (Fri, 05 Nov 2010) $
 * $Revision: 88 $
 * $Author:   $
 */

/** 
 * @file
 * Network buffers. 
 */

#ifndef __NBUF_H
#define __NBUF_H

#include <config.h>
#include <cpu/types.h>

#include <util/crc16.h>

/**
 * Net page. 
 * The system disposes of a pool of net pages, that are the sole buffering
 * media for network packets. Net pages should be kept rather small. Larger
 * packets will consist of a number of net pages linked together. 
 * When a module needs to access a net page, it should reference it by 
 * a call to npage_ref(). When the page data is no longer needed, the module
 * should dereference the page (a call to npage_deref()). The page will be
 * returned to the pool of free pages when its reference count goes back to 
 * zero. 
 * 
 * 'start' and 'end' markers can be used when net pages are used directly,
 * without using the net buffer API. The net buffer API functions neither
 * set nor read these markers, except for the 'nbuf_fwd_read_page()'. 
 */
struct npage {
	/** Reference count */
	uint16_t ref;
	/** Next page in the linked list */
	struct npage *next;
	/** Previous page in the linked list */
	struct npage *prev;
	/** Start of data marker */
	uint16_t start;
	/** End of data marker */
	uint16_t end;
	/** Data buffer */
	uint8_t data[C_NET_NPAGE_SIZE];
};

/**
 * A queue of net pages. 
 */
struct npage_queue {
	/** First member in the queue */
	struct npage *head;
	/** Last member in the queue */
	struct npage *tail;
};

/** 
 * Network buffer. 
 * Network buffers correspond to single network packets or frames. Every 
 * buffer can contain one or more network pages that hold packet data. 
 * When a module needs to access a net buffer, it should reference it by 
 * a call to nbuf_ref(). When the buffer data is no longer needed, the module
 * should dereference the buffer (a call to nbuf_deref()). The buffer will
 * returned to the pool of free buffers when its reference count goes back to 
 * zero. 
 */
struct nbuf {
	/** Reference count */
	uint16_t ref;
	/** Previous buffer in a queue */
	struct nbuf *next;
	/** Next buffer in a queue */
	struct nbuf *prev;
	/** Queue of network pages linked to this buffer */
	struct npage_queue pages;
	/** Current page. Must match the current buffer position */
	struct npage *current;
	/** Current buffer position */
	uint16_t pos;
	/** Marker pointing to the first valid data byte */
	uint16_t start;
	/** Marker pointing to the byte after the last valid data byte */
	uint16_t end;
	/** Total buffer size (space) */
	uint16_t size;
	#if C_NET_METADATA_WORDS > 0
	/** Meta data for protocol-specific use */
	uint16_t meta[C_NET_METADATA_WORDS];
	#endif //C_NET_METADATA_WORDS
};

/**
 * Queue of net buffers. 
 */
struct nbuf_queue {
	/** First member in the queue */
	struct nbuf *head;
	/** Last member in the queue */
	struct nbuf *tail;
};

/**
 * Pool of net pages. 
 * Typically there will be just one in the system. 
 */
struct npage_pool {
	/** Next page to access */
	uint16_t index;
	/** Remaining pages */
	uint16_t remain;
	/** Table of all pages */
	struct npage pages[C_NET_NPAGE_POOL];
};

/**
 * Pool of net buffers. 
 * Typically there will be just one in the system. 
 */
struct nbuf_pool {
	/** Next buffer to access */
	uint16_t index;
	/** Remaining buffers */
	uint16_t remain;
	/** Table of all buffers */
	struct nbuf bufs[C_NET_NBUF_POOL];
};

void net_pools_init(void);
bool npage_pool_lw(void);
bool nbuf_pool_lw(void);

void npage_init(struct npage *page);
struct npage *npage_pool_get(void);
void npage_ref(struct npage *page);
void npage_deref(struct npage *page);

void npage_enqueue_head(struct npage_queue *queue, struct npage *page);
void npage_enqueue_tail(struct npage_queue *queue, struct npage *page);
struct npage *npage_dequeue_head(struct npage_queue *queue);
struct npage *npage_dequeue_tail(struct npage_queue *queue);

void nbuf_init(struct nbuf *buf);
struct nbuf *nbuf_pool_get(void);
struct nbuf *nbuf_pool_get_lw(void);
struct nbuf *nbuf_pool_get_with_offs(uint16_t offs);
struct nbuf *nbuf_pool_get_with_offs_lw(uint16_t offs);
void nbuf_ref(struct nbuf *buf);
void nbuf_deref(struct nbuf *buf);

struct nbuf *nbuf_copy(struct nbuf *buf);
struct nbuf *nbuf_clone(struct nbuf *buf);

bool nbuf_fwd_make_space(struct nbuf *buf, uint16_t count);
bool nbuf_fwd_make_space_lw(struct nbuf *buf, uint16_t count);
void nbuf_fwd_write(struct nbuf *buf, uint8_t *data, uint16_t count);
void nbuf_fwd_move(struct nbuf *buf, uint16_t count);
void nbuf_fwd_write_byte(struct nbuf *buf, uint8_t byte);
void nbuf_fwd_write_word(struct nbuf *buf, uint16_t word);

bool nbuf_rev_make_space(struct nbuf *buf, uint16_t count);
bool nbuf_rev_make_space_lw(struct nbuf *buf, uint16_t count);
void nbuf_rev_write(struct nbuf *buf, uint8_t *data, uint16_t count);
void nbuf_rev_move(struct nbuf *buf, uint16_t count);
void nbuf_rev_write_byte(struct nbuf *buf, uint8_t byte);
void nbuf_rev_write_word(struct nbuf *buf, uint16_t word);

struct npage *nbuf_fwd_read_page(struct nbuf *buf);
bool nbuf_fwd_read(struct nbuf *buf, uint8_t *data, uint16_t count);
uint8_t nbuf_fwd_read_byte(struct nbuf *buf);
uint16_t nbuf_fwd_read_word(struct nbuf *buf);

bool nbuf_rev_read(struct nbuf *buf, uint8_t *data, uint16_t count);
uint8_t nbuf_rev_read_byte(struct nbuf *buf);
uint16_t nbuf_rev_read_word(struct nbuf *buf);

void nbuf_set_pos_to_start(struct nbuf *buf);
void nbuf_set_pos_to_end(struct nbuf *buf);
void nbuf_cut_head(struct nbuf *buf);
void nbuf_cut_tail(struct nbuf *buf);
void nbuf_final(struct nbuf *buf);

void nbuf_enqueue_head(struct nbuf_queue *queue, struct nbuf *buf);
void nbuf_enqueue_tail(struct nbuf_queue *queue, struct nbuf *buf);
struct nbuf *nbuf_dequeue_head(struct nbuf_queue *queue);
struct nbuf *nbuf_dequeue_tail(struct nbuf_queue *queue);

void nbuf_queue_release(struct nbuf_queue *queue);

/** Calculate 16-bit ITUT CRC of a net buffer */
#define NBUF_CRC16_CALC(buf, key) nbuf_crc16(buf, key, 0)
/** Check if 'chksum' is a valid 16-bit ITUT CRC of 'msg' */
#define NBUF_CRC16_CHECK(buf, key, chksum) (nbuf_crc16(buf, key, chksum)==0)

uint16_t nbuf_crc16(struct nbuf *buf, uint16_t key, uint16_t chksum);

void nbuf_dump(struct nbuf *buf);
void npage_dump(struct npage *page);

#endif //__NBUF_H

