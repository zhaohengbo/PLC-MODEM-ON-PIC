/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-10-22 16:00:58 +0200 (Fri, 22 Oct 2010) $
 * $Revision: 85 $
 * $Author:   $
 */

#include <stdlib.h>
#include <string.h>

#include <config.h>
#include <cpu/adc.h>
#include <cpu/cpu.h>
#include <cpu/types.h>
#include <cpu/int.h>
#include <cpu/osc.h>
#include <drv/hd44780.h>
#include <libs/num2str.h>
#include <util/crc16.h>

#include <common/plm.h>

#define DEBUG_CONTEXT MAIN
#include <sys/debug.h>
#include <sys/timebase.h>

#include "payload.h"

#ifdef __dsPIC33F__
/** Primary oscillator is XT, switching is enabled, monitor is disabled */
_FOSC(FCKSM_CSECMD & OSCIOFNC_OFF & POSCMD_XT);
/** Start from the internal Fast RC clock */
_FOSCSEL(FNOSC_FRC & IESO_OFF);
/** Maximum power-up timer delay */
_FPOR(FPWRT_PWR128);
/** WDT by default is off, may be turned on with RCON.SWDTEN, 512 ms timeout */
_FWDT(FWDTEN_OFF & WINDIS_OFF & WDTPRE_PR32 & WDTPOST_PS512);
/** No Boot Sector */
_FBS(RBS_NO_RAM & BSS_NO_FLASH & BWRP_WRPROTECT_OFF);
/** No Secure Segment */
_FSS(RSS_NO_RAM & SSS_NO_FLASH & SWRP_WRPROTECT_OFF);
/** No code protection */
_FGS(GSS_OFF & GCP_OFF & GWRP_OFF);
#endif //__dsPIC33F__

#if 0
#define BUF_LEN 2048
uint16_t buf[BUF_LEN];
uint16_t bufptr = 0;

void buf_add(uint16_t sample)
{
    buf[bufptr++ & 0x7ff] = sample;
    buf[bufptr & 0x7ff] = 0xdead;
}
#endif //0

/* Data block to transmit */
static uint8_t packet[PACKET_SIZE];

/* Packet counter */
static uint16_t txcount = 0;

/* Packet transmission timeout */
#if PLM_FEC == DISABLED
#define TXINTERVAL (((1000ul*8*(PACKET_SIZE+64))/PLM_BAUD)*J_MSEC)
#else
#define TXINTERVAL (((1000ul*16*(PACKET_SIZE+64))/PLM_BAUD)*J_MSEC)
#endif //PLM_FEC

static jiffie_t txtimeout = 0;

/* Push button servicing */

/* For how long a button should ignore events after an accepted event */
#define BUTTON_TIMEOUT (250*J_MSEC)

/* Buttons that need attention */
static struct
{
    int but0 : 1;
    int but1 : 1;
    //	int but2:1;
    int but3 : 1;
} buttons;

/* Button event timeouts */
static jiffie_t but0_timeout;
static jiffie_t but1_timeout;
//static jiffie_t but2_timeout;
static jiffie_t but3_timeout;

/* Start buttons */
static void buttons_start(void)
{
    TRISDbits.TRISD6 = 1; //button 0
    TRISDbits.TRISD7 = 1; //button 1
    //TRISAbits.TRISA7 = 1;  //button 2 (don't use, weird)
    TRISDbits.TRISD13 = 1; //button 3
}

/* Button actions */
static void button0_action(void);
static void button1_action(void);
//static void button2_action(void);
static void button3_action(void);

/* Poll buttons */
static void buttons_poll(void)
{
    if (time_after(but0_timeout))
    {
        if (PORTDbits.RD6 == 0)
        {
            buttons.but0 = 1;
        }
        but0_timeout = time_get_timeout(20 * J_MSEC);
    }
    if (time_after(but1_timeout))
    {
        if (PORTDbits.RD7 == 0)
        {
            buttons.but1 = 1;
        }
        but1_timeout = time_get_timeout(20 * J_MSEC);
    }
    /*
    if (time_after(but2_timeout)) {
            if (PORTAbits.RA7 == 0) {
                    buttons.but2 = 1;
            }
            but2_timeout = time_get_timeout(20*J_MSEC);
    }
     */
    if (time_after(but3_timeout))
    {
        if (PORTDbits.RD13 == 0)
        {
            buttons.but3 = 1;
        }
        but3_timeout = time_get_timeout(20 * J_MSEC);
    }

    if (buttons.but0)
    {
        button0_action();
        buttons.but0 = 0;
        but0_timeout = time_get_timeout(BUTTON_TIMEOUT);
    }
    if (buttons.but1)
    {
        button1_action();
        buttons.but1 = 0;
        but1_timeout = time_get_timeout(BUTTON_TIMEOUT);
    }
    /*
    if (buttons.but2) {
            //button2_action();
            buttons.but2 = 0;
            but2_timeout = time_get_timeout(BUTTON_TIMEOUT);
    }
     */
    if (buttons.but3)
    {
        button3_action();
        buttons.but3 = 0;
        but3_timeout = time_get_timeout(BUTTON_TIMEOUT);
    }
}

/* LED servicing */

/* Start LEDs */
static void leds_start(void)
{
    TRISAbits.TRISA0 = 0;
    LATAbits.LATA0 = 0;
    TRISAbits.TRISA1 = 0;
    LATAbits.LATA1 = 0;
    TRISAbits.TRISA2 = 0;
    LATAbits.LATA2 = 0;
    TRISAbits.TRISA3 = 0;
    LATAbits.LATA3 = 0;
}

/* Show modem status on LEDs */
static void leds_show_status(void)
{
    uint16_t status = plm_get_status();
    LATAbits.LATA0 = (status & PLM_TX_ACTIVE_MASK) ? 1 : 0;
    LATAbits.LATA1 = (status & PLM_BYTE_SYNC_MASK) ? 1 : 0;
    LATAbits.LATA2 = (status & PLM_BIT_SYNC_MASK) ? 1 : 0;
}


/* LCD servicing */

/* LCD views. Switched with a button press */
typedef enum
{
    LCD_VIEW_COUNTER,
    LCD_VIEW_INFO,
    LCD_VIEW_NONE
} lcd_view_t;

/* Current LCD view */
static lcd_view_t lcd_view = LCD_VIEW_COUNTER;

/* Time to elapse before the LCD is refreshed */
static jiffie_t lcd_update_tout = 0;

/* Show counter on the LCD  */
static void lcd_show_counter(void)
{
    char buf[5];

    if (!time_after(lcd_update_tout))
    {
        return;
    }
    lcd_update_tout = time_get_timeout(20 * J_MSEC);

    //-------------0123456789abcdef
    hd44780_write("TX:             ", 0, 16, 0);
    hd44780_write("                ", 0, 16, 1);

    u16_to_str_fixed(buf, sizeof (buf), txcount % 10000);
    hd44780_write(buf, 0, 4, 1);
}

#define STRINGIFY(s) #s

#if PLM_FEC==ENABLED
#define UART_FEC " FEC"
#define LCD_FEC " E"
#else
#define UART_FEC
#define LCD_FEC
#endif //PLM_FEC

#if PLM_SCHEME == MS_BFSK
#define UART_INF_SCHEME(fcarrier, baud) \
	"Using BFSK, " STRINGIFY(baud) " bps @ " \
	STRINGIFY(fcarrier) " Hz" UART_FEC "\r\n"
#endif //PLM_SCHEME
#if PLM_SCHEME == MS_BPSK
#define UART_INF_SCHEME(fcarrier, baud) \
	"Using BPSK, " STRINGIFY(baud) " bps @ " \
	STRINGIFY(fcarrier) " Hz" UART_FEC "\r\n"
#endif //PLM_SCHEME

#define UART_INF_FRAME(size) \
	"Sending " STRINGIFY(size) " byte frames\r\n"
#define UART_INF_PREAMBLE(size) \
	" - PREAMBLE: " STRINGIFY(size) "\r\n"
#define UART_INF_DATA(size) \
	" - DATA    : " STRINGIFY(size) "\r\n"
#define UART_INF_CRC(size) \
	" - CRC     : " STRINGIFY(size) "\r\n"

#define LCD_INF0(fcarrier) "TX, Fc = " STRINGIFY(fcarrier)

#if PLM_SCHEME == MS_BPSK
#define LCD_INF1(baud) ("BPSK, " STRINGIFY(baud) " bps" LCD_FEC)
#endif //PLM_SCHEME
#if PLM_SCHEME == MS_BFSK
#define LCD_INF1(baud) ("BFSK, " STRINGIFY(baud) " bps" LCD_FEC)
#endif //PLM_SCHEME

/* Show application information on the LCD */
static void lcd_show_info(void)
{
    if (!time_after(lcd_update_tout))
    {
        return;
    }
    lcd_update_tout = time_get_timeout(20 * J_MSEC);

    //-------------0123456789abcdef
    hd44780_clear();
    hd44780_write(LCD_INF0(PLM_FC), 0, sizeof (LCD_INF0(PLM_FC)) - 1, 0);
    hd44780_write(LCD_INF1(PLM_BAUD), 0, sizeof (LCD_INF1(PLM_BAUD)) - 1, 1);
}

/* Select what to print depending on the current LCD view */
static void lcd_poll(void)
{
    switch (lcd_view)
    {
    case LCD_VIEW_COUNTER:
        lcd_show_counter();
        break;
    case LCD_VIEW_INFO:
    default:
        lcd_show_info();
        break;
    };
}

/* Poll MODEM reception */
static void modem_poll_rx(void)
{
}

/* Poll MODEM transmission */
static void modem_poll_tx(void)
{
    char buf[5];

    if (plm_get_status() & PLM_TX_BF_MASK)
    {
        return;
    }

    if (!time_after(txtimeout))
    {
        return;
    }
    txtimeout = time_get_timeout(TXINTERVAL);

    /* Sometimes it may be useful to stop after a given number of packets */
    /*
    if (txcount >= 500) {
            return;
    }
     */

    DEBUG_INFO("*");
    txcount++;
    if ((txcount & 0xf) == 0)
    {
        DEBUG_INFO(" ");
        DEBUG_INFO(u16_to_str_fixed(buf, 5, txcount % 10000));
        DEBUG_INFO("\r\n");
    }

    plm_xmit(packet, PACKET_SIZE);
}

/* Button actions */

static void button0_action(void)
{
    lcd_view++;
    if (lcd_view >= LCD_VIEW_NONE)
    {
        lcd_view = 0;
    }
    hd44780_clear();
    lcd_update_tout = time_now();
}

static void button1_action(void)
{
    if (lcd_view == 0)
    {
        lcd_view = LCD_VIEW_NONE;
    }
    lcd_view--;

    hd44780_clear();
    lcd_update_tout = time_now();
}

/*
static void button2_action(void)
{
}
 */

static void button3_action(void)
{
    txcount = 0;
}

int main(void)
{
#ifdef INT_USE_AIVT
    _ALTIVT = 1;
#else
    _ALTIVT = 0;
#endif //
    int_global_enable();

    /* Set the required DSP engine configuration
     *  - the other bits assumed to be in the default reset state.
     */
    CORCONbits.ACCSAT = 1;
    CORCONbits.SATA = 1;
    CORCONbits.SATB = 1;

#ifdef __dsPIC33F__
    /* We have 8MHz XTAL on Explorer16
     * Fvco = Fin * (PLLDIV+2) / (PLLPRE+2)
     * Fvco must be in the range 100..200 MHz
     * Fpfd = Fvco / (PLLDIV+2) must be in the range 0.8..8 MHz
     * Fosc = Fvco / (2*(PLLPOST+1))
     * Fcy  = Fosc / 2
     */
    //_PLLDIV = 78;   //80: 8MHz * (78+2) = 640MHz
    //_PLLPRE = 2;    // 4: Fvco = 640MHz / (2+2) = 160MHz, Fpfd = 2MHz
    //_PLLPOST = 0;   // 2: Fosc = 160MHz / 2 = 80MHz

    osc_set_pll(PLLPRE_4, PLLPOST_2, 80);
    osc_do_switch(OSCSEL_PRIPLL);

    while (!osc_switch_complete());
    while (!pll_has_lock());
#endif //__dsPIC33F__

    adc_set_all_digital();

    debug_init();
    timebase_init();
    hd44780_init();

    timebase_start();

    buttons_start();
    leds_start();

    plm_demod_start();
    plm_mod_start();

    /* Prepare stuff to send */
    packet_fill(packet);

    DEBUG_INFO("\r\nTransmitter started!\r\n");
    DEBUG_INFO(UART_INF_SCHEME(PLM_FC, PLM_BAUD));
    DEBUG_INFO(UART_INF_FRAME(PACKET_SIZE));
    DEBUG_INFO(UART_INF_PREAMBLE(PRE_SIZE));
    DEBUG_INFO(UART_INF_DATA(DATA_SIZE));
    DEBUG_INFO(UART_INF_CRC(2));

    while (1)
    {
        /* Poll background tasks */
        hd44780_poll();

        modem_poll_rx();
        modem_poll_tx();

        /* Poll top level threads */
        buttons_poll();
        leds_show_status();

        lcd_poll();
    }
}

