/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-11-05 16:48:49 +0100 (Fri, 05 Nov 2010) $
 * $Revision: 88 $
 * $Author:   $
 */

/** 
 * @file
 * Trivial Media Access Protocol Device. 
 */

#include <config.h>
#include <string.h>
#include <net/net.h>
#include <net/bdev.h>
#include <net/proto/tmap.h>

#define DEBUG_CONTEXT TMAP
#include <sys/debug.h>

/* Public API */

/**
 * Initialize a TMAP Device. 
 * This function has to be called before any other API functions are used. 
 * @param dev Device instance to initialize
 * @param mac Device MAC address
 */
void tmap_init(struct tmap_dev *dev, uint16_t mac)
{
    memset(dev, 0, sizeof (struct tmap_dev));
    dev->my_mac = mac;
}

/**
 * Start a TMAP Device. 
 * This function does not start the interface, it should be started by 
 * the caller. 
 * @param dev Device to start
 * @param interface Buffered device used for communications
 */
void tmap_start(struct tmap_dev *dev, struct bdev *interface)
{
    dev->interface = interface;
    dev->rx_state = TMAP_RX_SEEK_PRE;
}

/**
 * Set flags on a TMAP Device. 
 * @param dev Device to modify
 * @param flags New flag state
 */
void tmap_set_flags(struct tmap_dev *dev, uint16_t flags)
{
    dev->iflags = flags;
}

/**
 * Stop a TMAP Device.
 * This function discards all queued packets and disconnects from 
 * the underlying buffered device. It does not stop the buffered interface. 
 * @param dev Device to stop
 */
void tmap_stop(struct tmap_dev *dev)
{
    dev->interface = NULL;

    nbuf_queue_release(&dev->tx_queue);
    nbuf_queue_release(&dev->rx_queue);
}

/* Finish frame reception */
static void rx_frame_finish(struct tmap_dev *dev, struct nbuf *nb)
{
    struct nbuf *copy;
    uint16_t reallen;
    uint16_t fcs, dmac, smac;

#if C_TMAP_DEBUG_LEVEL >= DEBUG_LEVEL_VERBOSE
    DEBUG_VERBOSE("\r\ntmap: RX nbuf:\r\n");
    nbuf_dump(nb);
#endif //C_TMAP_DEBUG_LEVEL

    reallen = nb->end - nb->start;
    if (reallen < TMAP_OVERHEAD)
    {
        DEBUG_INFO("tmap: frame too short\r\n");
        NET_STATS_RX_FRAME_ERROR(dev->stats);
        nbuf_deref(nb);
        return;
    }
    /* Buffer position is at the end (guaranteed by rx_process_byte())
     * and we verified that at least 9 bytes can be read.
     */
    fcs = NTOH16(nbuf_rev_read_word(nb));

    /* Strip FCS */
    nbuf_cut_tail(nb);
    nbuf_set_pos_to_start(nb);

    if (!NBUF_CRC16_CHECK(nb, CRC16_ITUT_POLY, fcs))
    {
        DEBUG_INFO("tmap: bad FCS\r\n");
        NET_STATS_RX_FRAME_ERROR(dev->stats);
        nbuf_deref(nb);
        return;
    }

    /* We are at the end again, due to nbuf_crc16() */
    nbuf_set_pos_to_start(nb);
    nbuf_fwd_move(nb, 3);
    smac = NTOH16(nbuf_fwd_read_word(nb));
    dmac = NTOH16(nbuf_fwd_read_word(nb));
    nbuf_set_pos_to_start(nb);

    if (smac == dev->my_mac)
    {
        DEBUG_VERBOSE("tmap: own frame received OK\r\n");
        nbuf_deref(nb);
        return;
    }

    if (dmac != dev->my_mac)
    {
        DEBUG_VERBOSE("tmap: frame for someone else\r\n");
        if (dev->iflags & TMAP_FLAG_REPEATER)
        {
            DEBUG_VERBOSE("tmap: resending frame\r\n");
            if (dev->iflags & TMAP_FLAG_PROMISC)
            {
                copy = nbuf_copy(nb);
                if (copy)
                {
                    tmap_resend(dev, copy);
                }
                nbuf_deref(copy);
            }
            else
            {
                tmap_resend(dev, nb);
            }
        }
        if (dev->iflags & TMAP_FLAG_PROMISC)
        {
            DEBUG_VERBOSE("tmap: receiving in PROMISC\r\n");
        }
        else
        {
            nbuf_deref(nb);
            return;
        }
    }

    NET_STATS_RX_PACKET(dev->stats);
    nbuf_set_pos_to_start(nb);
    nbuf_enqueue_tail(&dev->rx_queue, nb);
}

/* Process the next byte received */
static void rx_process_byte(struct tmap_dev *dev, uint8_t rx)
{
    //DEBUG_VERBOSE_U8(rx);

    switch (dev->rx_state)
    {
    case TMAP_RX_SEEK_PRE:
        if (rx == TMAP_PREAMBLE)
        {
            dev->rx_state = TMAP_RX_SEEK_SOF;
        }
        break;
    case TMAP_RX_SEEK_SOF:
        if (rx == TMAP_SOF)
        {
            DEBUG_INFO("tmap: frame RX started\r\n");
            dev->rx_nb = nbuf_pool_get_lw();
            if (dev->rx_nb == NULL)
            {
                DEBUG_WARN("tmap: cannot start frame\r\n");
                NET_STATS_RX_DROPPED(dev->stats);
                dev->rx_state = TMAP_RX_SEEK_PRE;
                break;
            }
            /* Make space for SOF and LEN */
            if (!nbuf_fwd_make_space_lw(dev->rx_nb, 2))
            {
                DEBUG_WARN("tmap: dropping frame\r\n");
                NET_STATS_RX_DROPPED(dev->stats);
                nbuf_deref(dev->rx_nb);
                dev->rx_nb = NULL;
                dev->rx_state = TMAP_RX_SEEK_PRE;
                break;
            }
            nbuf_fwd_write_byte(dev->rx_nb, rx);
            dev->rx_state = TMAP_RX_LEN;
        }
        else if (rx != TMAP_PREAMBLE)
        {
            dev->rx_state = TMAP_RX_SEEK_PRE;
        }
        break;
    case TMAP_RX_LEN:
        /* Make space for entire expected packet */
        nbuf_fwd_write_byte(dev->rx_nb, rx);
        if (!nbuf_fwd_make_space_lw(dev->rx_nb, rx - 2))
        {
            DEBUG_WARN("tmap: dropping frame\r\n");
            NET_STATS_RX_DROPPED(dev->stats);
            nbuf_deref(dev->rx_nb);
            dev->rx_nb = NULL;
            dev->rx_state = TMAP_RX_SEEK_PRE;
            break;
        }
        dev->rx_remain = rx - 2;
        dev->rx_state = TMAP_RX_FRAME_DATA;
        break;
    case TMAP_RX_FRAME_DATA:
    default:
        nbuf_fwd_write_byte(dev->rx_nb, rx);
        if (--dev->rx_remain == 0)
        {
            DEBUG_INFO("tmap: frame RX complete\r\n");
            rx_frame_finish(dev, dev->rx_nb);
            dev->rx_nb = NULL;
            dev->rx_state = TMAP_RX_SEEK_PRE;
        }
        break;
    }
}

/**
 * Poll a TMAP Device. 
 * This function must be executed periodically, often enough so that
 * receive buffers don't overflow and transmit buffers don't get empty in 
 * the middle of a packet.
 * 
 * @param dev Device to poll
 */
void tmap_poll(struct tmap_dev *dev)
{
    struct npage *page;
    uint16_t status;
    int i;

    if (dev->interface == NULL)
    {
        return;
    }

    /* Order matters */
    status = dev->interface->status(dev->interface);
    page = dev->interface->recv(dev->interface);

    if (page)
    {
        for (i = page->start; i < page->end; i++)
        {
            rx_process_byte(dev, page->data[i]);
        }
        npage_deref(page);
    }

    /* Order mattered because of this */
    if ((dev->rx_nb != NULL) && ((status & BDEV_STATUS_RX) == 0))
    {
        /* Second chance, it should eliminate all races */
        status = dev->interface->status(dev->interface);
        if ((status & BDEV_STATUS_RX) == 0)
        {
            DEBUG_WARN("tmap: sync lost before frame end\r\n");
            NET_STATS_RX_FRAME_ERROR(dev->stats);
            nbuf_deref(dev->rx_nb);
            dev->rx_nb = NULL;
            dev->rx_state = TMAP_RX_SEEK_PRE;
        }
    }
    else
    {
        status = dev->interface->status(dev->interface);
    }

    if ((dev->tx_nb == NULL) && ((status & BDEV_STATUS_RX) == 0))
    {
        dev->tx_nb = nbuf_dequeue_head(&dev->tx_queue);
        if (dev->tx_nb)
        {
            DEBUG_INFO("tmap: frame TX started\r\n");
        }
    }

    while ((dev->tx_nb != NULL) && ((status & BDEV_STATUS_TX_BF) == 0))
    {
        page = nbuf_fwd_read_page(dev->tx_nb);
        dev->interface->xmit(dev->interface, page);
        if (page == NULL)
        {
            DEBUG_INFO("tmap: frame TX complete\r\n");
            NET_STATS_TX_PACKET(dev->stats);
            nbuf_deref(dev->tx_nb);
            dev->tx_nb = NULL;
        }
        status = dev->interface->status(dev->interface);
    }
}

/**
 * Send a TMAP frame. 
 * @param dev TMAP device via which the frame shall be sent
 * @param nb Frame payload to send
 * @param header TMAP specific protocol info to append
 * @return Whether the frame has been queued for transmission
 */
bool tmap_send(struct tmap_dev *dev, struct nbuf *nb,
               const struct tmap_header *header)
{
    uint8_t tmp[TMAP_PREAMBLE_LEN];
    uint16_t len;
    uint16_t fcs;

    if (header->smac != dev->my_mac)
    {
        if ((dev->iflags & TMAP_FLAG_PROMISC) == 0)
        {
            DEBUG_ERROR("tmap: must use own SMAC ");
            DEBUG_ERROR("unless PROMISC flag is set\r\n");
            return false;
        }
    }

    nbuf_set_pos_to_start(nb);

    len = nb->end - nb->start;
    if (len > 255 - TMAP_OVERHEAD)
    {
        return false;
    }
    len += TMAP_OVERHEAD;

    memset(tmp, TMAP_PREAMBLE, TMAP_PREAMBLE_LEN);

    if (!nbuf_rev_make_space(nb, TMAP_OVERHEAD + TMAP_PREAMBLE_LEN - 2))
    {
        DEBUG_WARN("tmap: cannot add headers\r\n");
        NET_STATS_TX_DROPPED(dev->stats);
        return false;
    }

    nbuf_rev_write_word(nb, HTON16(header->dmac));
    nbuf_rev_write_word(nb, HTON16(header->smac));
    nbuf_rev_write_byte(nb, header->ttl);
    nbuf_rev_write_byte(nb, len);
    nbuf_rev_write_byte(nb, TMAP_SOF);

    fcs = NBUF_CRC16_CALC(nb, CRC16_ITUT_POLY);
    /* nbuf_crc16() moves pos to end */
    if (!nbuf_fwd_make_space(nb, 2))
    {
        DEBUG_WARN("tmap: cannot add FCS\r\n");
        NET_STATS_TX_DROPPED(dev->stats);
        return false;
    }
    nbuf_fwd_write_word(nb, HTON16(fcs));

    nbuf_set_pos_to_start(nb);
    nbuf_rev_write(nb, tmp, TMAP_PREAMBLE_LEN);

    nbuf_ref(nb);
    nbuf_set_pos_to_start(nb);
    nbuf_enqueue_tail(&dev->tx_queue, nb);

#if C_TMAP_DEBUG_LEVEL >= DEBUG_LEVEL_VERBOSE
    DEBUG_VERBOSE("\r\ntmap: TX nbuf:\r\n");
    nbuf_dump(nb);
#endif //C_TMAP_DEBUG_LEVEL

    return true;
}

/**
 * Retransmit a received TMAP frame. The frame should already 
 * have all headers, except preamble and FCS. 
 * @param dev TMAP device via which the frame shall be sent
 * @param nb Frame payload to send
 * @return Whether the frame has been queued for transmission
 */
bool tmap_resend(struct tmap_dev *dev, struct nbuf *nb)
{
    uint8_t tmp[TMAP_PREAMBLE_LEN];
    uint16_t fcs;
    uint8_t ttl;

    /* Check TTL */
    nbuf_set_pos_to_start(nb);
    nbuf_fwd_move(nb, 2);
    ttl = nbuf_fwd_read_byte(nb);
    if (ttl-- == 0)
    {
        DEBUG_VERBOSE("tmap: ttl expired\r\n");
        return false;
    }
    nbuf_rev_write_byte(nb, ttl);
    nbuf_rev_move(nb, 2);

    /* Redo FCS */
    fcs = NBUF_CRC16_CALC(nb, CRC16_ITUT_POLY);
    /* nbuf_crc16() moves pos to end */
    if (!nbuf_fwd_make_space(nb, 2))
    {
        DEBUG_WARN("tmap: cannot add FCS\r\n");
        NET_STATS_TX_DROPPED(dev->stats);
        return false;
    }
    nbuf_fwd_write_word(nb, HTON16(fcs));

    /* Add preamble */
    memset(tmp, TMAP_PREAMBLE, TMAP_PREAMBLE_LEN);
    nbuf_set_pos_to_start(nb);
    if (!nbuf_rev_make_space(nb, TMAP_PREAMBLE_LEN))
    {
        DEBUG_WARN("tmap: cannot add preamble\r\n");
        NET_STATS_TX_DROPPED(dev->stats);
        return false;
    }
    nbuf_rev_write(nb, tmp, TMAP_PREAMBLE_LEN);

    nbuf_ref(nb);
    nbuf_set_pos_to_start(nb);
    nbuf_enqueue_tail(&dev->tx_queue, nb);

#if C_TMAP_DEBUG_LEVEL >= DEBUG_LEVEL_VERBOSE
    DEBUG_VERBOSE("TX nbuf:\r\n");
    nbuf_dump(nb);
#endif //C_TMAP_DEBUG_LEVEL

    return true;
}

/**
 * Receive a TMAP frame. 
 * Frame position is set to the beginning of the payload field, 
 * but TMAP-specific headers, except for FCS, are not stripped. 
 * 
 * @param dev TMAP device to read
 * @param header Received TMAP specific protocol info
 * @return Frame received or NULL if no frames are available
 */
struct nbuf *tmap_recv(struct tmap_dev *dev, struct tmap_header *header)
{
    struct nbuf *nb;

    nb = nbuf_dequeue_head(&dev->rx_queue);
    if (!nb)
    {
        return NULL;
    }

    nbuf_fwd_move(nb, 2);
    header->ttl = nbuf_fwd_read_byte(nb);
    header->smac = NTOH16(nbuf_fwd_read_word(nb));
    header->dmac = NTOH16(nbuf_fwd_read_word(nb));

    return nb;
}

