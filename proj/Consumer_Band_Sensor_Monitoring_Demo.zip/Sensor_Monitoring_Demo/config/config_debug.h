/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-10-22 16:00:58 +0200 (Fri, 22 Oct 2010) $
 * $Revision: 85 $
 * $Author:   $
 */

/** 
 * @file
 * Template of the configuration file of the Debug module.  
 * It should be included in the master configuration file. Do not edit this 
 * file in the 'conf' subdirectory of the framework. Copy it to the 
 * application directory instead. 
 */

#ifndef __CONFIG_DEBUG_H
#define __CONFIG_DEBUG_H

/** Enable or disable debug mode globally */
#define C_DEBUG_MODE (ENABLED)
//#define C_DEBUG_MODE (DISABLED)

/** Call printf() instead of using UART directly? */
#define C_DEBUG_USE_PRINTF (DISABLED)

/** Maximum interrupt priority level where debug macros can be used */
#define C_DEBUG_IPL 2

/** Select the UART peripheral that will be used for debugging */
#define C_DEBUG_UART 2
/** Choose a baudrate for the debug interface */
#define C_DEBUG_UART_BAUD 115200

/** Debug level for top level functions (main.c) */
#define C_MAIN_DEBUG_LEVEL (DEBUG_LEVEL_VERBOSE)
/** Debug level for default (unassigned) context */
#define C_DEFAULT_DEBUG_LEVEL (DEBUG_LEVEL_PANIC)
/** Debug level for the debug module */
#define C_DEBUG_DEBUG_LEVEL (DEBUG_LEVEL_PANIC)

/** Debug trap handlers. 
 * If enabled, Top-of-stack and WREGs will be printed upon trap entry. 
 */
#define C_DEBUG_TRAPS (DISABLED)

/** Debug NMI. 
 * If enabled, it will consume the Change Notification interrupt handler. 
 * The information printed is the same as in the case of traps. 
 */
#define C_DEBUG_CN_NMI (DISABLED)

/** Debug NMI TRIS register */
#define C_DEBUG_CN_NMI_TRIS (TRISD)
/** Debug NMI port pin number */
#define C_DEBUG_CN_NMI_PIN (13)
/** Debug NMI Interrupt Enable register and pin */
#define C_DEBUG_CN_NMI_IE CNEN2, #CN19IE

#endif //__CONFIG_DEBUG_H

