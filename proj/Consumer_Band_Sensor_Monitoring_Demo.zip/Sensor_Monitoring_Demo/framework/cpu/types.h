/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-10-22 16:00:58 +0200 (Fri, 22 Oct 2010) $
 * $Revision: 85 $
 * $Author:   $
 */

#ifndef __TYPES_H
#define __TYPES_H

/** 
 * @file 
 * Type definitions 
 */

#include <stddef.h>

#ifndef HOSTED
/* If HOSTED is unset, then assume that standard types, as defined in
 * 'stdint.h' and 'stdbool.h' are not provided. Define them now. 
 */
typedef char int8_t;                  /**< Signed 8 bit type       */
typedef unsigned char uint8_t;        /**< Unsigned 8 bit type     */
typedef short int16_t;                /**< Signed 16 bit type      */
typedef unsigned short uint16_t;      /**< Unsigned 16 bit type    */
typedef long int32_t;                 /**< Signed 32 bit type      */
typedef unsigned long uint32_t;       /**< Unsigned 32 bit type    */
typedef long long int64_t;            /**< Signed 64 bit type      */
typedef unsigned long long uint64_t;  /**< Unsigned 64 bit type    */

typedef char bool;                    /**< Boolean type            */
#define false	0                     /**< Boolean false value     */
#define true	1                     /**< Boolean true value      */

#else
#include <stdint.h>
#include <stdbool.h>
#endif //HOSTED

/* All possible 16-bit fractional types */
typedef int16_t q1_15;                /**< Fractional 1.15 type    */
typedef int16_t q2_14;                /**< Fractional 2.14 type    */
typedef int16_t q3_13;                /**< Fractional 3.13 type    */
typedef int16_t q4_12;                /**< Fractional 4.12 type    */
typedef int16_t q5_11;                /**< Fractional 5.11 type    */
typedef int16_t q6_10;                /**< Fractional 6.10 type    */
typedef int16_t q7_0;                 /**< Fractional 7.9 type     */
typedef int16_t q8_8;                 /**< Fractional 8.8 type     */
typedef int16_t q9_7;                 /**< Fractional 9.7 type     */
typedef int16_t q10_6;                /**< Fractional 10.6 type    */
typedef int16_t q11_5;                /**< Fractional 11.5 type    */
typedef int16_t q12_4;                /**< Fractional 12.4 type    */
typedef int16_t q13_3;                /**< Fractional 13.3 type    */
typedef int16_t q14_2;                /**< Fractional 14.2 type    */
typedef int16_t q15_1;                /**< Fractional 15.1 type    */

/* Selected 32-bit and 64-bit fractional types */
typedef int32_t q17_15;               /**< Fractional 17.15 type   */
typedef int32_t q3_29;                /**< Fractional 3.29 type    */
typedef int32_t q1_31;                /**< Fractional 1.31 type    */
typedef int64_t q35_29;               /**< Fractional 35.29 type   */
typedef int64_t q49_15;               /**< Fractional 49.15 type   */

typedef void (*handle_t)(void);       /**< Generic functional type */

#endif //__TYPES_H

