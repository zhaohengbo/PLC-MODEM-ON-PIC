/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-09-01 09:54:39 +0200 (Wed, 01 Sep 2010) $
 * $Revision: 83 $
 * $Author:   $
 */

#ifndef __CONFIG_BPSK_H
#define __CONFIG_BPSK_H

#if PLM_SCHEME == MS_BPSK

/** 
 * @file
 * Template of the BPSK configuration file. It should be included 
 * in the master configuration file. 
 *
 * If you wish to do application-specific modifications, you should copy 
 * this file to the application directory, to a location in the include search 
 * path and modify it there. Modifications in the template will affect 
 * all the applications that do not use a local modified copy. 
 */

/** @name Available modulator implementations.
 * Set the PLM_MOD_IMP variable to one of the constants defined here. 
 *  DDS:   
 *       Directly calculates sine samples. No real-world output. 
 *       Used for demodulator testing (internal loopback). 
 *       Can be used to drive a DAC. 
 *  PWM: 
 *       Uses a single PWM (Output Compare) output. 
 *       For PLM-E16 revision 1.3 or older
 *  2PWM: 
 *       Uses a sum of two PWM (Output Compare) outputs. 
 *       For custom boards, especially with dsPIC33FJ32GP202

 *  4PWM: 
 *       Uses a sum of four PWM (Output Compare) outputs. 
 *       For PLM-E16 revision 1.4 or newer
 */
/*@{*/
#define MOD_DDS 0
#define MOD_PWM 1
#define MOD_2PWM 2
#define MOD_4PWM 3
/*@}*/

#ifndef __MakefileOverride
/**
 * Carrier frequencies and baud rates below are just examples. 
 * Anything will do as long as PLM_FC / PLM_BAUD is integer, but
 * it is recommended so that the undersampled carrier was also
 * divisible by the baud rate. The PLL will make up if it is not, 
 * however the performance may be suboptimal (e.g. 7200 @ 72000). 
 */

/** Carrier frequency (72000 or 129600) */
#define PLM_FC 129600

/** Desired baudrate
 *   @ 72000: 1200, 2400, 4800, 6000
 *   @129600: 1200, 2400, 3600, 4800, 5400, 7200
 */
#define PLM_BAUD 7200

/** Modulator selection */
#define PLM_MOD_IMP MOD_4PWM
#endif //__MakefileOverride

/** 
 * Soft AGC. Enable, if the hardware does not produce an overamplified
 * square signal. Otherwise, the Costas loop will not catch sync. 
 */
#define PLM_SOFT_AGC ENABLED

/** @name Costas feedback options. */
/*@{*/

/** 
 * No filtering, the error signal drives the NCO directly. 
 * Simple, efficient and usually good enough. 
 */
#define COSTAS_DIRECT 0

/**
 * PI regulator. 
 * It can cancel the frequency offset, but is difficult to tune. 
 */
#define COSTAS_PI 1

/**
 * Full PID regulator. 
 * Theoretically can catch up faster. 
 */
#define COSTAS_PID 2

/*@}*/

/** Select your feedback option here */
#define PLM_COSTAS_FB COSTAS_PI

/** Preamble character (synchronization pattern). 
 *  Don't mess with it, unless you know what you are doing 
 */
#if PLM_FEC==DISABLED
	#define PLM_PRE 0x2a
#else
	#define PLM_PRE 0xd3
	#if FEC_CODE==HAYKIN
		#define PLM_PRE_FEC 0x4bda
	#endif //HAYKIN
	#if FEC_CODE==PRIME
		#define PLM_PRE_FEC 0xaead
	#endif //PRIME
#endif //PLM_FEC

#endif //PLM_SCHEME

#endif //__CONFIG_BPSK_H

