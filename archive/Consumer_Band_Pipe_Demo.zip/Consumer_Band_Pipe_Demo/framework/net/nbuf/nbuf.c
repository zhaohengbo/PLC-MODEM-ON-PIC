/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-11-05 16:48:49 +0100 (Fri, 05 Nov 2010) $
 * $Revision: 88 $
 * $Author:   $
 */

/** 
 * @file
 * Network buffers. 
 */

#include <config.h>
#include <string.h>
#include <net/nbuf.h>

#define DEBUG_CONTEXT NET
#include <sys/debug.h>

/* Net page pool of the networking stack */
static struct npage_pool page_pool;

/* Net buffer pool of the networking stack */
static struct nbuf_pool buf_pool;

/**
 * Initialize system npage and nbuf pools. 
 */
void net_pools_init(void)
{
    int i;

    page_pool.index = 0;
    page_pool.remain = C_NET_NPAGE_POOL;
    for (i = 0; i < C_NET_NPAGE_POOL; i++)
    {
        npage_init(&page_pool.pages[i]);
    }

    buf_pool.index = 0;
    buf_pool.remain = C_NET_NBUF_POOL;
    for (i = 0; i < C_NET_NBUF_POOL; i++)
    {
        nbuf_init(&buf_pool.bufs[i]);
    }
}

/** 
 * Check "low water" condition on the npage pool. 
 * @return 'true' if the npage low water mark has been achieved
 */
bool npage_pool_lw(void)
{
    return page_pool.remain <= C_NET_NPAGE_LOW_WATER;
}

/** 
 * Check "low water" condition on the nbuf pool. 
 * @return 'true' if the nbuf low water mark has been achieved
 */
bool nbuf_pool_lw(void)
{
    return buf_pool.remain <= C_NET_NBUF_LOW_WATER;
}

/**
 * Initialize a new net page.
 * @param page Net page to initialize
 */
void npage_init(struct npage *page)
{
    memset(page->data, 0, sizeof (page->data));
    page->ref = 0;
    page->start = 0;
    page->end = 0;
    page->next = NULL;
    page->prev = NULL;
}

/**
 * Get a net page from the net page pool. 
 * The page will have a reference count set to 1. 
 * @return Page address or NULL in case no pages are left
 */
struct npage *npage_pool_get(void)
{
    struct npage *page;
    uint16_t i;

    if (page_pool.remain == 0)
    {
        return NULL;
    }

    for (i = 0; i < C_NET_NPAGE_POOL; i++)
    {
        page = &page_pool.pages[page_pool.index];
        if (page->ref == 0)
        {
            break;
        }
        page_pool.index++;
        if (page_pool.index == C_NET_NPAGE_POOL)
        {
            page_pool.index = 0;
        }
    }
    if (i < C_NET_NPAGE_POOL)
    {
        npage_init(page);
        npage_ref(page);
        page_pool.remain--;
        return page;
    }
    DEBUG_ERROR("net: remain > 0, but no pages found\r\n");
    return NULL;
}

/**
 * Increase the reference count for a page. 
 * @param page Net page to reference
 */
void npage_ref(struct npage *page)
{
    page->ref++;
    if (page->ref == 0)
    {
        DEBUG_ERROR("net: page ref count overflow\r\n");
        page->ref--;
    }
}

/**
 * Decrease the reference count for a page. 
 * @param page Net page to dereference
 */
void npage_deref(struct npage *page)
{
    if (page->ref != 0)
    {
        if (--page->ref == 0)
        {
            page_pool.remain++;
        }
    }
    else
    {
        DEBUG_ERROR("net: dereferencing an unused page\r\n");
    }
}

/**
 * Add a net page to the head of a net page queue. 
 * @param queue Queue to add to
 * @param page Page to add
 */
void npage_enqueue_head(struct npage_queue *queue, struct npage *page)
{
    if (!page)
    {
        return;
    }

    page->prev = NULL;
    page->next = queue->head;
    queue->head = page;
    if (page->next)
    {
        page->next->prev = page;
    }
    else
    {
        queue->tail = page;
    }
}

/**
 * Add a net page to the head of a net page queue. 
 * @param queue Queue to add to
 * @param page Page to add
 */
void npage_enqueue_tail(struct npage_queue *queue, struct npage *page)
{
    if (!page)
    {
        return;
    }

    page->prev = queue->tail;
    page->next = NULL;
    queue->tail = page;
    if (page->prev)
    {
        page->prev->next = page;
    }
    else
    {
        queue->head = page;
    }
}

/**
 * Detach head from a net page queue. 
 * @param queue Queue to work on
 * @return Former head member of the queue
 */
struct npage *npage_dequeue_head(struct npage_queue *queue)
{
    struct npage *page;

    page = queue->head;
    if (page)
    {
        if (queue->tail == page)
        {
            queue->tail = NULL;
        }
        queue->head = page->next;
        if (queue->head)
        {
            queue->head->prev = NULL;
        }
    }
    return page;
}

/**
 * Detach tail from a net page queue. 
 * @param queue Queue to work on
 * @return Former tail member of the queue
 */
struct npage *npage_dequeue_tail(struct npage_queue *queue)
{
    struct npage *page;

    page = queue->tail;
    if (page)
    {
        if (queue->head == page)
        {
            queue->head = NULL;
        }
        queue->tail = page->prev;
        if (queue->tail)
        {
            queue->tail->next = NULL;
        }
    }
    return page;
}

/**
 * Initialize a new net buffer.
 * @param buf Net buffer to initialize
 */
void nbuf_init(struct nbuf *buf)
{
    memset(buf, 0, sizeof (struct nbuf));

    /* Set by memset() above.
    buf->ref = 0;
    buf->next = NULL;
    buf->prev = NULL;

    buf->pages.head = NULL;
    buf->pages.tail = NULL;
    buf->current = NULL;

    buf->pos = 0;
    buf->start = 0;
    buf->end = 0;
    buf->size = 0;
     */
}

/**
 * Finalize a net buffer. 
 * Frees all net pages attached and resets the buffer. 
 * @param buf Net buffer to finalize
 */
void nbuf_final(struct nbuf *buf)
{
    struct npage *page;
    while ((page = npage_dequeue_head(&buf->pages)) != NULL)
    {
        npage_deref(page);
    }
    buf_pool.remain++;
    nbuf_init(buf);
}

/**
 * Get a net buffer from the net buffer pool even if low water condition. 
 * The buffer will have a reference count set to 1. 
 * @return Buffer address or NULL in case no buffers are left
 */
struct nbuf *nbuf_pool_get_lw(void)
{
    struct nbuf *buf;
    uint16_t i;

    if (buf_pool.remain == 0)
    {
        return NULL;
    }

    for (i = 0; i < C_NET_NBUF_POOL; i++)
    {
        buf = &buf_pool.bufs[buf_pool.index];
        if (buf->ref == 0)
        {
            break;
        }
        buf_pool.index++;
        if (buf_pool.index == C_NET_NBUF_POOL)
        {
            buf_pool.index = 0;
        }
    }
    if (i < C_NET_NBUF_POOL)
    {
        nbuf_init(buf);
        nbuf_ref(buf);
        buf_pool.remain--;
        return buf;
    }
    DEBUG_ERROR("net: remain > 0, but no nbufs found\r\n");
    return NULL;
}

/**
 * Get a net buffer from the net buffer pool. 
 * The buffer will have a reference count set to 1. 
 * @return Buffer address or NULL in case no buffers are left
 */
struct nbuf *nbuf_pool_get(void)
{
    if (nbuf_pool_lw())
    {
        return NULL;
    }
    return nbuf_pool_get_lw();
}

/**
 * Get a net buffer from the net buffer pool and move the start by offset, 
 * even if low water condition. 
 * The buffer will have a reference count set to 1. 
 * @param offs Position where start mark should be set
 * @return Buffer address or NULL in case no buffers are left
 */
struct nbuf *nbuf_pool_get_with_offs_lw(uint16_t offs)
{
    struct nbuf *buf;
    buf = nbuf_pool_get();
    if (buf == NULL)
    {
        return NULL;
    }

    if (!nbuf_fwd_make_space(buf, offs))
    {
        nbuf_deref(buf);
        return NULL;
    }
    nbuf_fwd_move(buf, offs);
    buf->start = offs;
    buf->end = offs;
    return buf;
}

/**
 * Get a net buffer from the net buffer pool and move the start by offset.  
 * The buffer will have a reference count set to 1. 
 * @param offs Position where start mark should be set
 * @return Buffer address or NULL in case no buffers are left
 */
struct nbuf *nbuf_pool_get_with_offs(uint16_t offs)
{
    if (nbuf_pool_lw())
    {
        return NULL;
    }
    return nbuf_pool_get_with_offs_lw(offs);
}

/**
 * Make a copy of a net buffer. 
 * New buffer will have a reference count of 1 and will neither 
 * have a predecessor nor successor. 
 * @param buf Buffer to copy
 * @return Buffer address or NULL in case no buffers are left
 */
struct nbuf *nbuf_copy(struct nbuf *buf)
{
    struct nbuf *copy;
    struct npage *spage;
    struct npage *dpage;

    copy = nbuf_pool_get();
    if (copy == NULL)
    {
        return NULL;
    }

    if (!nbuf_fwd_make_space(copy, buf->size))
    {
        nbuf_deref(copy);
        return NULL;
    }

    spage = buf->pages.head;
    dpage = copy->pages.head;
    while (spage && dpage)
    {
        memcpy(dpage->data, spage->data, C_NET_NPAGE_SIZE);

        if (spage == buf->current)
        {
            copy->current = dpage;
        }
        spage = spage->next;
        dpage = dpage->next;
    }

    copy->pos = buf->pos;
    copy->start = buf->start;
    copy->end = buf->end;

    return copy;
}

/**
 * Make a clone of a net buffer. 
 * The new one will share all net pages with the old buffer, it will have 
 * a reference  count of 1 and will neither have a predecessor nor successor. 
 * The buffer returned should be treated read-only. 
 * @param buf Buffer to copy
 * @return Buffer address or NULL in case no buffers are left
 */
struct nbuf *nbuf_clone(struct nbuf *buf)
{
    struct nbuf *clone;
    struct npage *page;

    clone = nbuf_pool_get();
    if (clone == NULL)
    {
        return NULL;
    }

    *clone = *buf;
    clone->ref = 1;
    clone->next = NULL;
    clone->prev = NULL;

    page = buf->pages.head;
    while (page)
    {
        npage_ref(page);
        page = page->next;
    }
    return clone;
}

/**
 * Increase the reference count for a net buffer. 
 * @param buf Net buffer to reference
 */
void nbuf_ref(struct nbuf *buf)
{
    buf->ref++;
    if (buf->ref == 0)
    {
        DEBUG_ERROR("net: buf ref count overflow\r\n");
        buf->ref--;
    }
}

/**
 * Decrease the reference count for a net buffer. 
 * @param buf Net buf to dereference
 */
void nbuf_deref(struct nbuf *buf)
{
    if (buf->ref != 0)
    {
        if (--buf->ref == 0)
        {
            nbuf_final(buf);
        }
    }
    else
    {
        DEBUG_ERROR("net: dereferencing an unused buffer\r\n");
    }
}

/**
 * Make forward space in a net buffer even if low water condition. 
 * Ensures that 'count' bytes can be written to the net buffer 'buf' 
 * at current buffer position. New net pages are fetched from the pool
 * whenever required. Even if this function fails, new pages may be
 * added to the buffer. 
 *
 * @param buf Buffer to extend
 * @param count Amount of space to make
 * @return Operation status, 'true' if space was made available
 */
bool nbuf_fwd_make_space_lw(struct nbuf *buf, uint16_t count)
{
    struct npage *page;

    while (buf->pos + count > buf->size)
    {
        if (buf->size > 0xffff - C_NET_NPAGE_SIZE)
        {
            DEBUG_WARN("net: buffer full\r\n");
            return false;
        }

        page = npage_pool_get();
        if (!page)
        {
            DEBUG_WARN("net: out of net pages\r\n");
            return false;
        }
        npage_enqueue_tail(&buf->pages, page);
        buf->size += C_NET_NPAGE_SIZE;
        if (buf->current == NULL)
        {
            buf->current = page;
        }
    }
    return true;
}

/**
 * Make forward space in a net buffer. 
 * Ensures that 'count' bytes can be written to the net buffer 'buf' 
 * at current buffer position. New net pages are fetched from the pool
 * whenever required. Even if this function fails, new pages may be
 * added to the buffer. 
 *
 * @param buf Buffer to extend
 * @param count Amount of space to make
 * @return Operation status, 'true' if space was made available
 */
bool nbuf_fwd_make_space(struct nbuf *buf, uint16_t count)
{
    if (buf->pos + count <= buf->size)
    {
        return true;
    }

    if (npage_pool_lw())
    {
        return false;
    }

    return nbuf_fwd_make_space_lw(buf, count);
}

/**
 * Forward data write to a net buffer. 
 * Writes 'count' bytes to the net buffer 'buf' at current buffer position. 
 * Position is advanced by the number of bytes written. 
 * 
 * @param buf Buffer to write to
 * @param data Data to write
 * @param count Number of bytes to copy
 */
void nbuf_fwd_write(struct nbuf *buf, uint8_t *data, uint16_t count)
{
    uint16_t offset = buf->pos % C_NET_NPAGE_SIZE;
    uint16_t i;

    for (i = 0; i < count; i++)
    {
        if (!buf->current)
        {
            DEBUG_ERROR("net: fwd_write(");
            DEBUG_ERROR_U16(count);
            DEBUG_ERROR(") no space in buffer\r\n");
            return;
        }
        buf->current->data[offset++] = data[i];
        if (offset == C_NET_NPAGE_SIZE)
        {
            offset = 0;
            buf->current = buf->current->next;
        }
    }
    buf->pos += count;
    if (buf->pos > buf->end)
    {
        buf->end = buf->pos;
    }
}

/**
 * Move net buffer position forward. 
 * This function moves buffer position and end marker the same way 
 * as nbuf_fwd_write() would, but it does not change buffer data. 
 * 
 * @param buf Net buffer to operate on
 * @param count Number of bytes to advance
 */
void nbuf_fwd_move(struct nbuf *buf, uint16_t count)
{
    uint16_t offset = buf->pos % C_NET_NPAGE_SIZE;
    uint16_t i;

    for (i = 0; i < count; i++)
    {
        if (!buf->current)
        {
            DEBUG_ERROR("net: fwd_move(");
            DEBUG_ERROR_U16(count);
            DEBUG_ERROR(") no space in buffer\r\n");
            return;
        }
        if (++offset == C_NET_NPAGE_SIZE)
        {
            offset = 0;
            buf->current = buf->current->next;
        }
    }
    buf->pos += count;
    if (buf->pos > buf->end)
    {
        buf->end = buf->pos;
    }
}

/**
 * Forward write a byte to a net buffer. 
 * Writes a byte to the net buffer 'buf' at current buffer position. 
 * Position is advanced by one. The caller must ensure that there is 
 * enough space in the buffer. 
 * 
 * @param buf Buffer to write to
 * @param byte Data byte to write
 */
void nbuf_fwd_write_byte(struct nbuf *buf, uint8_t byte)
{
    nbuf_fwd_write(buf, &byte, 1);
}

/**
 * Forward write a two byte word to a net buffer. 
 * Writes a 16-bit word to the net buffer 'buf' at current buffer position. 
 * Position is advanced by two. The caller must ensure that there is 
 * enough space in the buffer. 
 * 
 * @param buf Buffer to write to
 * @param word Data word to write
 */
void nbuf_fwd_write_word(struct nbuf *buf, uint16_t word)
{
    nbuf_fwd_write(buf, (uint8_t*) & word, 2);
}

/**
 * Make reverse space in a net buffer even if low water condition. 
 * Ensures that 'count' bytes can be written to the net buffer 'buf' 
 * starting one position before the current buffer position.
 * New net pages are fetched from the pool whenever required. Even if this 
 * function fails, new pages may be added to the buffer.  
 *
 * @param buf Buffer to extend
 * @param count Amount of space to make
 * @return Operation status, 'true' if space was made available
 */
bool nbuf_rev_make_space_lw(struct nbuf *buf, uint16_t count)
{
    struct npage *page;
    while (buf->pos < count)
    {
        if (buf->size > 0xffff - C_NET_NPAGE_SIZE)
        {
            DEBUG_WARN("net: buffer full\r\n");
            return false;
        }

        page = npage_pool_get();
        if (!page)
        {
            DEBUG_WARN("net: out of net pages\r\n");
            return false;
        }
        npage_enqueue_head(&buf->pages, page);
        buf->size += C_NET_NPAGE_SIZE;
        buf->start += C_NET_NPAGE_SIZE;
        buf->end += C_NET_NPAGE_SIZE;
        buf->pos += C_NET_NPAGE_SIZE;
    }
    return true;
}

/**
 * Make reverse space in a net buffer. 
 * Ensures that 'count' bytes can be written to the net buffer 'buf' 
 * starting one position before the current buffer position.
 * New net pages are fetched from the pool whenever required. Even if this 
 * function fails, new pages may be added to the buffer.  
 *
 * @param buf Buffer to extend
 * @param count Amount of space to make
 * @return Operation status, 'true' if space was made available
 */
bool nbuf_rev_make_space(struct nbuf *buf, uint16_t count)
{
    if (buf->pos >= count)
    {
        return true;
    }

    if (npage_pool_lw())
    {
        return false;
    }

    return nbuf_rev_make_space_lw(buf, count);
}

/**
 * Reverse data write to a net buffer. 
 * Writes 'count' bytes to the net buffer 'buf' starting one position before 
 * the current buffer position. The order of bytes in the net buffer is 
 * the same as the order in the original data buffer. Position is retracted 
 * by the number of bytes written. The caller must ensure that there is 
 * enough space in the buffer. 
 *
 * @param buf Buffer to write to
 * @param data Data to write
 * @param count Number of bytes to copy
 */
void nbuf_rev_write(struct nbuf *buf, uint8_t *data, uint16_t count)
{
    uint16_t offset = buf->pos % C_NET_NPAGE_SIZE;
    uint16_t i;

    for (i = count; i > 0; i--)
    {
        if (offset == 0)
        {
            offset = C_NET_NPAGE_SIZE;
            if (buf->current)
            {
                buf->current = buf->current->prev;
            }
            else
            {
                buf->current = buf->pages.tail;
            }
        }
        if (!buf->current)
        {
            DEBUG_ERROR("net: rev_write(");
            DEBUG_ERROR_U16(count);
            DEBUG_ERROR(") no space in buffer\r\n");
            return;
        }
        buf->current->data[--offset] = data[i - 1];
    }
    buf->pos -= count;
    if (buf->pos < buf->start)
    {
        buf->start = buf->pos;
    }
}

/**
 * Move net buffer position backward. 
 * This function moves buffer position and start marker the same way 
 * as nbuf_rev_write() would, but it does not change buffer data. 
 * 
 * @param buf Net buffer to operate on
 * @param count Number of bytes to retract
 */
void nbuf_rev_move(struct nbuf *buf, uint16_t count)
{
    uint16_t offset = buf->pos % C_NET_NPAGE_SIZE;
    uint16_t i;

    for (i = count; i > 0; i--)
    {
        if (offset == 0)
        {
            offset = C_NET_NPAGE_SIZE;
            if (buf->current)
            {
                buf->current = buf->current->prev;
            }
            else
            {
                buf->current = buf->pages.tail;
            }
        }
        if (!buf->current)
        {
            DEBUG_ERROR("net: rev_move(");
            DEBUG_ERROR_U16(count);
            DEBUG_ERROR(") no space in buffer\r\n");
            return;
        }
        offset--;
    }
    buf->pos -= count;
    if (buf->pos < buf->start)
    {
        buf->start = buf->pos;
    }
}

/**
 * Reverse write a byte to a net buffer. 
 * Writes a bytes to the net buffer 'buf' starting one position before 
 * the current buffer position. Position is retracted by one. The caller 
 * must ensure that there is enough space in the buffer. 
 *
 * @param buf Buffer to write to
 * @param byte Data byte to write
 */
void nbuf_rev_write_byte(struct nbuf *buf, uint8_t byte)
{
    nbuf_rev_write(buf, &byte, 1);
}

/**
 * Reverse write a two byte word to a net buffer. 
 * Writes a 16-bit word to the net buffer 'buf' starting one position before 
 * the current buffer position. Position is retracted by two. The caller 
 * must ensure that there is enough space in the buffer. 
 * 
 * @param buf Buffer to write to
 * @param word Data word to write
 */
void nbuf_rev_write_word(struct nbuf *buf, uint16_t word)
{
    nbuf_rev_write(buf, (uint8_t*) & word, 2);
}

/**
 * Forward read a page from a net buffer. 
 * Advances buffer position by one page.
 * Page read is referenced and has start and end markers set. 
 * 
 * @return Pointer to a page read
 */
struct npage *nbuf_fwd_read_page(struct nbuf *buf)
{
    uint16_t offset = buf->pos % C_NET_NPAGE_SIZE;
    uint16_t remain;

    struct npage *page;

    if (!buf->current)
    {
        return NULL;
    }
    page = buf->current;

    remain = C_NET_NPAGE_SIZE - offset;
    if (buf->pos + remain > buf->end)
    {
        remain = buf->end - buf->pos;
    }
    if (remain == 0)
    {
        return NULL;
    }
    buf->pos += remain;
    page->start = offset;
    page->end = page->start + remain;
    if (page->end == C_NET_NPAGE_SIZE)
    {
        buf->current = buf->current->next;
    }

    npage_ref(page);
    return page;
}

/**
 * Forward data read from a net buffer. 
 * Reads 'count' bytes from the net buffer 'buf' starting at current buffer 
 * position. Position is advanced by the number of bytes read. 
 * 
 * @param buf Buffer to read from
 * @param data Buffer for data read
 * @param count Number of bytes to copy
 * @return Operation status, 'true' if read succeeded
 */
bool nbuf_fwd_read(struct nbuf *buf, uint8_t *data, uint16_t count)
{
    uint16_t offset = buf->pos % C_NET_NPAGE_SIZE;
    uint16_t index = 0;

    if ((buf->pos + count > buf->end) || (buf->pos > 0xffffu - count))
    {
        DEBUG_INFO("net: read beyond buffer end\r\n");
        return false;
    }
    buf->pos += count;

    while (index < count)
    {
        if (!buf->current)
        {
            DEBUG_ERROR("net: unexpected NULL page\r\n");
            return false;
        }
        data[index++] = buf->current->data[offset++];
        if (offset == C_NET_NPAGE_SIZE)
        {
            offset = 0;
            buf->current = buf->current->next;
        }
    }
    return true;
}

/**
 * Forward read a byte from a net buffer. 
 * Reads a byte from the net buffer 'buf' starting at current buffer 
 * position. Position is advanced by one. 
 * You should verify before calling this function that a byte can be read. 
 * 
 * @param buf Buffer to read from
 * @return Byte read
 */
uint8_t nbuf_fwd_read_byte(struct nbuf *buf)
{
    uint8_t byte = 0;
    nbuf_fwd_read(buf, &byte, 1);
    return byte;
}

/**
 * Forward read a two byte word from a net buffer. 
 * Reads a 16-bit word from the net buffer 'buf' starting at current buffer 
 * position. Position is advanced by two. 
 * You should verify before calling this function that a word can be read. 
 * 
 * @param buf Buffer to read from
 * @return Word read
 */
uint16_t nbuf_fwd_read_word(struct nbuf *buf)
{
    uint16_t word;
    nbuf_fwd_read(buf, (uint8_t*) & word, 2);
    return word;
}

/**
 * Reverse data read from a net buffer. 
 * Reads 'count' bytes from the net buffer 'buf' starting one position 
 * before the current buffer position. The order of bytes in the read 
 * buffer is the same as the order in the original net buffer. Position is 
 * retracted by the number of bytes read. 
 *
 * @param buf Buffer to read from
 * @param data Buffer for data read
 * @param count Number of bytes to copy
 * @return Operation status, 'true' if read succeeded
 */
bool nbuf_rev_read(struct nbuf *buf, uint8_t *data, uint16_t count)
{
    uint16_t offset = buf->pos % C_NET_NPAGE_SIZE;
    uint16_t index = count;

    if ((buf->pos - count < buf->start) || (buf->pos < count))
    {
        DEBUG_INFO("net: read beyond buffer start\r\n");
        return false;
    }
    buf->pos -= count;

    while (index)
    {
        if (offset == 0)
        {
            offset = C_NET_NPAGE_SIZE;
            if (buf->current)
            {
                buf->current = buf->current->prev;
            }
            else
            {
                buf->current = buf->pages.tail;
            }
        }
        if (!buf->current)
        {
            DEBUG_ERROR("net: unexpected NULL page\r\n");
            return false;
        }
        data[--index] = buf->current->data[--offset];
    }
    return true;
}

/**
 * Reverse read a byte from a net buffer. 
 * Reads a byte from the net buffer 'buf' starting one position 
 * before the current buffer position. Position is retracted by one. 
 * You should verify before calling this function that a byte can be read. 
 * 
 * @param buf Buffer to read from
 * @return Byte read
 */
uint8_t nbuf_rev_read_byte(struct nbuf *buf)
{
    uint8_t byte;
    nbuf_rev_read(buf, &byte, 1);
    return byte;
}

/**
 * Reverse read a two byte word from a net buffer. 
 * Reads a 16-bit word from the net buffer 'buf' starting one position 
 * before the current buffer position. Position is retracted by two. 
 * You should verify before calling this function that a word can be read. 
 * 
 * @param buf Buffer to read from
 * @return Word read
 */
uint16_t nbuf_rev_read_word(struct nbuf *buf)
{
    uint16_t word;
    nbuf_rev_read(buf, (uint8_t*) & word, 2);
    return word;
}

/**
 * Set net buffer position to the start of data. 
 * @param buf Buffer to operate on
 */
void nbuf_set_pos_to_start(struct nbuf *buf)
{
    nbuf_rev_move(buf, buf->pos - buf->start);
}

/**
 * Set net buffer position to the end of data. 
 * @param buf Buffer to operate on
 */
void nbuf_set_pos_to_end(struct nbuf *buf)
{
    nbuf_fwd_move(buf, buf->end - buf->pos);
}

/**
 * Cut count bytes from net buffer start. 
 * This function moves buffer start marker forward, till the current buffer 
 * position, dereferencing all net pages that get freed on the way. 
 * 
 * @param buf Net buffer to operate on
 */
void nbuf_cut_head(struct nbuf *buf)
{
    struct npage *page;

    buf->start = buf->pos;
    if (!buf->current)
    {
        return;
    }
    while (buf->current->prev)
    {
        page = npage_dequeue_head(&buf->pages);
        if (!page)
        {
            DEBUG_PANIC("net: PANIC: nbuf corruption\r\n");
            return;
        }
        npage_deref(page);
        buf->pos -= C_NET_NPAGE_SIZE;
        buf->start -= C_NET_NPAGE_SIZE;
        buf->end -= C_NET_NPAGE_SIZE;
        buf->size -= C_NET_NPAGE_SIZE;
    }
}

/**
 * Cut count bytes from net buffer end. 
 * This function moves buffer end marker backward, till the current buffer 
 * position, dereferencing all net pages that get freed on the way. 
 * 
 * @param buf Net buffer to operate on
 */
void nbuf_cut_tail(struct nbuf *buf)
{
    struct npage *page;

    buf->end = buf->pos;
    if (!buf->current)
    {
        return;
    }

    while (buf->current->next)
    {
        page = npage_dequeue_tail(&buf->pages);
        if (!page)
        {
            DEBUG_PANIC("net: PANIC: nbuf corruption\r\n");
            return;
        }
        npage_deref(page);
        buf->size -= C_NET_NPAGE_SIZE;
    }
}

/**
 * Add a net buffer to the head of a net buffer queue. 
 * @param queue Queue to add to
 * @param buf Net buffer to add
 */
void nbuf_enqueue_head(struct nbuf_queue *queue, struct nbuf *buf)
{
    if (!buf)
    {
        return;
    }

    buf->prev = NULL;
    buf->next = queue->head;
    queue->head = buf;
    if (buf->next)
    {
        buf->next->prev = buf;
    }
    else
    {
        queue->tail = buf;
    }
}

/**
 * Add a net buffer to the head of a net buffer queue. 
 * @param queue Queue to add to
 * @param buf Net buffer to add
 */
void nbuf_enqueue_tail(struct nbuf_queue *queue, struct nbuf *buf)
{
    if (!buf)
    {
        return;
    }

    buf->prev = queue->tail;
    buf->next = NULL;
    queue->tail = buf;
    if (buf->prev)
    {
        buf->prev->next = buf;
    }
    else
    {
        queue->head = buf;
    }
}

/**
 * Detach head from a net buffer queue. 
 * @param queue Queue to work on
 * @return Former head member of the queue
 */
struct nbuf *nbuf_dequeue_head(struct nbuf_queue *queue)
{
    struct nbuf *buf;

    buf = queue->head;
    if (buf)
    {
        queue->head = buf->next;
        if (queue->head)
        {
            queue->head->prev = NULL;
        }
        else
        {
            queue->tail = NULL;
        }
        buf->next = NULL;
        buf->prev = NULL;
    }
    return buf;
}

/**
 * Detach tail from a net buffer queue. 
 * @param queue Queue to work on
 * @return Former tail member of the queue
 */
struct nbuf *nbuf_dequeue_tail(struct nbuf_queue *queue)
{
    struct nbuf *buf;

    buf = queue->tail;
    if (buf)
    {
        queue->tail = buf->prev;
        if (queue->tail)
        {
            queue->tail->next = NULL;
        }
        else
        {
            queue->head = NULL;
        }
        buf->next = NULL;
        buf->prev = NULL;
    }
    return buf;
}

/**
 * Release a net buffer queue. 
 * Removes and dereferemces all net buffers in a queue. 
 * @param queue Net buffer queue to release
 */
void nbuf_queue_release(struct nbuf_queue *queue)
{
    struct nbuf *buf;

    while ((buf = nbuf_dequeue_head(queue)) != NULL)
    {
        nbuf_deref(buf);
    }
}

