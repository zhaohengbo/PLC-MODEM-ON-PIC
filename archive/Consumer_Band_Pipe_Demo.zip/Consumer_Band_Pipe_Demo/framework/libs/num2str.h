/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-10-22 16:00:58 +0200 (Fri, 22 Oct 2010) $
 * $Revision: 85 $
 * $Author:   $
 */

/**
 * @file
 * String to number and number to string conversions.
 *
 * Most of the functionality provided by these functions could
 * be achieved using standard functions (sprintf, atoi, etc.),
 * but for unsophisticated needs, it's better to use num2str
 * as functions from this file will take less program memory space.
 */

#ifndef __NUM2STR_H
#define __NUM2STR_H

#include <cpu/types.h>

char to_hex_digit(uint8_t val);

char *fraction_16_to_str(char *buf, 
	uint8_t buf_len, uint16_t frac, uint16_t base);
char *fraction_32_to_str(char *buf, 
	uint8_t buf_len, uint32_t frac, uint32_t base);

char *parse_u8_substr(char *str, 
	uint8_t *result, char delim, uint8_t min, uint8_t max);
char *parse_u16_substr(char *str, 
	uint16_t *result, char delim, uint16_t min, uint16_t max);

char *u8_to_str_hex(char *buf, uint8_t val);
char *u16_to_str_hex(char *buf, uint16_t val);
char *u32_to_str_hex(char *buf, uint32_t val);
char *u64_to_str_hex(char *buf, uint64_t val);

char *u8_to_str(char *buf, uint8_t buf_len, uint8_t num);
char *u16_to_str(char *buf, uint8_t buf_len, uint16_t num);
char *u32_to_str(char *buf, uint8_t buf_len, uint32_t num);
char *u64_to_str(char *buf, uint8_t buf_len, uint64_t num);

char *u8_to_str_fixed(char *buf, uint8_t buf_len, uint8_t num);
char *u16_to_str_fixed(char *buf, uint8_t buf_len, uint16_t num);
char *u32_to_str_fixed(char *buf, uint8_t buf_len, uint32_t num);
char *u64_to_str_fixed(char *buf, uint8_t buf_len, uint64_t num);

char *s8_to_str(char *buf, uint8_t buf_len, int8_t num);
char *s16_to_str(char *buf, uint8_t buf_len, int16_t num);
char *s32_to_str(char *buf, uint8_t buf_len, int32_t num);
char *s64_to_str(char *buf, uint8_t buf_len, int64_t num);

void s16_to_dot_decimal(char *ibuf, uint8_t ibuf_len, 
	char *fbuf, uint8_t fbuf_len, 
	int16_t val, int16_t base, int16_t ref);

void u16_to_dot_decimal(char *ibuf, uint8_t ibuf_len, 
	char *fbuf, uint8_t fbuf_len, 
	uint16_t val, uint16_t base, uint16_t ref);

void float_to_dot_decimal(char *ibuf, uint8_t ibuf_len, 
	char *fbuf, uint8_t fbuf_len, float val);

void q1_15_to_dot_decimal(char *ibuf, uint8_t ibuf_len, 
	char *fbuf, uint8_t fbuf_len, q1_15 val);

void q3_29_to_dot_decimal(char *ibuf, uint8_t ibuf_len, 
	char *fbuf, uint8_t fbuf_len, q3_29 val);

void q17_15_to_dot_decimal(char *ibuf, uint8_t ibuf_len, 
	char *fbuf, uint8_t fbuf_len, q17_15 val);

void q35_29_to_dot_decimal(char *ibuf, uint8_t ibuf_len, 
	char *fbuf, uint8_t fbuf_len, q35_29 val);

void q49_15_to_dot_decimal(char *ibuf, uint8_t ibuf_len, 
	char *fbuf, uint8_t fbuf_len, q49_15 val);

uint32_t str_to_u32(const char *p, bool *error);
uint64_t str_to_u64(const char *p, bool *error);

int32_t str_to_s32(const char *p, bool *error);
int64_t str_to_s64(const char *p, bool *error);

float str_to_float(const char *p, bool *error);

#endif //__NUM2STR_H

