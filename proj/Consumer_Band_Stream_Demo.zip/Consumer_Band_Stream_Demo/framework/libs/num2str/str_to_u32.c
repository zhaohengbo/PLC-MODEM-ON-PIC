/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-08-27 19:25:56 +0200 (Fri, 27 Aug 2010) $
 * $Revision: 82 $
 * $Author:   $
 */

/**
 * @file
 * Convert a string to a 32 bit unsigned number. 
 */

#include <libs/num2str.h>

/**
 * Convert a string to a 32 bit unsigned number. 
 *
 * @param p Null-terminated string to convert
 * @param error Memory location to write status to, it will be set 
 * 	to true if conversion was unsuccessful, otherwise false
 * @return Unsigned 32 bit result
 */
uint32_t str_to_u32(const char *p, bool *error)
{
    const char *s = p;
    uint32_t val = 0;

    (*error) = false;

    if ((*s) == 0)
    {
        (*error) = true;
        return 0;
    }

    if (((*s) == '0') && ((*(s + 1)) == 'x'))
    {
        // decode HEX
        s += 2;
        while (*s)
        {
            //val *= 16;
            val <<= 4;
            if (*s >= '0' && *s <= '9')
            {
                val += *s - '0';
            }
            else if (*s >= 'a' && *s <= 'f')
            {
                val += *s - 'a' + 10;
            }
            else
            {
                (*error) = true;
                break;
            }
            s++;
        }
    }
    else
    {
        // decode DEC
        while (*s)
        {
            val *= 10;
            //10*x == 2*x+8*x
            //val = (val<<3)+(val<<1);
            if (*s >= '0' && *s <= '9')
            {
                val += *s - '0';
            }
            else
            {
                (*error) = true;
                break;
            }
            s++;
        }
    }

    return val;
}

