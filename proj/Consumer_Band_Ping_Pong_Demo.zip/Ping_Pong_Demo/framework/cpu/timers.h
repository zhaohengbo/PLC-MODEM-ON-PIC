/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-08-27 19:25:56 +0200 (Fri, 27 Aug 2010) $
 * $Revision: 82 $
 * $Author:   $
 */

/**
 * @file
 * Timer definitions. 
 */

#ifndef __TIMERS_H
#define __TIMERS_H

/** @name Timer configuration macros
 */
/*@{*/
#define timer1_set_period(period) PR1 = period
#define timer1_get_period() PR1

#define timer2_set_period(period) PR2 = period
#define timer2_get_period() PR2

#define timer3_set_period(period) PR3 = period
#define timer3_get_period() PR3

#define timer4_set_period(period) PR4 = period
#define timer4_get_period() PR4

#define timer5_set_period(period) PR5 = period
#define timer5_get_period() PR5

#define timer1_on() T1CONbits.TON = 1
#define timer2_on() T2CONbits.TON = 1
#define timer3_on() T3CONbits.TON = 1
#define timer4_on() T4CONbits.TON = 1
#define timer5_on() T5CONbits.TON = 1

#define timer1_off() T1CONbits.TON = 0
#define timer2_off() T2CONbits.TON = 0
#define timer3_off() T3CONbits.TON = 0
#define timer4_off() T4CONbits.TON = 0
#define timer5_off() T5CONbits.TON = 0
/*@}*/

/** @name A-Type timers - TxCON register bits */
/*@{*/
/** Timer on/off */
#define TIMERA_TON 0x8000
/** Idle mode operation */
#define TIMERA_TSIDL 0x2000
/** Gated time accumulation. TCS must be set to �0� when TGATE = 1 */
#define TIMERA_TGATE 0x0040
/** Timer prescaler assignment */
#define TIMERA_TCKPS 0x0030
/** Timer clock synchronization. When TCS = 0 this bit is ignored. */
#define TIMERA_TSYNC 0x0004
/** Timer clock selection */
#define TIMERA_TCS 0x0002
/*@}*/

/** @name A-Type timers - TxCON defines. 
 * Constants should be or'ed together.
 */
/*@{*/
/** Timer ON */
#define TIMERA_ON TIMERA_TON
/** Timer OFF */
#define TIMERA_OFF 0x0000
/** Stop timer when in IDLE mode */
#define TIMERA_STOP_IDLE TIMERA_TSIDL
/** Run in IDLE mode */
#define TIMERA_RUN_IDLE 0x0000
/** Gated time accumulation enabled */
#define TIMERA_GATE_EN TIMERA_TGATE
/** Gated time accumulation disabled */
#define TIMERA_GATE_DIS 0x0000
/** 1:256 prescale value */
#define TIMERA_TCKPS_1_256 0x0030
/** 1:64 prescale value */
#define TIMERA_TCKPS_1_64 0x0020
/** 1:8 prescale value */
#define TIMERA_TCKPS_1_8 0x0010
/** 1:1 prescale value */
#define TIMERA_TCKPS_1_1 0x0000
/** Synchronize external clock input */
#define TIMERA_TSYNC_ON TIMERA_TSYNC
/** Do not synchronize external clock input */
#define TIMERA_TSYNC_OFF 0x0000
/** External clock from pin TxCK */
#define TIMERA_EXTCLK TIMERA_TCS
/** Internal clock (FOSC/4) */
#define TIMERA_INTCLK 0x0000
/*@}*/

/** @name B-Type timers - TxCON register bits */
/*@{*/
/** Timer on/off */
#define TIMERB_TON 0x8000
/** Idle mode operation */
#define TIMERB_TSIDL 0x2000
/** Gated time accumulation. TCS must be set to �0� when TGATE = 1 */
#define TIMERB_TGATE 0x0040
/** Timer prescaler assignment */
#define TIMERB_TCKPS 0x0030
/** 16 or 32-bit operation mode */
#define TIMERB_T32 0x0008
/** Timer clock selection */
#define TIMERB_TCS 0x0002
/*@}*/

/** @name B-Type timers - TxCON defines. 
 * Constants should be or'ed together.
 */
/*@{*/
/** Timer ON */
#define TIMERB_ON TIMERB_TON
/** Timer OFF */
#define TIMERB_OFF 0x0000
/** Stop timer when in IDLE mode */
#define TIMERB_STOP_IDLE TIMERB_TSIDL
/** Run in IDLE mode */
#define TIMERB_RUN_IDLE 0x0000
/** Gated time accumulation enabled */
#define TIMERB_GATE_EN TIMERB_TGATE
/** Gated time accumulation disabled */
#define TIMERB_GATE_DIS 0x0000
/** 1:256 prescale value */
#define TIMERB_TCKPS_1_256 0x0030
/** 1:64 prescale value */
#define TIMERB_TCKPS_1_64 0x0020
/** 1:8 prescale value */
#define TIMERB_TCKPS_1_8 0x0010
/** 1:1 prescale value */
#define TIMERB_TCKPS_1_1 0x0000
/** TMRx and TMRy form a 32-bit timer */
#define TIMERB_32 TIMERB_T32
/** TMRx and TMRy form two separate 16-bit timers */
#define TIMERB_16 0x0000
/** External clock from pin TxCK */
#define TIMERB_EXTCLK TIMERB_TCS
/** Internal clock (FOSC/4) */
#define TIMERB_INTCLK 0x0000
/*@}*/

/** @name C-Type timers - TxCON register bits */
/*@{*/
/** Timer on/off */
#define TIMERC_TON 0x8000
/** Idle mode operation */
#define TIMERC_TSIDL 0x2000
/** Gated time accumulation. TCS must be set to �0� when TGATE = 1 */
#define TIMERC_TGATE 0x0040
/** Timer prescaler assignment */
#define TIMERC_TCKPS 0x0030
/** Timer clock selection */
#define TIMERC_TCS 0x0002
/*@}*/

/** @name C-Type timers - TxCON defines. 
 * Constants should be or'ed together.
 */
/*@{*/
/** Timer ON */
#define TIMERC_ON TIMERC_TON
/** Timer OFF */
#define TIMERC_OFF 0x0000
/** Stop timer when in IDLE mode */
#define TIMERC_STOP_IDLE TIMERC_TSIDL
/** Run in IDLE mode */
#define TIMERC_RUN_IDLE 0x0000
/** Gated time accumulation enabled */
#define TIMERC_GATE_EN TIMERC_TGATE
/** Gated time accumulation disabled */
#define TIMERC_GATE_DIS 0x0000
/** 1:256 prescale value */
#define TIMERC_TCKPS_1_256 0x0030
/** 1:64 prescale value */
#define TIMERC_TCKPS_1_64 0x0020
/** 1:8 prescale value */
#define TIMERC_TCKPS_1_8 0x0010
/** 1:1 prescale value */
#define TIMERC_TCKPS_1_1 0x0000
/** External clock from pin TxCK */
#define TIMERC_EXTCLK TIMERC_TCS
/** Internal clock (FOSC/4) */
#define TIMERC_INTCLK 0x0000
/*@}*/

#endif //__TIMERS_H

