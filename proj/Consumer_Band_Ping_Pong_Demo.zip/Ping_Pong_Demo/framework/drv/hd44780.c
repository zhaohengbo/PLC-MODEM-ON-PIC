/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-08-27 19:25:56 +0200 (Fri, 27 Aug 2010) $
 * $Revision: 82 $
 * $Author:   $
 */

/**
 * @file
 * Driver for HD44780-based LCDs.
 */

#include <config.h>
#include <cpu/types.h>

#include <string.h>

#include <drv/hd44780.h>
#include <sys/timebase.h>

#define DEBUG_CONTEXT HD44780
#include <sys/debug.h>

/** @cond NONDOC */
/* Address setup time (RS, RW to E): 60 ns */
#define SETUP_TIME 3
/* Enable pulse width: 450 ns */
#define PULSE_WIDTH 31
/* Data delay time: 360 ns */
#define DATA_DELAY 15
/* Data hold time: 10 ns */
#define HOLD_TIME 1

/** @endcond */

static void blocking_wait(int count)
{
    int i;
    for (i = 0; i < count; i++)
    {
        Nop();
    }
}

/* Single static instance of the HD44780 LCD controller */
static struct hd44780 lcd;

/* 'E' strobe for write operations */
static void e_wr_strobe(void)
{
    C_HD44780_DATA_TRIS &= 0xff00;
    blocking_wait(SETUP_TIME);
    C_HD44780_E = 1;
    blocking_wait(PULSE_WIDTH);
    C_HD44780_E = 0;
    blocking_wait(HOLD_TIME);
    C_HD44780_DATA_TRIS |= 0x00ff;
}

#if 0

/* 'E' strobe for read operations */
static char e_rd_strobe(void)
{
    char result;
    blocking_wait(SETUP_TIME);
    C_HD44780_E = 1;
    blocking_wait(DATA_DELAY);
    result = C_HD44780_DATA;
    C_HD44780_E = 0;
    return result;
}
#endif //0

/** 
 * Execute a command. See command codes in the header file. 
 * @param code Command code
 */
static void write_cmd(char code)
{
    C_HD44780_RS = 0;
    C_HD44780_RW = 0;
    C_HD44780_DATA = code;
    e_wr_strobe();
}

#if 0

/** 
 * Read busy flag and address.  
 * @return Busy flag and current address. 
 */
static char read_status(void)
{
    C_HD44780_RS = 0;
    C_HD44780_RW = 1;
    return e_rd_strobe();
}
#endif //0

/** 
 * Write the current RAM cell. 
 * @param data Data byte to write
 */
static void write_ram(char data)
{
    C_HD44780_RS = 1;
    C_HD44780_RW = 0;
    C_HD44780_DATA = data;
    e_wr_strobe();
}

#if 0

/** 
 * Read the current RAM cell. 
 * @return RAM cell contents
 */
static char read_ram(void)
{
    C_HD44780_RS = 1;
    C_HD44780_RW = 1;
    return e_rd_strobe();
}
#endif //0

/* Public API starts here */

/**
 * Do all required initialization steps. 
 * Execute only once. 
 */
void hd44780_init(void)
{
    int i;
    memset(&lcd, 0, sizeof (lcd));
    for (i = 0; i < C_HD44780_LINES; i++)
    {
        memset(&lcd.lines[i].data, ' ', C_HD44780_CHARACTERS);
    }

    C_HD44780_E = 0;
    C_HD44780_RW_TRIS = 0;
    C_HD44780_RS_TRIS = 0;
    C_HD44780_E_TRIS = 0;
    C_HD44780_DATA_TRIS |= 0x00ff;

    lcd.state = HD44780_STATE_FUNC_SET;
}

/**
 * Check if the display can accept commands. 
 * @return True, if the Busy Flag is clear
 */
bool hd44780_ready(void)
{
    if (!time_after(lcd.timeout))
    {
        return false;
    }
    return true;
}

/**
 * Clear the LCD. 
 * This function accesses the framebuffer. Data is copied 
 * to the LCD RAM in the hd44780_poll() function. 
 */
void hd44780_clear(void)
{
    int i;
    for (i = 0; i < C_HD44780_LINES; i++)
    {
        lcd.lines[i].update = true;
        memset(lcd.lines[i].data, ' ', sizeof (lcd.lines[i].data));
    }
}

/**
 * Write data to the LCD. 
 * This function accesses the framebuffer. Data is copied 
 * to the LCD RAM in the hd44780_poll() function. 
 * @param buf Buffer with the data to write
 * @param pos Line position to start from
 * @param len Number of bytes to write
 * @param line Line number
 */
void hd44780_write(const char buf[], int pos, int len, int line)
{
    int i;
    if (line >= C_HD44780_LINES)
    {
        return;
    }

    lcd.lines[line].update = true;
    for (i = pos; (i < pos + len) && (i < C_HD44780_CHARACTERS); i++)
    {
        lcd.lines[line].data[i] = buf[i - pos];
    }
}

/** 
 * The polling function. Must be executed periodically, but there 
 * are absolutely no restrictions on the execution frequency 
 * or regularity. 
 */
void hd44780_poll(void)
{
    if (!hd44780_ready())
    {
        return;
    }

    lcd.timeout = time_get_timeout(J_MSEC);

    switch (lcd.state)
    {
    case HD44780_STATE_FUNC_SET:
        DEBUG_VERBOSE("hd44780: function set\r\n");
        /* Function Set: 2-line, display on */
        write_cmd(HD44780_CMD_FUNC_SET | 0x1C);
        lcd.state = HD44780_STATE_ON_OFF_CTRL;
        break;
    case HD44780_STATE_ON_OFF_CTRL:
        DEBUG_VERBOSE("hd44780: on/off ctrl\r\n");
        /* Display On/Off Control: display on, cursor off, blink off */
        write_cmd(HD44780_CMD_ON_OFF_CTRL | 0x04);
        lcd.state = HD44780_STATE_CLEAR_DISP;
        break;
    case HD44780_STATE_CLEAR_DISP:
        DEBUG_VERBOSE("hd44780: clear\r\n");
        /* Display Clear */
        write_cmd(HD44780_CMD_CLEAR_DISP);
        lcd.state = HD44780_STATE_ENTRY_MODE_SET;
        break;
    case HD44780_STATE_ENTRY_MODE_SET:
        DEBUG_VERBOSE("hd44780: entry mode set\r\n");
        /* Entry Mode Set: increment mode, entire shift off */
        write_cmd(HD44780_CMD_ENTRY_MODE_SET | 0x02);
        lcd.state = HD44780_STATE_CHECK_UPDATE_LINE0;
        break;
    case HD44780_STATE_CHECK_UPDATE_LINE0:
        if (lcd.lines[0].update)
        {
            lcd.lines[0].update = false;
            write_cmd(HD44780_CMD_SET_DDADDR | HD44780_ADDR_LINE0);
            lcd.update_ptr = 0;
            lcd.state = HD44780_STATE_UPDATE_LINE0;
        }
        else
        {
            lcd.state = HD44780_STATE_CHECK_UPDATE_LINE1;
        }
        break;
    case HD44780_STATE_UPDATE_LINE0:
        DEBUG_VERBOSE("hd44780: update line 0\r\n");
        if (lcd.update_ptr < C_HD44780_CHARACTERS)
        {
            write_ram(lcd.lines[0].data[lcd.update_ptr++]);
        }
        else
        {
            lcd.state = HD44780_STATE_CHECK_UPDATE_LINE1;
        }
        break;
    case HD44780_STATE_CHECK_UPDATE_LINE1:
        if (lcd.lines[1].update)
        {
            lcd.lines[1].update = false;
            write_cmd(HD44780_CMD_SET_DDADDR | HD44780_ADDR_LINE1);
            lcd.update_ptr = 0;
            lcd.state = HD44780_STATE_UPDATE_LINE1;
        }
        else
        {
            lcd.state = HD44780_STATE_CHECK_UPDATE_LINE0;
        }
        break;
    case HD44780_STATE_UPDATE_LINE1:
    default:
        DEBUG_VERBOSE("hd44780: update line 1\r\n");
        if (lcd.update_ptr < C_HD44780_CHARACTERS)
        {
            write_ram(lcd.lines[1].data[lcd.update_ptr++]);
        }
        else
        {
            lcd.state = HD44780_STATE_CHECK_UPDATE_LINE0;
        }
        break;
    };
}

