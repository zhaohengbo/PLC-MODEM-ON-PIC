/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-09-01 09:54:39 +0200 (Wed, 01 Sep 2010) $
 * $Revision: 83 $
 * $Author:   $
 */

#ifndef __CONFIG_FEC_H
#define __CONFIG_FEC_H

/** 
 * @file
 * Template of the FEC configuration file. It should be included 
 * in the master configuration file. 
 *
 * If you wish to do application-specific modifications, you should copy 
 * this file to the application directory, to a location in the include search 
 * path and modify it there. Modifications in the template will affect 
 * all the applications that do not use a local modified copy. 
 */

/** Enable or disable the FEC encoder that encodes 8 bits at a time */
#define FEC_BYTE_ENC (ENABLED)
/** Enable or disable the FEC encoder that encodes 1 bit at a time */
#define FEC_BIT_ENC (DISABLED)

/** 
 * Enable or disable the single pass FEC decoder. It takes two bits of 
 * encoded message and produces an estimate in a single call to fec_decode(). 
 * Be warned, that 'fec_decode()' takes a long time to execute (the actual
 * time depends on the number of code states (the constraint length)). 
 */ 
#define FEC_SINGLE_PASS (DISABLED)

/**
 * Enable or disable the multi pass FEC decoder. The decoding procedure is
 * split to 3 stages: fec_decode_start(), fec_decode_pass() that must be 
 * executed at least as many times, as there are code states, and 
 * fec_decode_final() that produces the message estimate. This method
 * can be used in cases when a single call to fec_decode() would block
 * the CPU for too long. 
 */
#define FEC_MULTI_PASS (ENABLED)

/** 
 * Implementations of the single bit encoder. 
 * The 8-bit encoder always uses graph. 
 */
/*@{*/
/** Use polynomials directly, inefficient as it uses a lot of bit arithmetic */
#define FEC_ENCODER_POLY 1
/** Use graph. Use this one, as it is fast */
#define FEC_ENCODER_GRAPH 2
/*@}*/

/** Choose the encoder implementation (use graph, unless learning) */
#define FEC_ENCODER (FEC_ENCODER_GRAPH)

/**
 * Available convolutional codes. 
 */
/*@{*/
/** Textbook code from Haykin's "Communication Systems". For learnerns. 
 *  Constraint length is 3. Fast (only 4 states) but very limited performance.
 */ 
#define HAYKIN 1
/** The code taken from the Prime Alliance's specification. 
 *  Constraint length is 7 (64 states), free distance is 10. 
 */
#define PRIME 2
/*@}*/

/** Choose your code */
#define FEC_CODE PRIME

#endif //__CONFIG_FEC_H

