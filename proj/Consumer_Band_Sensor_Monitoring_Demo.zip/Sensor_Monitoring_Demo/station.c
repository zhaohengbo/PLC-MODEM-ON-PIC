/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-11-05 16:48:49 +0100 (Fri, 05 Nov 2010) $
 * $Revision: 88 $
 * $Author:   $
 */

#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <config.h>
#include <cpu/adc.h>
#include <cpu/cpu.h>
#include <cpu/types.h>
#include <cpu/int.h>
#include <cpu/osc.h>
#include <drv/hd44780.h>
#include <net/net.h>
#include <net/proto/tmap.h>
#include <net/bdev/sw_plm.h>
#include <libs/num2str.h>

#include <common/plm.h>

#define DEBUG_CONTEXT MAIN
#include <sys/debug.h>
#include <sys/timebase.h>

#ifdef __dsPIC33F__
/** Primary oscillator is XT, switching is enabled, monitor is disabled */
_FOSC(FCKSM_CSECMD & OSCIOFNC_OFF & POSCMD_XT);
/** Start from the internal Fast RC clock */
_FOSCSEL(FNOSC_FRC & IESO_OFF);
/** Maximum power-up timer delay */
_FPOR(FPWRT_PWR128);
/** WDT by default is off, may be turned on with RCON.SWDTEN, 512 ms timeout */
_FWDT(FWDTEN_OFF & WINDIS_OFF & WDTPRE_PR32 & WDTPOST_PS512);
/** No Boot Sector */
_FBS(RBS_NO_RAM & BSS_NO_FLASH & BWRP_WRPROTECT_OFF);
/** No Secure Segment */
_FSS(RSS_NO_RAM & SSS_NO_FLASH & SWRP_WRPROTECT_OFF);
/** No code protection */
_FGS(GSS_OFF & GCP_OFF & GWRP_OFF);
#endif //__dsPIC33F__

#if 0
#define BUF_LEN 2048
uint16_t buf[BUF_LEN];
uint16_t bufptr = 0;

void buf_add(uint16_t sample)
{
    buf[bufptr++ & 0x7ff] = sample;
    buf[bufptr & 0x7ff] = 0xdead;
}
#endif //0

#define STATION_MAC 0x1234
#define BUTTON PORTDbits.RD6

/* TMAP device associated with the power line modem */
static struct tmap_dev modem;

/* Node data structure. We can talk to a number of nodes. */
struct node_data
{
    uint16_t mac;
    int16_t adc_value;
    jiffie_t time;
    bool valid;
};

/* Data from all nodes */
#define NUM_NODES 2
static struct node_data nodes[NUM_NODES];

/* LCD views. Switched with a button press */
typedef enum
{
    LCD_VIEW_VALUES,
    LCD_VIEW_STATS
} lcd_view_t;

/* Current LCD view */
static lcd_view_t lcd_view = LCD_VIEW_VALUES;
/* Time to elapse before the LCD is refreshed */
static jiffie_t lcd_update_tout = 0;

/* Button is pressed: switch the LCD view */
static void button_press_event(void)
{
    lcd_view++;
    if (lcd_view > LCD_VIEW_STATS)
    {
        lcd_view = 0;
    }
    hd44780_clear();
    lcd_update_tout = time_now();
}

/* Button states */
typedef enum
{
    BUTTON_STAT_DEPRESSED,
    BUTTON_STAT_DEBOUNCE,
    BUTTON_STAT_REPEAT
} bstat_t;

#define BUTTON_DEBOUNCE_TOUT (100*J_MSEC)
#define BUTTON_REPEAT_TOUT (2*J_SEC)

/* Current button state */
static bstat_t button_state = BUTTON_STAT_DEPRESSED;
/* Button timeout, used for debouncing and repeated events */
static jiffie_t button_tout;

/* Start the button */
static void button_start(void)
{
    TRISDbits.TRISD6 = 1;
}

/* Poll the button that switches LCD views */
static void button_poll(void)
{
    bool pressed = (BUTTON == 0);

    switch (button_state)
    {
    case BUTTON_STAT_DEBOUNCE:
        if (!pressed)
        {
            button_state = BUTTON_STAT_DEPRESSED;
            break;
        }

        if (!time_after(button_tout))
        {
            break;
        }
        button_press_event();

        button_state = BUTTON_STAT_REPEAT;
        button_tout = time_get_timeout(BUTTON_REPEAT_TOUT);
        break;
    case BUTTON_STAT_REPEAT:
        if (!pressed)
        {
            button_state = BUTTON_STAT_DEPRESSED;
            break;
        }
        if (time_after(button_tout))
        {
            button_tout = time_get_timeout(BUTTON_REPEAT_TOUT);
            button_press_event();
        }
        break;
    case BUTTON_STAT_DEPRESSED:
    default:
        if (pressed)
        {
            button_state = BUTTON_STAT_DEBOUNCE;
            button_tout = time_get_timeout(BUTTON_DEBOUNCE_TOUT);
        }
        break;
    }
}

/* Start station communications */
static void station_start(void)
{
    memset(&nodes, 0, sizeof (nodes));
}

/* Find node entry to update */
static struct node_data *find_node(uint16_t mac)
{
    int i, j;
    /* 1: find matching node */
    for (i = 0; i < NUM_NODES; i++)
    {
        if (nodes[i].mac == mac)
        {
            return &nodes[i];
        }
    }
    /* 2: find empty node */
    for (i = 0; i < NUM_NODES; i++)
    {
        if (nodes[i].valid == false)
        {
            return &nodes[i];
        }
    }
    /* 3: find oldest node */
    j = 0;
    for (i = 0; i < NUM_NODES; i++)
    {
        if (((long) nodes[j].time - (long) nodes[i].time < 0))
        {
            j = i;
        }
    }
    return &nodes[j];
}

/* Time after which nodes expire */
#define NODE_EXPIRY (20*J_SEC)

/* Expire nodes that were updated long time ago */
static void expire_nodes(void)
{
    int i;
    for (i = 0; i < NUM_NODES; i++)
    {
        if (time_after(nodes[i].time + NODE_EXPIRY))
        {
            nodes[i].valid = false;
        }
        if (nodes[i].valid == false)
        {
            if (i < NUM_NODES - 1)
            {
                nodes[i] = nodes[i + 1];
                memset(&nodes[i + 1], 0, sizeof (nodes[i + 1]));
            }
            else
            {
                memset(&nodes[i], 0, sizeof (nodes[i]));
            }
        }
    }
}

/* Poll station communications. 
 * Receive packets from nodes and acknowledge them. 
 */
static void station_poll(void)
{
    struct tmap_header header;
    struct node_data *node;
    struct nbuf *nb;
    uint16_t len;
    uint8_t seq;

    expire_nodes();

    /* Try receiving a packet */
    nb = tmap_recv(&modem, &header);
    if (!nb)
    {
        return;
    }
    DEBUG_INFO("Received buffer:\r\n");

    DEBUG_INFO(" - ttl: ");
    DEBUG_INFO_U8(header.ttl);
    DEBUG_INFO("\r\n");

    DEBUG_INFO(" - smac: ");
    DEBUG_INFO_U16(header.smac);
    DEBUG_INFO("\r\n");

    DEBUG_INFO(" - dmac: ");
    DEBUG_INFO_U16(header.dmac);
    DEBUG_INFO("\r\n");

    len = nb->end - nb->pos;
    DEBUG_INFO(" - data len: ");
    DEBUG_INFO_U8(len);
    DEBUG_INFO("\r\n\r\n");

    /* Expected frame data format:
     *  seq (1 byte)  : Sequence Number
     *  val (2 bytes) : ADC Reading
     */
    if (len != 3)
    {
        DEBUG_WARN("Unexpected packet length\r\n");
        nbuf_deref(nb);
        return;
    }

    node = find_node(header.smac);
    node->mac = header.smac;
    seq = nbuf_fwd_read_byte(nb);
    node->adc_value = nbuf_fwd_read_word(nb);
    node->time = time_now();
    node->valid = true;

    nbuf_deref(nb);

    /* Send an acknowledge.
     *  seq (1 byte)  : Sequence Number
     */
    nb = nbuf_pool_get_with_offs(TMAP_PREAMBLE_LEN + TMAP_OVERHEAD - 2);
    if (!nb)
    {
        DEBUG_WARN("Out of nbufs\r\n");
        return;
    }

    if (!nbuf_fwd_make_space(nb, 1))
    {
        DEBUG_WARN("No space\r\n");
        nbuf_deref(nb);
        return;
    }
    nbuf_fwd_write_byte(nb, seq);

    header.ttl = 1;
    header.smac = modem.my_mac;
    header.dmac = node->mac;

    DEBUG_INFO("Sending ACK frame\r\n");
    if (!tmap_send(&modem, nb, &header))
    {
        DEBUG_WARN("Could not send ACK frame\r\n");
    }
    nbuf_deref(nb);
}

/* Start LEDs */
static void leds_start(void)
{
    TRISAbits.TRISA0 = 0;
    LATAbits.LATA0 = 0;
    TRISAbits.TRISA1 = 0;
    LATAbits.LATA1 = 0;
    TRISAbits.TRISA2 = 0;
    LATAbits.LATA2 = 0;
    TRISAbits.TRISA3 = 0;
    LATAbits.LATA3 = 0;
}

/* Show modem status on LEDs */
static void show_led_status(void)
{
    uint16_t status = plm_get_status();
    LATAbits.LATA0 = (status & PLM_TX_ACTIVE_MASK) ? 1 : 0;
    LATAbits.LATA1 = (status & PLM_BYTE_SYNC_MASK) ? 1 : 0;
    LATAbits.LATA2 = (status & PLM_BIT_SYNC_MASK) ? 1 : 0;
}

/* LCD view handlers */

/* Print to the LCD values received via powerline */
static void lcd_show_values(void)
{
    char buf[5];

    if (!time_after(lcd_update_tout))
    {
        return;
    }
    lcd_update_tout = time_get_timeout(200 * J_MSEC);

    //-------------0123456789abcdef
    hd44780_write("A:              ", 0, 16, 0);
    if (nodes[0].valid)
    {
        u16_to_str_hex(buf, nodes[0].mac);
        hd44780_write(buf, 3, 4, 0);
    }

    hd44780_write(" V: ", 7, 4, 0);
    if (nodes[0].valid)
    {
        u16_to_str_hex(buf, nodes[0].adc_value);
        hd44780_write(buf, 11, 4, 0);
    }

    //-------------0123456789abcdef
    hd44780_write("A:              ", 0, 16, 1);
    if (nodes[1].valid)
    {
        u16_to_str_hex(buf, nodes[1].mac);
        hd44780_write(buf, 3, 4, 1);
    }

    hd44780_write(" V: ", 7, 4, 1);
    if (nodes[1].valid)
    {
        u16_to_str_hex(buf, nodes[1].adc_value);
        hd44780_write(buf, 11, 4, 1);
    }
}

/* Print packet statistics to the LCD */
static void lcd_show_stats(void)
{
    char buf[5];

    if (!time_after(lcd_update_tout))
    {
        return;
    }
    lcd_update_tout = time_get_timeout(20 * J_MSEC);

    //-------------0123456789abcdef
    hd44780_write("TX:  RX:  Err:  ", 0, 16, 0);

    u16_to_str_fixed(buf, sizeof (buf),
                     modem.stats.tx_packets % 10000);
    hd44780_write(buf, 0, 4, 1);

    u16_to_str_fixed(buf, sizeof (buf),
                     modem.stats.rx_packets % 10000);
    hd44780_write(buf, 5, 4, 1);

    u16_to_str_fixed(buf, sizeof (buf),
                     modem.stats.rx_frame_errors % 10000);
    hd44780_write(buf, 10, 4, 1);
}

/* Select what to print depending on the current LCD view */
static void show_lcd_status(void)
{
    switch (lcd_view)
    {
    case LCD_VIEW_VALUES:
        lcd_show_values();
        break;
    case LCD_VIEW_STATS:
    default:
        lcd_show_stats();
        break;
    };
}

int main(void)
{
#ifdef INT_USE_AIVT
    _ALTIVT = 1;
#else
    _ALTIVT = 0;
#endif //
    int_global_enable();

    /* Set the required DSP engine configuration
     *  - the other bits assumed to be in the default reset state.
     */
    CORCONbits.ACCSAT = 1;
    CORCONbits.SATA = 1;
    CORCONbits.SATB = 1;

#ifdef __dsPIC33F__
    /* We have 8MHz XTAL on Explorer16
     * Fvco = Fin * (PLLDIV+2) / (PLLPRE+2)
     * Fvco must be in the range 100..200 MHz
     * Fpfd = Fvco / (PLLDIV+2) must be in the range 0.8..8 MHz
     * Fosc = Fvco / (2*(PLLPOST+1))
     * Fcy  = Fosc / 2
     */
    //_PLLDIV = 78;   //80: 8MHz * (78+2) = 640MHz
    //_PLLPRE = 2;    // 4: Fvco = 640MHz / (2+2) = 160MHz, Fpfd = 2MHz
    //_PLLPOST = 0;   // 2: Fosc = 160MHz / 2 = 80MHz

    osc_set_pll(PLLPRE_4, PLLPOST_2, 80);
    osc_do_switch(OSCSEL_PRIPLL);

    while (!osc_switch_complete());
    while (!pll_has_lock());
#endif //__dsPIC33F__

    adc_set_all_digital();

    net_pools_init();
    debug_init();
    timebase_init();
    sw_plm_init();
    hd44780_init();
    tmap_init(&modem, STATION_MAC);

    timebase_start();
    sw_plm_start();
    tmap_start(&modem, sw_plm_get_handle());

    /*
    tmap_set_flags(&modem,
            TMAP_DEV_FLAG_REPEATER|TMAP_DEV_FLAG_PROMISC);
     */

    button_start();
    leds_start();
    station_start();

    DEBUG_INFO("PLM Demo Started!\r\n");
    DEBUG_INFO("This is a station and has MAC address 0x");
    DEBUG_INFO_U16(modem.my_mac);
    DEBUG_INFO("\r\n");

    while (1)
    {
        /* Poll background tasks */
        hd44780_poll();
        sw_plm_poll();
        tmap_poll(&modem);

        /* Poll top level threads */
        button_poll();
        station_poll();
        show_led_status();
        show_lcd_status();
    }
}

