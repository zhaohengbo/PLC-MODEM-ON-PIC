/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-10-22 16:00:58 +0200 (Fri, 22 Oct 2010) $
 * $Revision: 85 $
 * $Author:   $
 */

/** 
 * @file
 * Time base generation. 
 */

#ifndef __TIMEBASE_H
#define __TIMEBASE_H

#include <config.h>
#include <cpu/types.h>

/**
 * Type used for system 'jiffies'. 
 * Jiffies are used for longer timeouts. 
 */
typedef uint32_t jiffie_t;

jiffie_t time_now(void);
bool time_after(jiffie_t when);
jiffie_t time_get_timeout(jiffie_t period);

/**
 * Jiffie timer prescale rate. 
 * 1 jiffie corresponds to 64 system clocks (prescale rate 1:64)
 *  --> 1 jiffie lasts 64/Fcy [sec]
 *  --> t [sec] correspond to (Fcy * t)/64 jiffies
 *
 * Example: at Fcy = 19.6608MHz 
 *  --> 1 jiffie lasts 3.255 us
 *  --> 1 sec is 307200 jiffies
 *  --> timer overflows every 213.34 ms (4.6875 Hz)
 */
#define J_PRESCALE 64

/** Number of jiffies per milisecond (may be inaccurate) */
#define J_MSEC (1ul*FCY/(1ul*J_PRESCALE*1000))
/** Number of jiffies per second (may be inaccurate) */
#define J_SEC (1ul*FCY/(1ul*J_PRESCALE))
/** Number of jiffies per minute (may be inaccurate) */
#define J_MIN (60ul*FCY/(1ul*J_PRESCALE))

/** Maximum number of seconds that can be stored in 32-bits of jiffies */
#define JIFFIE32_MAX_SEC (4294967295ull * J_PRESCALE / FCY)
/** Maximum number of miliseconds that can be stored in 32-bits of jiffies */
#define JIFFIE32_MAX_MSEC (4294967295ull * 1000 * J_PRESCALE / FCY)
/** Maximum number of microseconds that can be stored in 32-bits of jiffies */
#define JIFFIE32_MAX_USEC (4294967295ull * 1000000 * J_PRESCALE / FCY)

/** Maximum number of seconds that can be stored in 16-bits of jiffies */
#define JIFFIE16_MAX_SEC (65535ul * J_PRESCALE / FCY)
/** Maximum number of miliseconds that can be stored in 16-bits of jiffies */
#define JIFFIE16_MAX_MSEC (65535ul * 1000 * J_PRESCALE / FCY)
/** Maximum number of microseconds that can be stored in 16-bits of jiffies */
#define JIFFIE16_MAX_USEC (65535ull * 1000000 * J_PRESCALE / FCY)

/** 
 * CPU cycle count type. It is guaranteed to be able to hold cycle
 * count for 60 seconds. Never assume more. 
 *
 * Architectures: 
 *    - PIC24FJ  : 16MHz --> 268 seconds
 *    - PIC24HJ  : 40MHz --> 107 seconds
 *    - dsPIC30F : 30MHz --> 143 seconds
 *    - dsPIC33F : 40MHz --> 107 seconds
 * 
 * @see CYCLE_T_MAX_SECONDS
 */
typedef uint32_t cycle_t;

/** 
 * Maximum time in seconds during which CPU cycles can be counted without 
 * overflowing the cycle_t type. 
 */
#define CYCLE_T_MAX_SEC 60

/** @name Time types */
/*@{*/
typedef uint32_t usec_t;
typedef uint16_t msec_t;
typedef uint16_t sec_t;
/*@}*/

/** Maximum number of jiffies that can be stored in 16-bits of seconds */
#define SEC_T_MAX_JIFFIES (65535ull*FCY/J_PRESCALE)
/** Maximum number of jiffies that can be stored in 16-bits of miliseconds */
#define MSEC_T_MAX_JIFFIES (65535ull*FCY/J_PRESCALE/1000)
/** Maximum number of jiffies that can be stored in 32-bits of microseconds */
#define USEC_T_MAX_JIFFIES (4294967295ull*FCY/J_PRESCALE/1000000)

#if 0
/* These functions are huge, unused and have been #ifdef'ed out
 * in timebase.c 
 */

cycle_t usec_to_cyc(usec_t t);
cycle_t msec_to_cyc(msec_t t);
cycle_t sec_to_cyc(sec_t t);

jiffie_t usec_to_jiffie(usec_t t);
jiffie_t msec_to_jiffie(msec_t t);
jiffie_t sec_to_jiffie(sec_t t);

usec_t jiffie_to_usec(jiffie_t t);
msec_t jiffie_to_msec(jiffie_t t);
sec_t jiffie_to_sec(jiffie_t t);

jiffie_t cyc_to_jiffie(cycle_t cycles);
cycle_t jiffie_to_cyc(jiffie_t jiffies);
#endif //0

/**
 * Time base generator. 
 */
struct timebase {
	#ifdef HOSTED
	/* Time now. It has a low resolution (50 ms default) */
	jiffie_t now;
	#else
	/** High word of the jiffies counter */
	volatile uint16_t hjiffies;
	/** Whether hjiffies should get incremented during next read */
	volatile bool increment;
	#endif //HOSTED
};

void timebase_init(void);
void timebase_start(void);

#endif //__TIMEBASE_H

