/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-11-06 19:25:53 +0100 (Sat, 06 Nov 2010) $
 * $Revision: 90 $
 * $Author:   $
 */

/**
 * @file
 * Debug message printing. 
 * Each part of code should be assigned a debug context. Debug context 
 * is selected by \#defining DEBUG_CONTEXT within a 'C' file before 
 * <util/debug.h> is included. DEBUG_CONTEXT should be a descriptive 
 * single word identifier. Each debug context ought to be assigned 
 * a 'debug level'. If, for example, local debug context is 'UART' 
 * (\#define DEBUG_CONTEXT UART), then C_UART_DEBUG_LEVEL should be defined 
 * and assigned one of defined debug levels
 * (eg. \#define C_UART_DEBUG_LEVEL DEBUG_LEVEL_WARN). By using DEBUG macros 
 * (eg. DEBUG_WARN(), DEBUG_PANIC(), etc.) the programmer can assure, that 
 * debugging calls of levels weaker than given context's debug level 
 * will not even get compiled in. 
 */

#ifndef __DEBUG_H
#define __DEBUG_H

#include <config.h>
#include <cpu/types.h>
#include <cpu/cpu.h>

#if C_DEBUG_CN_NMI==ENABLED
void nmi_init(void);
#endif //C_DEBUG_CN_NMI

/**
 * @name Debug levels. 
 * Each portion of code may be assigned a debug context. For each debug 
 * context a debug level is defined. Debug messages having debug level 
 * smaller than debug level of the code they appear in are not even 
 * compiled in. 
 */
/*@{*/
#define DEBUG_LEVEL_OFF 0
#define DEBUG_LEVEL_PANIC 1
#define DEBUG_LEVEL_ERROR 2
#define DEBUG_LEVEL_WARN 3
#define DEBUG_LEVEL_INFO 4
#define DEBUG_LEVEL_VERBOSE 5
/*@}*/

/** @cond NONDOC */
#define DEBUG_LEV_HELPER(ctx) C_ ## ctx ## _DEBUG_LEVEL
#define DEBUG_LEV(ctx) DEBUG_LEV_HELPER(ctx)
/** @endcond */

#ifndef DEBUG_CONTEXT
#warning "Unknown debug context"
#define DEBUG_CONTEXT DEFAULT
#endif //DEBUG_CONTEXT

/** 
 * @name Verbose debug messages. 
 * Sent if the verbosity level is >= DEBUG_LEVEL_VERBOSE. 
 */
/*@{*/
#if DEBUG_LEV(DEBUG_CONTEXT) >= DEBUG_LEVEL_VERBOSE
#define DEBUG_VERBOSE(msg) { \
		debug_print(msg); \
	} while (0)
#define DEBUG_VERBOSE_U8(num) { \
		debug_print_byte(num); \
	} while (0)
#define DEBUG_VERBOSE_U16(num) { \
		debug_print_word(num); \
	} while (0)
#else
#define DEBUG_VERBOSE(msg)
#define DEBUG_VERBOSE_U8(num)
#define DEBUG_VERBOSE_U16(num)
#endif //DEBUG_LEV(DEBUG_CONTEXT) >= DEBUG_LEVEL_VERBOSE
/*@}*/

/** 
 * @name Informational debug messages. 
 * Sent if the verbosity level is >= DEBUG_LEVEL_INFO. 
 */
/*@{*/
#if DEBUG_LEV(DEBUG_CONTEXT) >= DEBUG_LEVEL_INFO
#define DEBUG_INFO(msg) { \
		debug_print(msg); \
	} while (0)
#define DEBUG_INFO_U8(num) { \
		debug_print_byte(num); \
	} while (0)
#define DEBUG_INFO_U16(num) { \
		debug_print_word(num); \
	} while (0)
#else
#define DEBUG_INFO(msg)
#define DEBUG_INFO_U8(num)
#define DEBUG_INFO_U16(num)
#endif //DEBUG_LEV(DEBUG_CONTEXT) >= DEBUG_LEVEL_INFO
/*@}*/

/** 
 * @name Warning debug messages. 
 * Sent if the verbosity level is >= DEBUG_LEVEL_WARN. 
 */
/*@{*/
#if DEBUG_LEV(DEBUG_CONTEXT) >= DEBUG_LEVEL_WARN
#define DEBUG_WARN(msg) { \
		debug_print(msg); \
	} while (0)
#define DEBUG_WARN_U8(num) { \
		debug_print_byte(num); \
	} while (0)
#define DEBUG_WARN_U16(num) { \
		debug_print_word(num); \
	} while (0)
#else
#define DEBUG_WARN(msg)
#define DEBUG_WARN_U8(num)
#define DEBUG_WARN_U16(num)
#endif //DEBUG_LEV(DEBUG_CONTEXT) >= DEBUG_LEVEL_WARN
/*@}*/

/** 
 * @name Error debug messages. 
 * Sent if the verbosity level is >= DEBUG_LEVEL_ERROR.  
 */
/*@{*/
#if DEBUG_LEV(DEBUG_CONTEXT) >= DEBUG_LEVEL_ERROR
#define DEBUG_ERROR(msg) { \
		debug_print(msg); \
	} while (0)
#define DEBUG_ERROR_U8(num) { \
		debug_print_byte(num); \
	} while (0)
#define DEBUG_ERROR_U16(num) { \
		debug_print_word(num); \
	} while (0)
#else
#define DEBUG_ERROR(msg)
#define DEBUG_ERROR_U8(num)
#define DEBUG_ERROR_U16(num)
#endif //DEBUG_LEV(DEBUG_CONTEXT) >= DEBUG_LEVEL_ERROR
/*@}*/

/** 
 * @name Panic debug messages. 
 * Sent if the verbosity level is >= DEBUG_LEVEL_PANIC. 
 */
/*@{*/
#if DEBUG_LEV(DEBUG_CONTEXT) >= DEBUG_LEVEL_PANIC
#define DEBUG_PANIC(msg) { \
		debug_print(msg); \
	} while (0)
#define DEBUG_PANIC_U8(num) { \
		debug_print_byte(num); \
	} while (0)
#define DEBUG_PANIC_U16(num) { \
		debug_print_word(num); \
	} while (0)
#else
#define DEBUG_PANIC(msg)
#define DEBUG_PANIC_U8(num)
#define DEBUG_PANIC_U16(num)
#endif //DEBUG_LEV(DEBUG_CONTEXT) >= DEBUG_LEVEL_PANIC
/*@}*/

/**
 * Convert a 4 bit value to an ASCII hex digit. 
 * @param val Value to convert
 * @return Corresponding hex digit
 */
char to_hex(uint8_t val);

#if C_DEBUG_MODE==ENABLED
void debug_init(void);
void debug_print(const char *msg);
void debug_print_byte(uint8_t num);
void debug_print_word(uint16_t num);

#else
#define debug_init();
#define debug_print(msg);
#define debug_print_byte(num);
#define debug_print_word(num);

#endif //C_DEBUG_MODE

#endif //__DEBUG_H

