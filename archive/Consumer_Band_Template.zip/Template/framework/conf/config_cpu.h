/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-10-22 16:00:58 +0200 (Fri, 22 Oct 2010) $
 * $Revision: 85 $
 * $Author:   $
 */

/** 
 * @file
 * Template of the CPU configuration file. 
 * It should be included in the master configuration file. Do not edit this 
 * file in the 'conf' subdirectory of the framework. Copy it to the 
 * application directory instead. 
 */

#ifndef __CONFIG_CPU_H
#define __CONFIG_CPU_H

#ifdef __dsPIC30F__
/** @name dsPIC30F oscillator settings (7.3728 MHz XTAL). 
 * Must match the actual configuration. 
 */
/*@{*/
#define P30F_FCY 29491200
#define FCY P30F_FCY
/*@}*/
#endif //__dsPIC30F__


#ifdef __dsPIC33F__
/** @name dsPIC33FJ oscillator settings (8 MHz XTAL). 
 * Must match the actual configuration. 
 */
/*@{*/
#define P33F_FCY 40000000
#define FCY P33F_FCY
/*@}*/
#endif //__dsPIC33F__

#ifdef HOSTED
/** @name Pseudo-oscillator frequency for operating system hosted applications.
 * Must be 64 MHz due to the 1 us timer resolution and fixed :64 prescale 
 * setting in the 'timebase' module. 
 */
#define FCY 64000000
#endif //HOSTED

#endif //__CONFIG_CPU_H

