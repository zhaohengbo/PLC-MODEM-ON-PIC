/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-08-27 19:25:56 +0200 (Fri, 27 Aug 2010) $
 * $Revision: 82 $
 * $Author:   $
 */

/**
 * @file
 * Compare to base and convert a signed number to dotted-decimal string. 
 */

#include <libs/num2str.h>

/**
 * Compare to base and convert a signed number to dotted-decimal string. 
 *
 * This function does not perform any range checking. It will provide
 * invalid results if the integral part (ref * val / base) 
 * does not fit in 16 bits. 
 *
 * @bug Check for overflow missing. 
 * @param ibuf Memory buffer to write the integer part to 
 * @param ibuf_len Number of characters to write to ibuf 
 * 	(including trailing null)
 * @param fbuf Memory buffer to write the fractional part to 
 * @param fbuf_len Number of characters to write to fbuf 
 * 	(including trailing null)
 * @param val Number to convert
 * @param base Maximum possible number
 * @param ref Output value when 'val' equals 'base'
 */
void s16_to_dot_decimal(char *ibuf, uint8_t ibuf_len,
                        char *fbuf, uint8_t fbuf_len,
                        int16_t val, int16_t base, int16_t ref)
{
    int32_t frac = (ref * val) % base;
    int32_t intgr = (ref * val) / base;

    if (val < 0)
    {
        ibuf[0] = '-';
        fraction_16_to_str(fbuf, fbuf_len, -frac, base);
        u16_to_str(ibuf + 1, ibuf_len - 1, -intgr);
    }
    else
    {
        fraction_16_to_str(fbuf, fbuf_len, frac, base);
        u16_to_str(ibuf, ibuf_len, intgr);
    }
}

