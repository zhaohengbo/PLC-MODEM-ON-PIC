/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-11-05 16:48:49 +0100 (Fri, 05 Nov 2010) $
 * $Revision: 88 $
 * $Author:   $
 */

#ifndef __CONFIG_PLM_H
#define __CONFIG_PLM_H

/** 
 * @file
 * Template of the PLM configuration file. It should be included 
 * in the master configuration file. 
 *
 * If you wish to do application-specific modifications, you should copy 
 * this file to the application directory, to a location in the include search 
 * path and modify it there. Modifications in the template will affect 
 * all the applications that do not use a local modified copy. 
 */

/** Output enable control methods. Check your hardware variant. 
 * PLM-E16 plugins up to 1.7 use the PLM_OE_ACTIVE_LOW_HIZ. 
 */
/*@{*/
/** Drive low to enable, high impedance to disable */
#define PLM_OE_ACTIVE_LOW_HIZ 0
/** Drive low to enable, drive high to disable */
#define PLM_OE_ACTIVE_LOW 1
/** Drive high to enable, drive low to disable */
#define PLM_OE_ACTIVE_HIGH 2
/*@}*/

/** Select your output enable method */
#define PLM_OE PLM_OE_ACTIVE_LOW_HIZ

/** I/O Configuration */
#define PLM_OE_LAT LATF, #0
#define PLM_OE_TRIS TRISF, #0

#define PLM_ADC_CHNL 8 
#define PLM_ADC_TRIS TRISB, #8

/** Select the modulation scheme. 
 * Further configuration can be done in the relevant include file. 
 * Available modulations:
 * - BFSK - Binary Frequency Shift Keying
 * 	Config: 'config_bfsk.h'
 * - BPSK - Binary Phase Shift Keying
 * 	Config: 'config_bpsk.h'
 */
/*@{*/
#define MS_BFSK 1
#define MS_BPSK 2
/*@}*/

#ifndef __MakefileOverride
#define PLM_SCHEME MS_BPSK
#endif //__MakefileOverride

/** Enable low level framing 
 * Frame format: 
 *  - preamble (n x PLM_PRE character)
 *  - start-of-frame (PLM_SOF)
 *  - frame length, one byte, SOF and length byte inclusive, minimum = 3
 */
#define PLM_FRAMING ENABLED

/** Start of frame character. Only used if PLM_FRAMING is ENABLED */
#define PLM_SOF 0x7e

/** Should FEC (Forward Error Correction) be enabled?
 * The implementation uses convolutional codes with a code rate of 1/2, 
 * with various constraint lengths possible. 
 * 
 * WARNING: If enabled, you may hit the CPU performance limit easily!
 *          e.g. BPSK at 129.6kHz with FEC DOES NOT WORK AT ALL. 
 */
#define PLM_FEC DISABLED

/** Should received signal quality estimation be enabled? *?
 * The quality is evaluated during the reception of the first bytes after 
 * byte synchronization has been found.
 */
#define PLM_QUALITY_MEASURE ENABLED

/** Local echo: should the modem receive its own transmissions? */
#define PLM_LOCAL_ECHO DISABLED

/** Optionally turn debug mode on. 
 * For all "signal logging" modes, the application must define 
 * a "buf_add()" function. See example applications to find out 
 * how to do this. 
 *
 * Mode 0: 
 * 	No debug at all
 * Mode 1:
 * 	Performance measurement (uses PORTG, 0). 
 * 	See PERF_ENTER and PERF_QUIT below. 
 * Mode 2:
 * 	Input signal logging. 
 * Mode 3:
 * 	Demodulated signal logging. 
 */
 /*@{*/
#define DEBUG_OFF 0
#define DEBUG_PERF 1
#define DEBUG_SIG_IN 2
#define DEBUG_SIG_OUT 3
/*@}*/

/** Select one of the above debug modes */
#define PLM_DEBUG_MODE DEBUG_OFF

/** RAM saving mode. Enable if you wish to trade MIPS for RAM. 
 *  Makes more sense at low baud rates. 
 */
#define PLM_RAM_SAVING ENABLED

#if PLM_RAM_SAVING == ENABLED
/** Buffer size (in samples) to use in the RAM saving mode (must be shorter 
 *  than or equal to the buffer that would be used in the normal mode). 
 */
#define PLM_DEM_BLOCK_LEN 8
#endif //PLM_RAM_SAVING

#ifdef __dsPIC33F__

/** Available ADC modules. 
 *  ADC1 will claim Timer3, ADC2 will use Timer5. 
 */
/*@{*/
#define ADC1 1
#define ADC2 2
/*@}*/

/** Select the ADC module to use */
#define PLM_ADC ADC1

/** Use DMA? */
#define PLM_USE_DMA ENABLED

#endif //__dsPIC33F__

/** Status flag numbers */
/*@{*/
#define PLM_TX_ACTIVE_FLAG 0
#define PLM_TX_BF_FLAG 1
#define PLM_BIT_SYNC_FLAG 2
#define PLM_BYTE_SYNC_FLAG 3
#define PLM_RESYNC_FLAG 4
/*@}*/

#endif //__CONFIG_PLM_H

