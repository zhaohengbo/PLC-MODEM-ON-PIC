/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-10-22 16:00:58 +0200 (Fri, 22 Oct 2010) $
 * $Revision: 85 $
 * $Author:   $
 */

/**
 * @file
 * Debug message printing. 
 */

#include <config.h>

#include <cpu/int.h>
#include <cpu/uart.h>

#if C_DEBUG_USE_PRINTF
#include <stdio.h>
#endif //C_DEBUG_USE_PRINTF

#define DEBUG_CONTEXT DEBUG
#include <sys/debug.h>

#ifdef HOSTED
#include <libs/num2str.h>
#define to_hex(x) to_hex_digit(x)
#endif //HOSTED

#if C_DEBUG_MODE==ENABLED

/** @cond NONDOC */
#if C_DEBUG_UART==U1
#define DEBUG_UART_TXBUF_FULL() (uart1_txbuf_full())
#define DEBUG_UART_XMIT() (!uart1_txbuf_empty())
#define DEBUG_UART_TX(byte) uart1_tx(byte)
#endif //C_DEBUG_UART==U1

#if C_DEBUG_UART==U2
#define DEBUG_UART_TXBUF_FULL() (uart2_txbuf_full())
#define DEBUG_UART_XMIT() (!uart2_txbuf_empty())
#define DEBUG_UART_TX(byte) uart2_tx(byte)
#endif //C_DEBUG_UART==U2

#define C_DEBUG_UxMODE (\
	UART_ENABLED|\
	UART_RUN_IDLE|\
	UART_USE_DEFAULT|\
	UART_WAKE_DIS|\
	UART_NO_LOOPBACK|\
	UART_ABAUD_OFF|\
	UART_8N1)

#define C_DEBUG_UxSTA (\
	UART_INT_TX_1WORD|\
	UART_TX_NORMAL|\
	UART_TX_DIS|\
	UART_INT_RX_1WORD|\
	UART_NO_ADDR_DET)

/** @endcond */

/**
 * Initialize the debug printing system. 
 */
void debug_init(void)
{
#if C_DEBUG_USE_PRINTF==DISABLED
#if C_DEBUG_UART==U1
    /* No interrupts */
    _U1RXIE = 0;
    _U1TXIE = 0;

    /* Configure UART SFRs */
    uart1_set_baud_rate(C_DEBUG_UART_BAUD);
    U1STA = C_DEBUG_UxSTA;
    U1MODE = C_DEBUG_UxMODE;

    /* UTXEN pin must be set while UARTEN has already been set */
    uart1_tx_enable();
#endif //C_DEBUG_UART==U1

#if C_DEBUG_UART==U2
    /* No interrupts */
    _U2RXIE = 0;
    _U2TXIE = 0;

    /* Configure UART SFRs */
    uart2_set_baud_rate(C_DEBUG_UART_BAUD);
    U2STA = C_DEBUG_UxSTA;
    U2MODE = C_DEBUG_UxMODE;

    /* UTXEN pin must be set while UARTEN has already been set */
    uart2_tx_enable();
#endif //C_DEBUG_UART==U2
#endif //C_DEBUG_USE_PRINTF
}

/**
 * Print a debug message over the debug interface (UART or stdout). 
 * This function is as blocking, as possible. 
 * @param msg Message to send. 
 */
void debug_print(const char *msg)
{
#if C_DEBUG_USE_PRINTF==DISABLED
    const char *ptr = msg;
    ATOMIC_START(C_DEBUG_IPL);
    while (*ptr)
    {
        while (DEBUG_UART_TXBUF_FULL());
        DEBUG_UART_TX(*ptr);
        ptr++;
    }
    while (DEBUG_UART_XMIT());
    ATOMIC_END(C_DEBUG_IPL);
#else
    printf("%s", msg);
#endif //C_DEBUG_USE_PRINTF
}

/**
 * Print a byte over the debug interface (UART or stdout). 
 * @param num Number to print in HEX format
 */
void debug_print_byte(uint8_t num)
{
    char buf[3];
    buf[0] = to_hex((num >> 4) & 0xf);
    buf[1] = to_hex((num) & 0xf);
    buf[2] = '\0';
    debug_print(buf);
}

/**
 * Print a 16-bit word over the debug interface (UART or stdout). 
 * @param num Number to print in HEX format
 */
void debug_print_word(uint16_t num)
{
    char buf[5];
    buf[0] = to_hex((num >> 12) & 0xf);
    buf[1] = to_hex((num >> 8) & 0xf);
    buf[2] = to_hex((num >> 4) & 0xf);
    buf[3] = to_hex((num) & 0xf);
    buf[4] = '\0';
    debug_print(buf);
}
#endif //C_DEBUG_MODE

