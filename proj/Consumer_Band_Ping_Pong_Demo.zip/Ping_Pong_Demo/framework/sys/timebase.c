/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-10-22 16:00:58 +0200 (Fri, 22 Oct 2010) $
 * $Revision: 85 $
 * $Author:   $
 */

/** 
 * @file
 * Time base generation. 
 */

#include <config.h>
#include <cpu/types.h>
#include <cpu/cpu.h>

#include <string.h>

#include <cpu/int.h>
#include <cpu/timers.h>

#include <sys/timebase.h>

/** The time base generator */
static struct timebase tbase;

#ifdef HOSTED

#include <sys/time.h>
#include <signal.h>
/* Callback information for itimer */
static struct sigaction sa;
/* POSIX interval timer structure */
static struct itimerval itimer;

/** ISR for the system timer */
static void T1Interrupt(int signum)
{
    tbase.now += 50 * J_MSEC;
}

/**
 * Get current system jiffies. 
 * @return Current time in jiffies
 */
jiffie_t time_now(void)
{
    return tbase.now;
}
#else //HOSTED

/** ISR for the system timer */
ISR(T1Interrupt)
{
    _T1IF = 0;
    if (tbase.increment)
    {
        tbase.hjiffies++;
    }
    tbase.increment = true;
}

/**
 * Get current system jiffies. 
 * @return Current time in jiffies
 */
jiffie_t time_now(void)
{
    uint16_t low, high;

    ATOMIC_START(C_TIMEBASE_IP);
    low = TMR1;
    if (tbase.increment)
    {
        if (low != 0xffff)
        {
            tbase.increment = false;
            tbase.hjiffies++;
        }
    }
    high = tbase.hjiffies;
    ATOMIC_END(C_TIMEBASE_IP);

    return ((uint32_t) high << 16) | low;
}
#endif //HOSTED

/**
 * Check if time now if later than given time. 
 * @param when Time that should be in the past now. 
 * @return 'true', if 'now' is later than 'when'
 */
bool time_after(jiffie_t when)
{
    return ((long) when - (long) time_now() < 0);
}

/**
 * Calculate a timeout deadline. 
 * @param period Timeout length
 * @return Time in jiffies when the timeout will expire. 
 */
jiffie_t time_get_timeout(jiffie_t period)
{
    return time_now() + period;
}

/**
 * Initialize the time base generator. 
 */
void timebase_init(void)
{
#ifdef HOSTED
    tbase.now = 0;
#else
    tbase.increment = false;
    tbase.hjiffies = 0;
#endif //HOSTED
}

/**
 * Start the time base generation. 
 */
void timebase_start(void)
{
    /* Setup the SYS_TIMER */

#ifdef HOSTED

    memset(&sa, 0, sizeof (sa));
    memset(&itimer, 0, sizeof (itimer));

    sa.sa_handler = T1Interrupt;
    sigaction(SIGALRM, &sa, NULL);

    /* Interrupt every 50 ms */
    itimer.it_value.tv_sec = 0;
    itimer.it_interval.tv_sec = 0;
    itimer.it_value.tv_usec = 50000;
    itimer.it_interval.tv_usec = 50000;

    setitimer(ITIMER_REAL, &itimer, NULL);

#else //HOSTED

    T1CON = TIMERA_OFF | \
 TIMERA_RUN_IDLE | \
 TIMERA_GATE_DIS | \
 TIMERA_TCKPS_1_64 | \
 TIMERA_INTCLK;

    timer1_set_period(0xffff);

    _T1IF = 0;
    _T1IP = C_TIMEBASE_IP;
    _T1IE = 1;

    /* Start the timer */
    timer1_on();

#endif //HOSTED
}

#if 0
/* A number of huge, but currently unused functions. 
 * Left here for reference. 
 */

/**
 * Convert jiffies to microseconds. 
 * @param t Time in jiffies
 * @return Corresponding time in microseconds
 */
usec_t jiffie_to_usec(jiffie_t t)
{
#if USEC_T_MAX_JIFFIES < 4294967295
    if (t > USEC_T_MAX_JIFFIES)
    {
        return 0xffffffff;
    }
#endif //USEC_T_MAX_JIFFIES
    return 1ull * J_PRESCALE * 1000 * 1000 * t / FCY;
}

/**
 * Convert jiffies to miliseconds. 
 * @param t Time in jiffies
 * @return Corresponding time in miliseconds
 */
msec_t jiffie_to_msec(jiffie_t t)
{
#if MSEC_T_MAX_JIFFIES < 4294967295
    if (t > MSEC_T_MAX_JIFFIES)
    {
        return 0xffff;
    }
#endif //MSEC_T_MAX_JIFFIES
    return 1ull * J_PRESCALE * 1000 * t / FCY;
}

/**
 * Convert jiffies to seconds. 
 * @param t Time in jiffies
 * @return Corresponding time in seconds
 */
sec_t jiffie_to_sec(jiffie_t t)
{
#if SEC_T_MAX_JIFFIES < 4294967295
    if (t > SEC_T_MAX_JIFFIES)
    {
        return 0xffff;
    }
#endif //SEC_T_MAX_JIFFIES
    return 1ull * J_PRESCALE * t / FCY;
}

/**
 * Convert microseconds to jiffies. 
 * @param t Time in microseconds
 * @return Corresponding number jiffies
 */
jiffie_t usec_to_jiffie(usec_t t)
{
#if JIFFIE32_MAX_USEC < 4294967295
    if (t > JIFFIE32_MAX_USEC)
    {
        /* Saturate if too much */
        return JIFFIE32_MAX_USEC;
    }
#endif //JIFFIE32_MAX_USEC
    return 1ull * FCY * t / J_PRESCALE / 1000000;
}

/**
 * Convert miliseconds to jiffies. 
 * @param t Time in miliseconds
 * @return Corresponding number of jiffies
 */
jiffie_t msec_to_jiffie(msec_t t)
{
#if JIFFIE32_MAX_MSEC < 65535
    if (t > JIFFIE32_MAX_MSEC)
    {
        /* Saturate if too much */
        return JIFFIE32_MAX_MSEC;
    }
#endif //JIFFIE32_MAX_MSEC
    return 1ull * FCY * t / J_PRESCALE / 1000;
}

/**
 * Convert seconds to jiffies. 
 * @param t Time in seconds
 * @return Corresponding number of jiffies
 */
jiffie_t sec_to_jiffie(sec_t t)
{
#if JIFFIE32_MAX_SEC < 65535
    if (t > JIFFIE32_MAX_SEC)
    {
        /* Saturate if too much */
        return JIFFIE32_MAX_SEC;
    }
#endif //JIFFIE32_MAX_SEC
    return 1ull * FCY * t / J_PRESCALE;
}

/**
 * Convert microseconds to CPU cycles. 
 * @param t Time in microseconds
 * @return Corresponding number of CPU cycles
 */
cycle_t usec_to_cyc(usec_t t)
{
    cycle_t result = 0;
    usec_t remain = t;
    if (t > 1000)
    {
        remain = t % 1000;
        result += msec_to_cyc(t / 1000);
    }
    result += 1ul * FCY * remain / 1000000ul;
    return result;
}

/**
 * Convert miliseconds to CPU cycles. 
 * @param t Time in miliseconds
 * @return Corresponding number of CPU cycles
 */
cycle_t msec_to_cyc(msec_t t)
{
    cycle_t result = 0;
    msec_t remain = t;
    if (t > 1000)
    {
        remain = t % 1000;
        result += sec_to_cyc(t / 1000);
    }
    result += 1ul * FCY * remain / 1000ul;
    return result;
}

/**
 * Convert seconds to CPU cycles. 
 * @param t Time in seconds
 * @return Corresponding number of CPU cycles
 */
cycle_t sec_to_cyc(sec_t t)
{
    if (t > CYCLE_T_MAX_SEC)
    {
        /* Saturate if too much */
        return 1ul * FCY * CYCLE_T_MAX_SEC;
    }
    return 1ul * FCY * t;
}

/**
 * Convert CPU cycles to jiffies. 
 * Values can get truncated and even zeroed. 
 * @param cycles Number of CPU cycles
 * @return Corresponding number of jiffies
 */
jiffie_t cyc_to_jiffie(cycle_t cycles)
{
    return cycles >> 6;
}

/**
 * Convert jiffies to CPU cycles. 
 * Values too large are subject to saturation. 
 * @param jiffies Number of jiffies
 * @return Corresponding number of CPU cycles
 */
cycle_t jiffie_to_cyc(jiffie_t jiffies)
{
    if (jiffies >= 0xfffffffful / 64)
    {
        return 0xfffffffful;
    }
    return jiffies << 6;
}
#endif //0

