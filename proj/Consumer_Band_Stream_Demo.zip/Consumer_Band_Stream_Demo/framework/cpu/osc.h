/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-10-22 16:00:58 +0200 (Fri, 22 Oct 2010) $
 * $Revision: 85 $
 * $Author:   $
 */

/**
 * @file
 * Oscillator configuration. 
 */

#ifndef __OSC_H
#define __OSC_H

#include <cpu/cpu.h>

/** 
 * Get oscillator frequency. 
 * This macro is intended to be rewritten to return the actual frequency 
 * according to the current oscillator selection, if such a need arises. 
 * Therefore you are better off using this macro, not the 'FCY' 
 * definition directly. 
 */
#define osc_get_fcy() ((unsigned long)FCY)

/** Oscillator selections */
typedef enum {
	#ifdef __dsPIC30F__
	/** Secondary oscillator - the low power 32768Hz crystal */
	OSCSEL_SOSC=0x0,
	/** Fast RC oscillator */
	OSCSEL_FRC=0x1,
	/** Low power RC oscillator (512kHz nominal)*/
	OSCSEL_LPRC=0x2,
	/** Primary oscillator (oscillator versions 1 and 2) */
	OSCSEL_PRI=0x3,
	/** External oscillator (oscillator version 3) */
	OSCSEL_EXT=0x3,
	/** PLL oscillator (oscillator version 3) */
	OSCSEL_PLL=0x7,
	#endif //__dsPIC30F__

	#ifdef __dsPIC33F__
	/** Fast RC oscillator */
	OSCSEL_FRC=0x0,
	/** Fast RC oscillator with PLL enabled */
	OSCSEL_FRCPLL=0x1,
	/** Primary oscillator */
	OSCSEL_PRI=0x2,
	/** Primary oscillator with PLL enabled */
	OSCSEL_PRIPLL=0x3,
	/** Secondary oscillator - the low power 32768Hz crystal */
	OSCSEL_SOSC=0x4,
	/** Low power RC oscillator (32768Hz nominal) */
	OSCSEL_LPRC=0x5,
	/** Fast RC oscillator divided by 16 */
	OSCSEL_FRCDIV16=0x6,
	/** Fast RC oscillator divided by N */
	OSCSEL_FRCDIVN=0x7
	#endif //__dsPIC33F__

	#ifdef HOSTED
	DUMMY
	#endif //HOSTED
} osc_sel_t;

/**
 * Immediately change the oscillator providing clock to the CPU. 
 * @param selection clock source selection
 */
void osc_do_switch(osc_sel_t selection);

/**
 * Check if oscillator switch has been completed. 
 */
#define osc_switch_complete() (!OSCCONbits.OSWEN)

/**
 * Check if the PLL has lock. 
 */
#define pll_has_lock() (OSCCONbits.LOCK)

/**
 * Enable the low-power 32768Hz oscillator. 
 */
void osc_lp_enable(void);

#ifdef __dsPIC33F__

/** PLL prescale (N1) settings */
typedef enum {
	PLLPRE_2,  PLLPRE_3,  PLLPRE_4,  PLLPRE_5,  PLLPRE_6,  PLLPRE_7, 
	PLLPRE_8,  PLLPRE_9,  PLLPRE_10, PLLPRE_11, PLLPRE_12, PLLPRE_13, 
	PLLPRE_14, PLLPRE_15, PLLPRE_16, PLLPRE_17, PLLPRE_18, PLLPRE_19,
	PLLPRE_20, PLLPRE_21, PLLPRE_22, PLLPRE_23, PLLPRE_24, PLLPRE_25,
	PLLPRE_26, PLLPRE_27, PLLPRE_28, PLLPRE_29, PLLPRE_30, PLLPRE_31, 
	PLLPRE_32, PLLPRE_33
} pllpre_t;

/** PLL postscale (N2) settings */
typedef enum {
	PLLPOST_2 = 0,
	PLLPOST_4 = 1,
	PLLPOST_8 = 3
} pllpost_t;

/** PLL feedback divider settings (range 2 to 513) */
typedef uint16_t plldiv_t;

static inline void osc_set_pll(pllpre_t n1, pllpost_t n2, plldiv_t m)
{
	_PLLPRE = n1;
	_PLLPOST = n2;
	_PLLDIV = m-2;
}

#endif //__dsPIC33F__

#endif //__OSC_H

