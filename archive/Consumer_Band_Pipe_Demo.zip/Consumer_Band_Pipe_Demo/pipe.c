/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-11-05 16:48:49 +0100 (Fri, 05 Nov 2010) $
 * $Revision: 88 $
 * $Author:   $
 */

#include <stdlib.h>
#include <string.h>

#include <config.h>
#include <cpu/adc.h>
#include <cpu/cpu.h>
#include <cpu/types.h>
#include <cpu/osc.h>
#include <util/ringbuf.h>

#include <common/plm.h>

#ifdef __dsPIC30F__
/** Start from XT with PLL x16 */
_FOSC(CSW_FSCM_OFF & XT_PLL16);
/** Brown-out disabled, maximum power-up timer delay */
_FBORPOR(PBOR_OFF & PWRT_64 & MCLR_EN);
/** WDT by default is off, may be turned on with RCON.SWDTEN, 512 ms timeout */
_FWDT(WDT_OFF & WDTPSA_64 & WDTPSB_4);
/** Code protection on */
_FGS(CODE_PROT_OFF);
#endif //__dsPIC30F__

#ifdef __dsPIC33F__
/** Primary oscillator is XT, switching is enabled, monitor is disabled */
_FOSC(FCKSM_CSECMD & OSCIOFNC_OFF & POSCMD_XT);
/** Start from the internal Fast RC clock */
_FOSCSEL(FNOSC_FRC & IESO_OFF);
/** Maximum power-up timer delay */
_FPOR(FPWRT_PWR128);
/** WDT by default is off, may be turned on with RCON.SWDTEN, 512 ms timeout */
_FWDT(FWDTEN_OFF & WINDIS_OFF & WDTPRE_PR32 & WDTPOST_PS512);
/** No Boot Sector */
_FBS(RBS_NO_RAM & BSS_NO_FLASH & BWRP_WRPROTECT_OFF);
/** No Secure Segment */
_FSS(RSS_NO_RAM & SSS_NO_FLASH & SWRP_WRPROTECT_OFF);
/** No code protection */
_FGS(GSS_OFF & GCP_OFF & GWRP_OFF);
#endif //__dsPIC33F__

#if 0
#define BUF_LEN 2048
uint16_t buf[BUF_LEN];
uint16_t bufptr = 0;

void buf_add(uint16_t sample)
{
    buf[bufptr++ & 0x7ff] = sample;
    buf[bufptr & 0x7ff] = 0xdead;
}
#endif //0

#define TX_BUFFER_SIZE 512
#define RX_BUFFER_SIZE 128

static uint8_t txdata[TX_BUFFER_SIZE];
static uint8_t rxdata[RX_BUFFER_SIZE];

#define PREAMBLE_LEN_TX 10
#define PREAMBLE_LEN_RX 2
#define FRAME_LEN 64
#define CRC_LEN 2
#define CRC_ITUT_POLY 0x1021

#define FLOW_SETUP() _TRISF13 = 0
#define FLOW_ON() _LATF13 = 0
#define FLOW_OFF() _LATF13 = 1

#define PRE PLM_PRE
#define SOF PLM_SOF

typedef enum
{
    RXSTATE_PREAMBLE,
    RXSTATE_SOF,
    RXSTATE_LEN,
    RXSTATE_DATA,
    RXSTATE_CRC
} rxstate_t;

struct buffer
{
    uint8_t data[FRAME_LEN];
};

static struct
{
    rxstate_t rxstate;
    uint16_t rxcounter;
    uint16_t rxcrc;

    struct ringbuf txrb;
    struct ringbuf rxrb;

    uint8_t ntx, nrx;
    struct buffer txbuf[2];
    struct buffer rxbuf[2];
} modem;

/* Initialize the modem */
static void modem_setup(void)
{
    modem.rxstate = RXSTATE_PREAMBLE;
    modem.rxcounter = PREAMBLE_LEN_RX;

    modem.ntx = 0;
    modem.nrx = 0;

    ringbuf_init(&modem.txrb, txdata, sizeof (txdata));
    ringbuf_init(&modem.rxrb, rxdata, sizeof (rxdata));
}

/* Process next byte with the CRC16 algorithm */
static uint16_t crc16_next_byte(char byte, uint16_t rem)
{
    int i;
    for (i = 0; i < 8 * sizeof (byte); i++)
    {
        if (rem & 0x8000)
        {
            rem <<= 1;
            if (byte & 0x80)
            {
                rem |= 1;
            }
            rem ^= CRC_ITUT_POLY;
        }
        else
        {
            rem <<= 1;
            if (byte & 0x80)
            {
                rem |= 1;
            }
        }
        byte <<= 1;
    }
    return rem;
}

/* Setup the UART */
static void uart_setup(void)
{
    U2MODE = 0x8800;
    U2STA = 0x8400;
    U2BRG = (FCY / 16) / 19200 - 1;

    _U2RXIP = 2;
    _U2TXIP = 1;

    _U2RXIF = 0;
    _U2RXIE = 1;
    _U2TXIF = 0;
    _U2TXIE = 0;

    FLOW_SETUP();
    FLOW_ON();
}

/* UART2 Transmit Interrupt */
void __attribute__((interrupt, no_auto_psv))_U2TXInterrupt(void)
{
    _U2TXIF = 0;

    if (!ringbuf_is_empty(&modem.rxrb))
    {
        U2TXREG = ringbuf_pop(&modem.rxrb);
    }
    else
    {
        /* Nothing to send - disable TX interrupts */
        _U2TXIE = 0;
    }
}

/* UART2 Receive Interrupt */
void __attribute__((interrupt, no_auto_psv))_U2RXInterrupt(void)
{
    char rx;
    _U2RXIF = 0;

    while (U2STAbits.URXDA)
    {
        rx = U2RXREG;
        ringbuf_push(&modem.txrb, rx);
        if (ringbuf_space(&modem.txrb) < 32)
        {
            FLOW_OFF();
        }
    }
    if (U2STAbits.OERR)
    {
        U2STAbits.OERR = 0;
    }
}

/* Poll UART communications */
static void uart_poll(void)
{
    if (U2STAbits.OERR)
    {
        U2STAbits.OERR = 0;
    }

    if (!_U2TXIE)
    {
        if (!ringbuf_is_empty(&modem.rxrb))
        {
            _U2TXIE = 1;
            _U2TXIF = 1;
        }
    }
}

//#define DEBUGGING

#ifdef DEBUGGING
#define DEBUG_SEND(c) ringbuf_push(&modem.rxrb, c)
#else
#define DEBUG_SEND(c);
#endif //DEBUGGING

#ifdef DEBUGGING

/**
 * Convert a number to a hex digit (ASCII).
 *
 * @param val Number in the range from 0 - 15
 * @return ASCII code '0' - '9' or 'a' - 'f'
 */
char to_hex_digit(uint8_t val)
{
    if (val > 9)
    {
        return val - 10 + 'a';
    }
    return val + '0';
}
#endif //DEBUGGING

/* Poll MODEM reception */
static void modem_poll_rx(void)
{
    uint8_t c;

    uint8_t *end_ptr;
    uint8_t *ptr;

    ptr = modem.rxbuf[modem.nrx++].data;
    if (modem.nrx == 2)
    {
        modem.nrx = 0;
    }
    end_ptr = plm_recv(ptr, FRAME_LEN);

    ptr = modem.rxbuf[modem.nrx].data;
    for (; ptr < end_ptr; ptr++)
    {

        c = *ptr;

        switch (modem.rxstate)
        {
        case RXSTATE_PREAMBLE:
        default:
            if (c == PRE)
            {
                DEBUG_SEND('-');
                if (--modem.rxcounter == 0)
                {
                    modem.rxstate = RXSTATE_SOF;
                }
            }
            else
            {
#if PLM_FRAMING == DISABLED
                plm_demod_resync();
#endif //PLM_FRAMING
                DEBUG_SEND('*');
                modem.rxcounter = PREAMBLE_LEN_RX;
            }
            break;
        case RXSTATE_SOF:
            if (c == SOF)
            {
                modem.rxstate = RXSTATE_LEN;
                DEBUG_SEND('<');
            }
            else if (c != PRE)
            {
                modem.rxcounter = PREAMBLE_LEN_RX;
                modem.rxstate = RXSTATE_PREAMBLE;
                DEBUG_SEND('@');
            }
            else
            {
                DEBUG_SEND('-');
            }
            break;
        case RXSTATE_LEN:
            DEBUG_SEND(to_hex_digit((c >> 4) & 0xf));
            DEBUG_SEND(to_hex_digit(c & 0xf));
            DEBUG_SEND('=');
            modem.rxcrc = 0x0000;
            if ((c > FRAME_LEN) || (c <= 3))
            {
                DEBUG_SEND('&');
                modem.rxcounter = PREAMBLE_LEN_RX;
                modem.rxstate = RXSTATE_PREAMBLE;
            }
            else
            {
                modem.rxcounter = c - 1;
                modem.rxstate = RXSTATE_DATA;
            }
            break;
        case RXSTATE_DATA:
            ringbuf_push(&modem.rxrb, c);
            modem.rxcrc = crc16_next_byte(c, modem.rxcrc);
            if (--modem.rxcounter == 2)
            {
                modem.rxstate = RXSTATE_CRC;
            }
            break;
        case RXSTATE_CRC:
            modem.rxcrc = crc16_next_byte(c, modem.rxcrc);
            DEBUG_SEND('#');
            if (--modem.rxcounter == 0)
            {
                if (modem.rxcrc != 0x0000)
                {
                    DEBUG_SEND('!');
                }
                modem.rxcounter = PREAMBLE_LEN_RX;
                modem.rxstate = RXSTATE_PREAMBLE;
                DEBUG_SEND('>');
            }
            break;
        }
    }
}

/* Poll MODEM transmission */
static void modem_poll_tx(void)
{
    int i;
    uint8_t c;

    uint8_t *data;
    uint16_t count = 0;
    uint16_t crc = 0;

    if (plm_get_status() & PLM_TX_BF_MASK)
    {
        return;
    }

    if (ringbuf_is_empty(&modem.txrb))
    {
        return;
    }

    data = modem.txbuf[modem.ntx].data;
    if (++modem.ntx == 2)
    {
        modem.ntx = 0;
    }

    for (i = 0; i < PREAMBLE_LEN_TX; i++)
    {
        data[count++] = PRE;
    }
    data[count++] = SOF;
    /* length has index PREAMBLE_LEN_TX + 1 */
    data[count++] = 0;

    DEBUG_SEND('{');

    while (!ringbuf_is_empty(&modem.txrb))
    {

        c = ringbuf_pop(&modem.txrb);
        //DEBUG_SEND(c);

        if (ringbuf_space(&modem.txrb) > 32)
        {
            FLOW_ON();
        }

        data[count++] = c;
        crc = crc16_next_byte(c, crc);

        if (count == FRAME_LEN - 2)
        {
            break;
        }
    }

    data[PREAMBLE_LEN_TX + 1] = count - PREAMBLE_LEN_TX + 1;

    DEBUG_SEND('=');
    DEBUG_SEND(to_hex_digit((data[PREAMBLE_LEN_TX + 1] >> 4) & 0xf));
    DEBUG_SEND(to_hex_digit(data[PREAMBLE_LEN_TX + 1] & 0xf));
    DEBUG_SEND('}');

    crc = crc16_next_byte(0, crc);
    crc = crc16_next_byte(0, crc);

    data[count++] = crc >> 8;
    data[count++] = crc & 0xff;

    plm_xmit(data, count);
}

/* Show status on leds */
static void show_led_status(void)
{
    uint16_t status = plm_get_status();
    LATAbits.LATA0 = (status & PLM_TX_ACTIVE_MASK) ? 1 : 0;
    LATAbits.LATA1 = (status & PLM_BIT_SYNC_MASK) ? 1 : 0;
    LATAbits.LATA2 = (status & PLM_BYTE_SYNC_MASK) ? 1 : 0;
}

int main(void)
{
    /* Set the required DSP engine configuration
     *  - the other bits assumed to be in the default reset state.
     */
    CORCONbits.ACCSAT = 1;
    CORCONbits.SATA = 1;
    CORCONbits.SATB = 1;

#ifdef __dsPIC33F__
    /* We have 8MHz XTAL on Explorer16
     * Fvco = Fin * (PLLDIV+2) / (PLLPRE+2)
     * Fvco must be in the range 100..200 MHz
     * Fpfd = Fvco / (PLLDIV+2) must be in the range 0.8..8 MHz
     * Fosc = Fvco / (2*(PLLPOST+1))
     * Fcy  = Fosc / 2
     */
    //_PLLDIV = 78;   //80: 8MHz * (78+2) = 640MHz
    //_PLLPRE = 2;    // 4: Fvco = 640MHz / (2+2) = 160MHz, Fpfd = 2MHz
    //_PLLPOST = 0;   // 2: Fosc = 160MHz / 2 = 80MHz

    osc_set_pll(PLLPRE_4, PLLPOST_2, 80);
    osc_do_switch(OSCSEL_PRIPLL);

    while (!osc_switch_complete());
    while (!pll_has_lock());
#endif //__dsPIC33F__

    adc_set_all_digital();

    TRISAbits.TRISA0 = 0;
    LATAbits.LATA0 = 0;
    TRISAbits.TRISA1 = 0;
    LATAbits.LATA1 = 0;
    TRISAbits.TRISA2 = 0;
    LATAbits.LATA2 = 0;
    TRISAbits.TRISA3 = 0;
    LATAbits.LATA3 = 0;

    modem_setup();
    uart_setup();

    plm_demod_start();
    plm_mod_start();

    while (1)
    {
        uart_poll();
        modem_poll_rx();
        modem_poll_tx();
        show_led_status();
    }
}

