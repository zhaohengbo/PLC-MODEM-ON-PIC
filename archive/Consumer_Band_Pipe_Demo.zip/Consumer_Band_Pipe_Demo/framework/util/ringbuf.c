/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-08-27 19:25:56 +0200 (Fri, 27 Aug 2010) $
 * $Revision: 82 $
 * $Author:   $
 */

/**
 * @file
 * Interrupt-safe circular buffer. 
 */

#include <config.h>
#include <cpu/int.h>
#include <util/ringbuf.h>

/** 
 * Initialize a ringbuf. Does the whole required initialization of a ringbuf - 
 * clears the counter and read/write pointers. 
 * @param rb Ringbuf to initialize
 * @param table Ringbuf data table
 * @param size Size of the table
 */
void ringbuf_init(struct ringbuf *rb, uint8_t *table, uint16_t size)
{
    rb->table = table;
    rb->size = size;
    rb->rdptr = 0;
    rb->wrptr = 0;
    rb->count = 0;
}

/** 
 * Check whether a ringbuf is full. 
 * Can be used safely only by the higher priority thread or the "pushing" 
 * thread. Worst case is that this function will return "buffer full", 
 * when there's already some space. 
 * 
 * @param rb Ringbuf to check
 * @return true if ringbuf is full, false otherwise
 */
inline bool ringbuf_is_full(struct ringbuf *rb)
{
    return rb->count == rb->size;
}

/** 
 * Check whether a ringbuf is empty. 
 * Can be used safely only by the higher priority thread or the "poping" 
 * thread. Worst case is that this function will return "buffer empty", 
 * when there're already some words in the buffer to be read. 
 * 
 * @param rb Ringbuf to check
 * @return true if ringbuf is empty, false otherwise
 */
inline bool ringbuf_is_empty(struct ringbuf *rb)
{
    return rb->count == 0;
}

/**
 * Write data to a ringbuf. 
 * Pushes to a given ringbuf can only be performed at one 
 * interrupt priority level. 
 * 
 * @param rb Ringbuf to use
 * @param byte Byte to add to the buffer
 */
void ringbuf_push(struct ringbuf *rb, uint8_t byte)
{
    if (ringbuf_is_full(rb))
    {
        return;
    }

    rb->table[rb->wrptr] = byte;
    rb->wrptr++;
    if (rb->wrptr == rb->size)
    {
        rb->wrptr = 0;
    }
    ATOMIC_INCREMENT(rb->count);
}

/** 
 * Read data from a ringbuf. 
 * Pops from a given ringbuf can only be performed at one 
 * interrupt priority level 
 * 
 * @param rb Ringbuf to use
 * @return Byte read
 */
uint8_t ringbuf_pop(struct ringbuf *rb)
{
    uint8_t byte;

    if (ringbuf_is_empty(rb))
    {
        return 0;
    }

    byte = rb->table[rb->rdptr];
    rb->rdptr++;
    if (rb->rdptr == rb->size)
    {
        rb->rdptr = 0;
    }
    ATOMIC_DECREMENT(rb->count);
    return byte;
}

/**
 * Get the number of bytes in a ringbuf. 
 * Lower priority thread may get an invalid value - too high for poping 
 * threads, too low for pushing threads. 
 *
 * @param rb Ringbuf to be checked
 * @return Number of bytes used in the ringbuf rb
 */
uint16_t ringbuf_count(struct ringbuf *rb)
{
    return rb->count;
}

/**
 * Get the number of free bytes in a ringbuf. 
 * Lower priority thread may get an invalid value - too low for poping 
 * threads, too high for pushing threads. 
 *
 * @param rb Ringbuf to be checked
 * @return Remaining space in the ringbuf rb
 */
uint16_t ringbuf_space(struct ringbuf *rb)
{
    return rb->size - rb->count;
}

