/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-10-22 16:00:58 +0200 (Fri, 22 Oct 2010) $
 * $Revision: 85 $
 * $Author:   $
 */

/**
 * @file
 * Interrupt support for the Microchip 16-bit architecture. 
 * This file provides definitions for all dsPIC and PIC24 families. 
 */

#ifndef __INT_MCP16_H
#define __INT_MCP16_H

#include <cpu/types.h>
#include <cpu/cpu.h>

/** Interrupt priority level type */
typedef uint8_t ipl_t;

/**
 * Number of interrupt nesting levels. 
 * This includes non-interrupt mainline code
 */
#define IRQ_LEVELS 8

/** Use the AIVT instead of IVT */
//#define INT_USE_AIVT

/** Interrupt declaration macro. */
#ifdef INT_USE_AIVT
#define ISR(name) \
	void __attribute__((interrupt, auto_psv))_Alt ## name(void)
#else
#define ISR(name) \
	void __attribute__((interrupt, auto_psv))_ ## name(void)
#endif //INT_USE_AIVT

/** 
 * Fast interrupt declaration macro. 
 * Fast interrupts use shadow registers to save the context. 
 * Beware: 'no_auto_psv' model for fast interrupts selected. 
 */
#ifdef INT_USE_AIVT
#define ISRFAST(name) \
	void __attribute__((interrupt, shadow, no_auto_psv))_Alt ## name(void)
#else
#define ISRFAST(name) \
	void __attribute__((interrupt, shadow, no_auto_psv))_ ## name(void)
#endif //INT_USE_AIVT

/** Disable level 1 to 6 interrupts for n CPU cycles. */
#define int_disable_ncycles(n) __asm__("DISI #" #n)

/* To safely set the CPU IPL, use SET_CPU_IPL(ipl); the */
/* valid range of ipl is 0-7, it may be any expression. */
#define SETCPUIPL(ipl) {         \
  int DISI_save;                 \
                                 \
  DISI_save = DISICNT;           \
  asm volatile ("disi #0x3FFF"); \
  SRbits.IPL = ipl;              \
  asm volatile ("disi #0x02"); } (void) 0;

/**
 * Set CPU interrupt priority level. Interrupts of priorities
 * lower than or equal to the level set will not be serviced.
 * Valid values range from 7 (interrupts disabled) to 0 (all
 * interrupts accepted).
 */
#define int_set_cpu_priority_level(level) SETCPUIPL(level)

/** Initialize interrupts */
#define int_init()

/** Globally disable all interrupts. This will not disable TRAP handlers. */
#define int_global_disable() int_set_cpu_priority_level(7)
/** Enable all interrupt sources */
#define int_global_enable() int_set_cpu_priority_level(0)

/**
 * Atomic (uninterruptible) block start. 
 * Never return or break from within a block surrounded by ATOMIC_START() 
 * and ATOMIC_END(). 
 * Typically you'll have to encompass your atomic code block with braces. 
 * Braces might have been included within macros below, but that would 
 * lead to very difficult to find errors. Don't change that!
 *
 */
#define ATOMIC_START(level) \
	int ipl_save = _IPL; \
	SETCPUIPL(level); \
	__asm__ volatile ("disi #4");

/**
 * Atomic (uninterruptible) block end. 
 */
#define ATOMIC_END(level) \
	SETCPUIPL(ipl_save)

/** 
 * Atomic variable incrementation 
 *
 */
#define ATOMIC_INCREMENT(var) \
	{ \
	int ipl_save = _IPL; \
	SETCPUIPL(7); \
	__asm__ volatile ("disi #4"); \
	var++; \
	SETCPUIPL(ipl_save); \
	} while(0)

/**
 * Atomic variable decrementation 
 *
 */
#define ATOMIC_DECREMENT(var) \
	{ \
	int ipl_save = _IPL; \
	SETCPUIPL(7); \
	__asm__ volatile ("disi #4"); \
	var--; \
	SETCPUIPL(ipl_save); \
	} while(0)

/** Maximum interrupt nesting level that can be used with ATOMIC macros */
#define ATOMIC_MAX 7

/**
 * Clear all interrupt flags.
 */
#ifdef __dsPIC30F__
#define int_clear_all_flags() \
	do { IFS0 = IFS1 = IFS2 = 0; } while (0)
#endif //__dsPIC30F__
#ifdef __dsPIC33F__
#define int_clear_all_flags() \
	do { IFS0 = IFS1 = IFS2 = IFS3 = IFS4 = 0; } while (0)
#endif //__dsPIC33F__

/**
 * Disable all interrupt sources.
 */
#ifdef __dsPIC30F__
#define int_disable_all() \
	do { IEC0 = IEC1 = IEC2 = 0; } while (0)
#endif //__dsPIC30F__
#ifdef __dsPIC33F__
#define int_disable_all() \
	do { IEC0 = IEC1 = IEC2 = IEC3 = IEC4 = 0; } while (0)
#endif //__dsPIC33F__

/** @name INTCON1 register bits */
/*@{*/
/** Interrupt nesting enable/disable */
#define INT_NSTDIS 0x8000
/** Accumulator A overflow trap enable/disable */
#define INT_OVATE 0x0400
/** Accumulator B overflow trap enable/disable */
#define INT_OVBTE 0x0200
/** Catastrophic overflow trap enable/disable */
#define INT_COVTE 0x0100
/*@}*/

/** @name INTCON1 defines. 
 *  Constants should be or'ed together
 */
/*@{*/
/** Interrupt nesting disabled */
#define INT_NESTING_DIS INT_NSTDIS
/** Interrupt nesting enabled */
#define INT_NESTING_EN 0x0000
/** Accumulator A overflow trap enabled */
#define INT_OVA_EN INT_OVATE
/** Accumulator A overflow trap disabled */
#define INT_OVA_DIS 0x0000
/** Accumulator B overflow trap enabled */
#define INT_OVB_EN INT_OVBTE
/** Accumulator B overflow trap disabled */
#define INT_OVB_DIS 0x0000
/** Catastrophic overflow trap enabled */
#define INT_COV_EN INT_COVTE
/** Catastrophic overflow trap disabled */
#define INT_COV_DIS 0x0000
/*@}*/

/** @name INTCON2 register bits */
/*@{*/
/** Select default or alternate interrupt vector table */
#define INT_ALTIVT 0x8000
/** INT4 interrupt edge select */
#define INT_INT4EP 0x0010
/** INT3 interrupt edge select */
#define INT_INT3EP 0x0008
/** INT2 interrupt edge select */
#define INT_INT2EP 0x0004
/** INT1 interrupt edge select */ 
#define INT_INT1EP 0x0002
/** INT0 interrupt edge select */ 
#define INT_INT0EP 0x0001
/*@}*/

/** @name INTCON2 defines. 
 *  Constants should be or'ed together
 */
/*@{*/
/** Alternate interrupt vector table is selected */
#define INT_ALTERN_VT INT_ALTIVT
/** Default interrupt vector table is selected */
#define INT_DEFAULT_VT 0x0000
/** External INT4 interrupt input is active on falling (negative) edge */
#define INT_INT4_NEG INT_INT4EP
/** External INT4 interrupt input is active on rising (positive) edge */
#define INT_INT4_POS 0x0000
/** External INT3 interrupt input is active on falling (negative) edge */
#define INT_INT3_NEG INT_INT3EP
/** External INT3 interrupt input is active on rising (positive) edge */
#define INT_INT3_POS 0x0000
/** External INT2 interrupt input is active on falling (negative) edge */
#define INT_INT2_NEG INT_INT2EP
/** External INT2 interrupt input is active on rising (positive) edge */
#define INT_INT2_POS 0x0000
/** External INT1 interrupt input is active on falling (negative) edge */
#define INT_INT1_NEG INT_INT1EP
/** External INT1 interrupt input is active on rising (positive) edge */
#define INT_INT1_POS 0x0000
/** External INT0 interrupt input is active on falling (negative) edge */
#define INT_INT0_NEG INT_INT0EP
/** External INT0 interrupt input is active on rising (positive) edge */
#define INT_INT0_POS 0x0000
/*@}*/

#ifdef __dsPIC30F__
/** @name Compatibility definitions to make the I2C code more portable */
/*@{*/
#define _MI2C1IF _MI2CIF
#define _MI2C1IE _MI2CIE
#define _MI2C1IP _MI2CIP
#define _SI2C1IF _SI2CIF
#define _SI2C1IE _SI2CIE
#define _SI2C1IP _SI2CIP
/*@}*/
#endif //__dsPIC30F__

#ifdef __dsPIC30F__
/** @name Compatibility definitions to make the ADC code more portable */
/*@{*/
#define _AD1IF _ADIF
#define _AD1IE _ADIE
#define _AD1IP _ADIP
/*@}*/
#endif //__dsPIC30F__

#endif //__INT_MCP16_H

