/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-08-27 19:25:56 +0200 (Fri, 27 Aug 2010) $
 * $Revision: 82 $
 * $Author:   $
 */

#include <stdlib.h>
#include <string.h>

#include <config.h>
#include <cpu/adc.h>
#include <cpu/cpu.h>
#include <cpu/types.h>
#include <cpu/osc.h>

#include <common/plm.h>

#ifdef __dsPIC30F__
/** Start from XT with PLL x16 */
_FOSC(CSW_FSCM_OFF & XT_PLL16);
/** Brown-out disabled, maximum power-up timer delay */
_FBORPOR(PBOR_OFF & PWRT_64 & MCLR_EN);
/** WDT by default is off, may be turned on with RCON.SWDTEN, 512 ms timeout */
_FWDT(WDT_OFF & WDTPSA_64 & WDTPSB_4);
/** Code protection on */
_FGS(CODE_PROT_OFF);
#endif //__dsPIC30F__

#ifdef __dsPIC33F__
/** Primary oscillator is XT, switching is enabled, monitor is disabled */
_FOSC(FCKSM_CSECMD & OSCIOFNC_OFF & POSCMD_XT);
/** Start from the internal Fast RC clock */
_FOSCSEL(FNOSC_FRC & IESO_OFF);
/** Maximum power-up timer delay */
_FPOR(FPWRT_PWR128);
/** WDT by default is off, may be turned on with RCON.SWDTEN, 512 ms timeout */
_FWDT(FWDTEN_OFF & WINDIS_OFF & WDTPRE_PR32 & WDTPOST_PS512);
/** No Boot Sector */
_FBS(RBS_NO_RAM & BSS_NO_FLASH & BWRP_WRPROTECT_OFF);
/** No Secure Segment */
_FSS(RSS_NO_RAM & SSS_NO_FLASH & SWRP_WRPROTECT_OFF);
/** No code protection */
_FGS(GSS_OFF & GCP_OFF & GWRP_OFF);
#endif //__dsPIC33F__

#if 0
/* Debug buffer. 'buf_add()' can be called to catch 
 * signals at different demodulation stages. 
 */
#define BUF_LEN 2048
uint16_t buf[BUF_LEN];
uint16_t bufptr = 0;

void buf_add(uint16_t sample)
{
    buf[bufptr++ & 0x7ff] = sample;
    buf[bufptr & 0x7ff] = 0xdead;
}
#endif //0

#define RXBUF_SIZE 64
#define TXBUF_SIZE 64

int main(void)
{
    uint16_t bytes_to_send = 0;

    /* Define transmit and receive buffers */
    uint8_t *rxbuf;
    uint8_t *end_ptr;
    uint8_t rxbuf1[RXBUF_SIZE];
    uint8_t rxbuf2[RXBUF_SIZE];
    uint8_t txbuf[TXBUF_SIZE];

    /* The receiver will fill in rxbuf1 first */
    rxbuf = rxbuf1;

    /* Set the required DSP engine configuration
     *  - the other bits assumed to be in the default reset state.
     */
    CORCONbits.ACCSAT = 1;
    CORCONbits.SATA = 1;
    CORCONbits.SATB = 1;

#ifdef __dsPIC33F__
    /* We have 8MHz XTAL on Explorer16
     * Fvco = Fin * (PLLDIV+2) / (PLLPRE+2)
     * Fvco must be in the range 100..200 MHz
     * Fpfd = Fvco / (PLLDIV+2) must be in the range 0.8..8 MHz
     * Fosc = Fvco / (2*(PLLPOST+1))
     * Fcy  = Fosc / 2
     */
    //_PLLDIV = 78;   //80: 8MHz * (78+2) = 640MHz
    //_PLLPRE = 2;    // 4: Fvco = 640MHz / (2+2) = 160MHz, Fpfd = 2MHz
    //_PLLPOST = 0;   // 2: Fosc = 160MHz / 2 = 80MHz

    osc_set_pll(PLLPRE_4, PLLPOST_2, 80);
    osc_do_switch(OSCSEL_PRIPLL);

    while (!osc_switch_complete());
    while (!pll_has_lock());
#endif //__dsPIC33F__

    adc_set_all_digital();

    plm_demod_start();
    plm_mod_start();

    while (1)
    {
        /* Prepare something to transmit.
         * Fill-in 'txbuf', set 'bytes_to_send' accordingly
         */
        //...

        /* When data is ready, check if TX buffer is empty */
        if ((plm_get_status() & PLM_TX_BF_MASK) == 0)
        {
            /* Modem will delay transmission if it's receiving */
            plm_xmit(txbuf, bytes_to_send);
        }

        /* Receive. The modem also receives own transmissions.
         * At most RXBUF_SIZE bytes will be written to rxbuf.
         */
        end_ptr = plm_recv(rxbuf, RXBUF_SIZE);

        /* Swap buffers - if we passed 'rxbuf1' to plm_recv(),
         * then the modem is busy with 'rxbuf1' and we must not
         * touch it now. However, 'rxbuf2' is ready to be processed.
         */
        if (rxbuf == rxbuf1)
        {
            rxbuf = rxbuf2;
        }
        else
        {
            rxbuf = rxbuf1;
        }

        /* Do something with the data received.
         * The data starts at 'rxbuf' and ends at 'end_ptr'.
         * It is possible that end_ptr == rxbuf (nothing received),
         * or that end_ptr == NULL (first pass).
         */
        //...
    }
}

