/**********************************************************************
* � 2011 Microchip Technology Inc.
*
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.00 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip,s 
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP,S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 development board with
* Consumer-band BPSK 7.2kbps PLM PICtail Plus Daughter Board
**********************************************************************//* 
 * $Date: 2010-11-05 16:48:49 +0100 (Fri, 05 Nov 2010) $
 * $Revision: 88 $
 * $Author:   $
 */

/** 
 * @file
 * Network buffer debugging. 
 */

#include <config.h>
#include <net/nbuf.h>

#define DEBUG_CONTEXT NET
#include <sys/debug.h>

/** 
 * Dump a net page to debug interface. 
 *
 * @param page Net page to dump
 */
void npage_dump(struct npage *page)
{
    int i;
    DEBUG_VERBOSE("Net page:\r\n");
    for (i = 0; i < C_NET_NPAGE_SIZE; i++)
    {
        DEBUG_VERBOSE_U8(page->data[i]);
        DEBUG_VERBOSE(" ");
        if (i % 8 == 7)
        {
            DEBUG_VERBOSE("\r\n");
        }
    }
    DEBUG_VERBOSE("\r\n");
}

/** 
 * Dump a net buffer to debug interface. 
 *
 * @param buf Net buffer to dump
 */
void nbuf_dump(struct nbuf *buf)
{
    struct npage *page;
    DEBUG_VERBOSE("Net buffer:\r\n");

    DEBUG_VERBOSE(" - ref   : ");
    DEBUG_VERBOSE_U16(buf->ref);
    DEBUG_VERBOSE("\r\n");

    DEBUG_VERBOSE(" - start : ");
    DEBUG_VERBOSE_U16(buf->start);
    DEBUG_VERBOSE("\r\n");

    DEBUG_VERBOSE(" - end   : ");
    DEBUG_VERBOSE_U16(buf->end);
    DEBUG_VERBOSE("\r\n");

    DEBUG_VERBOSE(" - pos   : ");
    DEBUG_VERBOSE_U16(buf->pos);
    DEBUG_VERBOSE("\r\n");

    DEBUG_VERBOSE(" - size  : ");
    DEBUG_VERBOSE_U16(buf->size);
    DEBUG_VERBOSE("\r\n");

    if (buf->pages.head)
    {
        if (buf->pages.head->prev)
        {
            DEBUG_PANIC("net: PANIC: head has prev\r\n");
        }
    }
    if (buf->pages.tail)
    {
        if (buf->pages.tail->next)
        {
            DEBUG_PANIC("net: PANIC: tail has next\r\n");
        }
    }

    page = buf->pages.head;
    while (page)
    {
        npage_dump(page);
        page = page->next;
    }

#if 0
    DEBUG_VERBOSE("CURRENT:\r\n");
    if (buf->current)
    {
        npage_dump(buf->current);
    }
    else
    {
        DEBUG_VERBOSE("... is NULL\r\n");
    }
#endif //0
}

